"""Deterministic, read-only explanation of an already computed decision.

This module never changes a score or decision.  It mirrors the current decision
precedence so observability has one causal primary reason and clearly separated
secondary facts and downstream execution blockers.
"""

from __future__ import annotations

from investment.strategy_policy import PRODUCTION_POLICY, StrategyPolicy


BUY_DECISIONS = {"ACCUMULATE", "BUY_PARTIALLY"}

REASON_LABELS_RU = {
    "INSUFFICIENT_HISTORY": "Недостаточно истории торгов",
    "ONCHAIN_CRITICAL_DISTRIBUTION": "Критическое on-chain распределение",
    "MACRO_CRISIS": "Макрорежим CRISIS",
    "VERIFIED_CRITICAL_NEWS": "Подтверждённая критическая новость по активу",
    "FUNDAMENTAL_CRITICAL_RISK": "Критический фундаментальный/token-quality риск",
    "TECHNICAL_THESIS_BROKEN": "Нарушена долгосрочная техническая гипотеза",
    "TAKE_PROFIT_CONDITION": "Условие фиксации прибыли",
    "ONCHAIN_DISTRIBUTION": "On-chain распределение",
    "MACRO_RISK_OFF": "Ограничивающий макрорежим",
    "VERIFIED_BEARISH_NEWS": "Подтверждённый негативный фон по активу",
    "HIGH_TOKEN_UNLOCK_RISK": "Высокий риск разблокировки токенов",
    "POSITION_QUALITY_WEAKENED": "Структура или качество позиции ухудшились",
    "PORTFOLIO_RISK_BLOCK": "Портфельный risk gate",
    "LIQUIDITY_LOW": "Низкая ликвидность или широкий спред",
    "BEARISH_HIGHER_TIMEFRAMES": "Медвежья структура 1W/1D",
    "TOKEN_QUALITY_BELOW_MINIMUM": "Качество токена ниже минимума",
    "ENTRY_ZONE_OR_OVERBOUGHT": "Цена вне зоны накопления или рынок перегрет",
    "STRONG_ACCUMULATION_SETUP": "Сильная структура для накопления",
    "PARTIAL_BUY_SETUP": "Умеренное преимущество для частичной покупки",
    "HOLD_NO_NEW_TRANCHE": "Позиция удерживается без нового транша",
    "COMPOSITE_QUALITY_INSUFFICIENT": "Совокупное качество недостаточно",
    "COMMITTEE_VETO": "Вето инвестиционного комитета",
    "COMMITTEE_CAUTION_DOWNGRADE": "Понижение решения инвестиционным комитетом",
    "CANDIDATE_LIMIT": "Лимит финальных кандидатов",
    "ALTCOIN_FUNDAMENTALS_UNAVAILABLE": "Нет обязательных fundamentals для альткоина",
    "NO_BUY_ZONE": "Нет исполнимой зоны покупки",
    "PRICE_OUTSIDE_BUY_ZONE": "Цена вне зоны покупки",
    "PURCHASES_PAUSED": "Покупки приостановлены",
    "DAILY_TRADE_LIMIT_REACHED": "Дневной лимит операций",
    "BUY_COOLDOWN_ACTIVE": "Период ожидания после покупки",
    "MINIMUM_CASH_RESERVE_WOULD_BE_BREACHED": "Недостаточный свободный резерв",
    "INSUFFICIENT_LISTING_HISTORY": "Не пройден listing/history gate",
    "ANALYSIS_ERROR": "Ошибка анализа",
}


def human_reason(code: str | None) -> str:
    if not code:
        return "Причина не зафиксирована"
    return REASON_LABELS_RU.get(code, code.replace("_", " ").title())


def normalize_execution_reason(reason: str | None) -> str | None:
    if not reason:
        return None
    return str(reason).strip().upper().replace(" ", "_")


def _base_reason_code(analysis: dict, position_exists: bool, policy: StrategyPolicy) -> str:
    technical = analysis.get("technical") or {}
    liquidity = analysis.get("liquidity") or {}
    risk = analysis.get("risk") or {}
    fundamental = analysis.get("fundamental") or {}
    news = analysis.get("news") or {}
    macro = analysis.get("macro") or {}
    on_chain = analysis.get("on_chain") or {}
    weekly = (technical.get("timeframes") or {}).get("1W") or {}
    daily = (technical.get("timeframes") or {}).get("1D") or {}
    committee = analysis.get("committee") or {}
    score = float(
        analysis.get("base_score", committee.get("base_score", analysis.get("score", 0))) or 0
    )
    technical_score = float(technical.get("technical_score", 0) or 0)
    structural_failure = (
        weekly.get("ema_trend") == "BEARISH"
        and daily.get("ema_trend") == "BEARISH"
        and technical_score < float(policy.structural_failure_score)
    )
    if technical.get("history_sufficient") is False:
        return "INSUFFICIENT_HISTORY"
    if on_chain.get("critical") or on_chain.get("bias") == "CRITICAL_DISTRIBUTION":
        return "ONCHAIN_CRITICAL_DISTRIBUTION"
    if macro.get("regime") == "CRISIS":
        return "MACRO_CRISIS"
    if news.get("critical_items"):
        return "VERIFIED_CRITICAL_NEWS"
    if fundamental.get("blocked"):
        return "FUNDAMENTAL_CRITICAL_RISK"
    if position_exists and structural_failure:
        return "TECHNICAL_THESIS_BROKEN"
    pnl = risk.get("position_pnl_percent")
    if position_exists and pnl is not None and float(pnl) >= float(policy.take_profit_pnl_percent) and technical.get("overbought"):
        return "TAKE_PROFIT_CONDITION"
    if on_chain.get("bias") == "DISTRIBUTION":
        return "ONCHAIN_DISTRIBUTION"
    if (
        macro.get("regime")
        in {"INFLATION_SHOCK", "RECESSION_RISK", "LIQUIDITY_CONTRACTION", "RISK_OFF"}
        and not position_exists
        and score < float(policy.macro_riskoff_min_score)
    ):
        return "MACRO_RISK_OFF"
    if float(news.get("position_size_multiplier", 1) or 0) < 1:
        return "VERIFIED_BEARISH_NEWS"
    if fundamental.get("unlock_risk") == "HIGH_UNLOCK_RISK":
        return "HIGH_TOKEN_UNLOCK_RISK"
    if position_exists and (
        score < float(policy.reduce_score)
        or (policy.reduce_on_bearish_regime and technical.get("market_regime") == "BEARISH")
    ):
        return "POSITION_QUALITY_WEAKENED"
    if liquidity.get("liquidity_status", "LOW") == "LOW":
        return "LIQUIDITY_LOW"
    if risk.get("blocked") and not position_exists:
        return "PORTFOLIO_RISK_BLOCK"
    if not position_exists and structural_failure:
        return "BEARISH_HIGHER_TIMEFRAMES"
    fundamental_score = fundamental.get("quality_score")
    if fundamental_score is not None and float(fundamental_score) < float(policy.fundamental_min_score):
        return "TOKEN_QUALITY_BELOW_MINIMUM"
    distance = technical.get("distance_to_support_percent")
    if technical.get("overbought") or (distance is not None and float(distance) > float(policy.max_distance_to_support_percent)):
        return "ENTRY_ZONE_OR_OVERBOUGHT"
    if score >= float(policy.accumulate_score) and technical.get("market_regime") == "BULLISH":
        return "STRONG_ACCUMULATION_SETUP"
    if score >= float(policy.partial_buy_score) and technical.get("market_regime") in {"BULLISH", "NEUTRAL"}:
        return "PARTIAL_BUY_SETUP"
    if position_exists:
        return "HOLD_NO_NEW_TRANCHE"
    return "COMPOSITE_QUALITY_INSUFFICIENT"


def build_decision_trace(
    analysis: dict, *, position_exists: bool = False, policy: StrategyPolicy | None = None,
) -> dict:
    policy = policy or PRODUCTION_POLICY
    committee = analysis.get("committee") or {}
    final_decision = str(analysis.get("decision") or "WAIT")
    base_decision = str(committee.get("base_decision") or final_decision)
    base_reason = _base_reason_code(analysis, position_exists, policy)
    secondary: list[str] = []
    if final_decision != base_decision:
        if committee.get("vetoes"):
            primary = "COMMITTEE_VETO"
            secondary.extend(f"COMMITTEE_VETO:{name}" for name in committee["vetoes"])
        else:
            primary = "COMMITTEE_CAUTION_DOWNGRADE"
            secondary.extend(
                f"COMMITTEE_CAUTION:{name}" for name in committee.get("caution_votes") or []
            )
        secondary.append(base_reason)
    else:
        primary = base_reason

    technical = analysis.get("technical") or {}
    fundamental = analysis.get("fundamental") or {}
    risk = analysis.get("risk") or {}
    liquidity = analysis.get("liquidity") or {}
    score_components = {
        "technical_score": technical.get("technical_score"),
        "fundamental_score": fundamental.get("quality_score"),
        "technical_weight": 1.0 if fundamental.get("quality_score") is None else 0.65,
        "fundamental_weight": 0.0 if fundamental.get("quality_score") is None else 0.35,
        "fundamental_components": fundamental.get("score_components") or [],
        "base_score": analysis.get("base_score", committee.get("base_score")),
        "committee_penalty": committee.get("score_penalty"),
        "committee_penalty_components": {
            "caution_votes": len(committee.get("caution_votes") or []),
            "points_per_caution": 5,
            "evidence_errors": len(committee.get("evidence_errors") or []),
            "points_per_evidence_error": 3,
            "maximum_penalty": 25,
            "positive_or_confirming_bonus": 0,
        },
        "final_score": analysis.get("score"),
        "timeframe_scores": {
            name: item.get("score")
            for name, item in (technical.get("timeframes") or {}).items()
            if isinstance(item, dict)
        },
        "technical_components": technical.get("score_components") or [],
        "technical_configured_weights": technical.get("configured_weights") or {},
        "strategy_policy": {
            "accumulate_score": float(policy.accumulate_score),
            "partial_buy_score": float(policy.partial_buy_score),
            "reduce_score": float(policy.reduce_score),
            "structural_failure_score": float(policy.structural_failure_score),
            "reduce_on_bearish_regime": bool(policy.reduce_on_bearish_regime),
            "max_distance_to_support_percent": float(policy.max_distance_to_support_percent),
        },
    }
    gates = {
        "history": {
            "evaluated": "history_sufficient" in technical,
            "pass": technical.get("history_sufficient") is not False,
        },
        "liquidity": {
            "evaluated": True,
            "pass": liquidity.get("liquidity_status", "LOW") != "LOW",
            "status": liquidity.get("liquidity_status", "LOW"),
            "hard_block": liquidity.get(
                "hard_block", liquidity.get("liquidity_status", "LOW") == "LOW"
            ),
            "reason": liquidity.get("reason"),
            "planned_order_usdt": liquidity.get("planned_order_usdt"),
            "depth_20_usdt": liquidity.get("depth_20_usdt"),
            "depth_to_order_ratio": liquidity.get("depth_to_order_ratio"),
            "spread_percent": liquidity.get("spread_percent"),
            "estimated_buy_slippage_bps": liquidity.get("estimated_buy_slippage_bps"),
        },
        "spread": {
            "evaluated": liquidity.get("spread_percent") is not None,
            "pass": (
                liquidity.get("spread_percent") is None
                or float(liquidity["spread_percent"]) <= 0.30
            ),
        },
        "portfolio_risk": {
            "evaluated": True,
            "pass": not bool(risk.get("blocked")),
            "reasons": risk.get("block_reasons") or [],
        },
        "fundamentals": {
            "evaluated": fundamental.get("status") is not None,
            "pass": not bool(fundamental.get("blocked")),
            "status": fundamental.get("status", "UNAVAILABLE"),
        },
        "token_quality": {
            "evaluated": fundamental.get("quality_score") is not None,
            "pass": (
                fundamental.get("quality_score") is None
                or float(fundamental["quality_score"]) >= float(policy.fundamental_min_score)
            ),
        },
        "token_unlock": {
            "evaluated": fundamental.get("unlock_risk") not in {None, "UNAVAILABLE"},
            "pass": fundamental.get("unlock_risk") not in {
                "HIGH_UNLOCK_RISK", "CRITICAL_UNLOCK_RISK"
            },
            "status": fundamental.get("unlock_risk", "UNAVAILABLE"),
        },
        "macro": {
            "evaluated": (analysis.get("macro") or {}).get("status") == "AVAILABLE",
            "pass": (analysis.get("macro") or {}).get("regime") != "CRISIS",
            "status": (analysis.get("macro") or {}).get("status", "UNAVAILABLE"),
        },
        "news": {
            "evaluated": (analysis.get("news") or {}).get("status") == "AVAILABLE",
            "pass": not bool((analysis.get("news") or {}).get("critical_items")),
            "status": (analysis.get("news") or {}).get("status", "UNAVAILABLE"),
        },
        "on_chain": {
            "evaluated": (analysis.get("on_chain") or {}).get("status") == "AVAILABLE",
            "pass": not bool((analysis.get("on_chain") or {}).get("critical")),
            "status": (analysis.get("on_chain") or {}).get("status", "UNAVAILABLE"),
        },
        "trend_alignment": {
            "evaluated": True,
            "pass": technical.get("market_regime") != "BEARISH",
        },
        "entry_location": {
            "evaluated": technical.get("distance_to_support_percent") is not None,
            "pass": not (
                technical.get("overbought")
                or (
                    technical.get("distance_to_support_percent") is not None
                    and float(technical["distance_to_support_percent"]) > float(policy.max_distance_to_support_percent)
                )
            ),
        },
        "capital_capacity": {
            "evaluated": risk.get("remaining_capacity_before_context_usdt") is not None,
            "pass": float(
                risk.get(
                    "remaining_capacity_before_context_usdt",
                    risk.get("remaining_capacity_usdt", 0),
                ) or 0
            ) > 0,
        },
        # These concepts influence indicators/plans but are not independent hard
        # gates in v4.8.0.  Keep them explicit so diagnostics do not invent a
        # pass/fail rate for a condition the strategy never evaluates.
        "valuation": {"evaluated": False, "pass": None, "status": "NOT_A_STANDALONE_GATE"},
        "volatility": {"evaluated": False, "pass": None, "status": "PLAN_INPUT_ONLY"},
        "momentum": {"evaluated": False, "pass": None, "status": "EMBEDDED_IN_TECHNICAL_SCORE"},
    }
    return {
        "base_decision": base_decision,
        "final_decision": final_decision,
        "primary_reason": primary,
        "primary_reason_human": human_reason(primary),
        "secondary_reasons": list(dict.fromkeys(secondary)),
        "score_components": score_components,
        "gates": gates,
    }
