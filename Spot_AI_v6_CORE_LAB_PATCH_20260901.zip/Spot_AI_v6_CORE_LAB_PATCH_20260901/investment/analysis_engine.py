from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone

from analysis.technical_analyzer import TechnicalAnalyzer
from committee.committee_engine import CommitteeEngine
from config.settings import PAPER_SLIPPAGE_BPS
from data_engine.historical_liquidity import HistoricalLiquidityProxy
from data_engine.market_data import MarketData
from data_engine.orderbook import OrderBook
from fundamentals.fundamental_engine import FundamentalEngine
from investment.accumulation_plan import AccumulationPlanner
from investment.decision_engine import DecisionEngine
from investment.event_momentum import EventMomentumEngine
from investment.models import InvestmentAnalysis, InvestmentDecision, PositionState
from investment.portfolio_risk import PortfolioRiskManager
from macro.macro_engine import MacroEngine
from news.news_engine import NewsEngine
from news.archive import NewsArchive
from onchain.onchain_engine import OnChainEngine
from testing.replay import PointInTimeStore
from utils.logger import logger


class SpotInvestmentEngine:
    def __init__(
        self,
        market_data: MarketData | None = None,
        orderbook: OrderBook | None = None,
        risk_manager: PortfolioRiskManager | None = None,
        fundamental_engine: FundamentalEngine | None = None,
        news_engine: NewsEngine | None = None,
        macro_engine: MacroEngine | None = None,
        onchain_engine: OnChainEngine | None = None,
        committee_engine: CommitteeEngine | None = None,
        decision_engine: DecisionEngine | None = None,
        point_in_time_store: PointInTimeStore | None = None,
        historical_liquidity: HistoricalLiquidityProxy | None = None,
    ):
        self.market_data = market_data or MarketData()
        self.orderbook = orderbook or OrderBook(self.market_data.client)
        self.technical_analyzer = TechnicalAnalyzer()
        self.risk_manager = risk_manager or PortfolioRiskManager()
        self.decision_engine = decision_engine or DecisionEngine()
        self.accumulation_planner = AccumulationPlanner()
        from config.settings import (
            EVENT_MAX_CHASE_ATR_MULTIPLE,
            EVENT_MAX_CHASE_PERCENT,
            EVENT_MAX_NEWS_AGE_HOURS,
            EVENT_MIN_NEWS_RELIABILITY,
            EVENT_OVERBOUGHT_ENTRY_SCALE_PERCENT,
            EVENT_OVERBOUGHT_EXCEPTION_ENABLED,
        )
        self.event_momentum_engine = EventMomentumEngine(
            min_news_reliability=EVENT_MIN_NEWS_RELIABILITY,
            max_news_age_hours=EVENT_MAX_NEWS_AGE_HOURS,
            enhanced_confirmation=True,
            overbought_exception_enabled=EVENT_OVERBOUGHT_EXCEPTION_ENABLED,
            overbought_entry_scale_percent=EVENT_OVERBOUGHT_ENTRY_SCALE_PERCENT,
            max_chase_atr_multiple=EVENT_MAX_CHASE_ATR_MULTIPLE,
            max_chase_percent=EVENT_MAX_CHASE_PERCENT,
        )
        self.fundamental_engine = fundamental_engine or FundamentalEngine()
        if news_engine is not None:
            self.news_engine = news_engine
        else:
            from config.settings import EVENT_NEWS_ARCHIVE_RETENTION_DAYS, NEWS_ARCHIVE_DB_PATH
            self.news_engine = NewsEngine(
                archive=NewsArchive(
                    NEWS_ARCHIVE_DB_PATH,
                    retention_days=EVENT_NEWS_ARCHIVE_RETENTION_DAYS,
                )
            )
        self.macro_engine = macro_engine or MacroEngine()
        self.onchain_engine = onchain_engine or OnChainEngine()
        self.committee_engine = committee_engine or CommitteeEngine()
        self.point_in_time_store = point_in_time_store
        self.historical_liquidity = historical_liquidity or HistoricalLiquidityProxy()

    @staticmethod
    def _fail_open_optional_context(kind: str, payload: dict | None) -> dict:
        """Prevent unavailable optional data from impersonating a negative signal."""
        result = dict(payload or {})
        if result.get("status") == "AVAILABLE":
            return result
        result["provider_reported_position_size_multiplier"] = result.get(
            "position_size_multiplier"
        )
        result["position_size_multiplier"] = 1.0
        result["fail_open_applied"] = True
        if kind == "news":
            result.update(
                critical_items=[], bearish_count=0, bullish_count=0,
                impact="NO_CHANGE_WITH_INCOMPLETE_DATA", review_required=False,
            )
        elif kind == "macro":
            result["regime"] = "NEUTRAL"
        elif kind == "on_chain":
            result.update(bias="UNAVAILABLE", critical=False)
        return result

    @staticmethod
    def _market_only_optional_contexts() -> tuple[dict, dict, dict, dict]:
        """Neutral optional context used by the live CORE_LAB control profile."""
        fundamental = {
            "status": "UNAVAILABLE", "reason": "CORE_LAB_MARKET_ONLY",
            "quality_score": None, "unlock_risk": "UNAVAILABLE", "blocked": False,
            "warnings": ["optional context frozen by CORE_LAB"], "critical_flags": [],
        }
        news = {
            "status": "UNAVAILABLE", "reason": "CORE_LAB_MARKET_ONLY", "items": [],
            "critical_items": [], "bearish_count": 0, "bullish_count": 0,
            "unverified_count": 0, "impact": "FROZEN_BY_CORE_LAB",
            "position_size_multiplier": 1.0, "review_required": False,
        }
        macro = {
            "status": "UNAVAILABLE", "reason": "CORE_LAB_MARKET_ONLY",
            "regime": "NEUTRAL", "position_size_multiplier": 1.0,
        }
        on_chain = {
            "status": "UNAVAILABLE", "reason": "CORE_LAB_MARKET_ONLY",
            "bias": "UNAVAILABLE", "critical": False, "position_size_multiplier": 1.0,
        }
        return fundamental, news, macro, on_chain

    @staticmethod
    def _planned_order_amount(plan: dict) -> float:
        zone = next(
            (
                item for item in (plan.get("zones") or [])
                if float(item.get("amount_usdt") or 0) > 0
            ),
            None,
        )
        return float((zone or {}).get("amount_usdt") or 0)

    def assess_live_liquidity(self, symbol: str, planned_order_usdt: float) -> dict:
        """Fetch and assess current liquidity for an exact proposed BUY amount."""
        book = self.orderbook.get(symbol.upper(), 100)
        assessor = getattr(self.orderbook, "assess_for_order", None)
        if callable(assessor):
            result = assessor(
                book,
                planned_order_usdt,
                max_expected_slippage_bps=PAPER_SLIPPAGE_BPS,
            )
        else:  # Backward-compatible test/custom OrderBook implementation.
            result = self.orderbook.analyze(book)
        logger.info(
            "liquidity_decision symbol=%s planned_order_usdt=%.8f "
            "depth_20_usdt=%s depth_to_order_ratio=%s spread=%s "
            "liquidity_status=%s hard_block=%s reason=%s",
            symbol.upper(),
            float(planned_order_usdt or 0),
            result.get("depth_20_usdt"),
            result.get("depth_to_order_ratio"),
            result.get("spread_percent"),
            result.get("liquidity_status"),
            result.get("hard_block", result.get("liquidity_status") == "LOW"),
            result.get("reason"),
        )
        return result

    def analyze(
        self,
        symbol: str,
        position: PositionState | None = None,
        portfolio_positions: list[PositionState] | None = None,
        portfolio_drawdown_percent: float = 0.0,
        as_of_ms: int | None = None,
        current_price_override: float | None = None,
        context_mode: str = "full",
    ) -> InvestmentAnalysis:
        symbol = symbol.upper()
        context_mode = str(context_mode or "full").lower().strip()
        if context_mode not in {"full", "market_only"}:
            raise ValueError("context_mode must be 'full' or 'market_only'")
        replay_mode = as_of_ms is not None
        decision_time = (
            datetime.fromtimestamp(as_of_ms / 1000, tz=timezone.utc)
            if replay_mode
            else datetime.now(timezone.utc)
        )

        timings: dict[str, float] = {}
        timer = time.perf_counter()
        timeframes = self.market_data.get_all_timeframes(symbol, as_of_ms=as_of_ms)
        btc_daily = (
            timeframes["1D"]
            if symbol == "BTCUSDT"
            else self.market_data.get_klines("BTCUSDT", "1d", 300, as_of_ms=as_of_ms)
        )
        eth_daily = (
            timeframes["1D"]
            if symbol == "ETHUSDT"
            else self.market_data.get_klines("ETHUSDT", "1d", 300, as_of_ms=as_of_ms)
        )
        if replay_mode:
            current_price = float(self.market_data.get_price_at(symbol, as_of_ms))
            current_price_source = "CLOSED_1H_AT_OR_BEFORE_DECISION"
        elif current_price_override is not None and float(current_price_override) > 0:
            current_price = float(current_price_override)
            current_price_source = "SPOT_TICKER_LIVE_SNAPSHOT"
        else:
            current_price = float(self.market_data.get_current_price(symbol))
            current_price_source = "SPOT_TICKER_LIVE"
        timings["market_data"] = round((time.perf_counter() - timer) * 1000, 2)
        timer = time.perf_counter()
        technical = self.technical_analyzer.analyze(
            timeframes, btc_daily, eth_daily, current_price_override=current_price
        )
        timings["technical"] = round((time.perf_counter() - timer) * 1000, 2)

        position = position or PositionState(symbol=symbol)
        if position.quantity > 0 and position.current_value_usdt <= 0:
            position = PositionState(
                symbol=symbol,
                quantity=position.quantity,
                average_price=position.average_price,
                invested_usdt=position.invested_usdt
                or position.quantity * position.average_price,
                current_value_usdt=position.quantity * current_price,
            )

        if replay_mode:
            timer = time.perf_counter()
            liquidity = self.historical_liquidity.analyze(timeframes.get("1D") or [])
            timings["liquidity"] = round((time.perf_counter() - timer) * 1000, 2)
            timer = time.perf_counter()
            fundamental = self._point_in_time_module("fundamental", symbol, decision_time)
            timings["fundamental"] = round((time.perf_counter() - timer) * 1000, 2)
            timer = time.perf_counter()
            news = self._point_in_time_module("news", symbol, decision_time)
            timings["news"] = round((time.perf_counter() - timer) * 1000, 2)
            timer = time.perf_counter()
            macro = self._point_in_time_module("macro", "*", decision_time)
            timings["macro"] = round((time.perf_counter() - timer) * 1000, 2)
            timer = time.perf_counter()
            on_chain = self._point_in_time_module("on_chain", symbol, decision_time)
            timings["on_chain"] = round((time.perf_counter() - timer) * 1000, 2)
        else:
            timer = time.perf_counter()
            live_orderbook = self.orderbook.get(symbol, 100)
            liquidity = self.orderbook.analyze(live_orderbook)
            timings["liquidity"] = round((time.perf_counter() - timer) * 1000, 2)
            if context_mode == "market_only":
                fundamental, news, macro, on_chain = self._market_only_optional_contexts()
                timings.update({
                    "fundamental": 0.0, "news": 0.0, "macro": 0.0, "on_chain": 0.0,
                })
            else:
                timer = time.perf_counter()
                fundamental = self.fundamental_engine.analyze(symbol)
                timings["fundamental"] = round((time.perf_counter() - timer) * 1000, 2)
                timer = time.perf_counter()
                news = self.news_engine.analyze(symbol)
                timings["news"] = round((time.perf_counter() - timer) * 1000, 2)
                timer = time.perf_counter()
                macro = self.macro_engine.analyze()
                timings["macro"] = round((time.perf_counter() - timer) * 1000, 2)
                timer = time.perf_counter()
                on_chain = self.onchain_engine.analyze(symbol)
                timings["on_chain"] = round((time.perf_counter() - timer) * 1000, 2)

        news = self._fail_open_optional_context("news", news)
        macro = self._fail_open_optional_context("macro", macro)
        on_chain = self._fail_open_optional_context("on_chain", on_chain)

        timer = time.perf_counter()
        risk = self.risk_manager.assess(
            symbol, position, portfolio_positions, portfolio_drawdown_percent
        )
        risk["position_pnl_percent"] = position.pnl_percent
        timings["portfolio_risk"] = round((time.perf_counter() - timer) * 1000, 2)

        # Determine the exact first-tranche notional before applying the live
        # order-size-aware liquidity decision.  This preview does not mutate
        # risk, strategy thresholds, or the eventual accumulation plan.
        if not replay_mode and callable(getattr(self.orderbook, "assess_for_order", None)):
            _, preview_score, _, _ = self.decision_engine.decide(
                technical,
                liquidity,
                risk,
                position,
                fundamental=fundamental,
                news=news,
                macro=macro,
                on_chain=on_chain,
            )
            daily_preview = technical.get("timeframes", {}).get("1D", {})
            preview_capacity = (
                float(risk.get("remaining_capacity_usdt", 0))
                * float(news.get("position_size_multiplier", 1.0))
                * float(macro.get("position_size_multiplier", 1.0))
                * float(on_chain.get("position_size_multiplier", 1.0))
            )
            preview_plan = self.accumulation_planner.build(
                current_price=current_price,
                supports=technical.get("supports") or [],
                atr_percent=daily_preview.get("atr_percent"),
                target_position_usdt=preview_capacity,
                regime=technical.get("market_regime", "NEUTRAL"),
                quality_score=preview_score,
                buying_allowed=True,
            )
            planned_order_usdt = self._planned_order_amount(preview_plan)
            liquidity = self.orderbook.assess_for_order(
                live_orderbook,
                planned_order_usdt,
                max_expected_slippage_bps=PAPER_SLIPPAGE_BPS,
            )
            logger.info(
                "liquidity_decision symbol=%s planned_order_usdt=%.8f "
                "depth_20_usdt=%s depth_to_order_ratio=%s spread=%s "
                "liquidity_status=%s hard_block=%s reason=%s",
                symbol,
                planned_order_usdt,
                liquidity.get("depth_20_usdt"),
                liquidity.get("depth_to_order_ratio"),
                liquidity.get("spread_percent"),
                liquidity.get("liquidity_status"),
                liquidity.get("hard_block"),
                liquidity.get("reason"),
            )
        timer = time.perf_counter()
        decision, score, reasons, risks = self.decision_engine.decide(
            technical,
            liquidity,
            risk,
            position,
            fundamental=fundamental,
            news=news,
            macro=macro,
            on_chain=on_chain,
        )
        timings["decision"] = round((time.perf_counter() - timer) * 1000, 2)

        buying_allowed = decision in {
            InvestmentDecision.ACCUMULATE,
            InvestmentDecision.BUY_PARTIALLY,
        }
        daily = technical.get("timeframes", {}).get("1D", {})
        news_multiplier = float(news.get("position_size_multiplier", 1.0))
        macro_multiplier = float(macro.get("position_size_multiplier", 1.0))
        onchain_multiplier = float(on_chain.get("position_size_multiplier", 1.0))
        risk["news_position_size_multiplier"] = news_multiplier
        risk["macro_position_size_multiplier"] = macro_multiplier
        risk["onchain_position_size_multiplier"] = onchain_multiplier
        risk["remaining_capacity_before_context_usdt"] = float(
            risk.get("remaining_capacity_usdt", 0)
        )
        risk["remaining_capacity_usdt"] = round(
            float(risk.get("remaining_capacity_usdt", 0))
            * news_multiplier
            * macro_multiplier
            * onchain_multiplier,
            2,
        )

        # v5.1.1 independent NEWS/EVENT sleeve assessment. It uses point-in-time
        # observable inputs and never rewrites DecisionEngine. Autonomous paper
        # execution may consume the separately capped event sleeve.
        event_momentum = self.event_momentum_engine.assess(
            current_price=current_price,
            timeframes=timeframes,
            technical=technical,
            liquidity=liquidity,
            news=news,
            macro=macro,
            position_exists=position.exists,
            decision_time=decision_time,
        ).to_dict()

        accumulation = self.accumulation_planner.build(
            current_price=current_price,
            supports=technical.get("supports") or [],
            atr_percent=daily.get("atr_percent"),
            target_position_usdt=float(risk.get("remaining_capacity_usdt", 0)),
            regime=technical.get("market_regime", "NEUTRAL"),
            quality_score=score,
            buying_allowed=buying_allowed,
        )
        take_profit = self._take_profit_plan(
            current_price,
            technical.get("resistances") or [],
            daily.get("atr_percent"),
        )
        review_days = (
            3
            if decision in {InvestmentDecision.REDUCE, InvestmentDecision.EXIT_ON_RISK}
            or fundamental.get("unlock_risk")
            in {"HIGH_UNLOCK_RISK", "CRITICAL_UNLOCK_RISK"}
            else 7
        )
        next_review = (decision_time + timedelta(days=review_days)).date().isoformat()
        last_closed_candles = {
            name: (candles[-1].get("close_time") if candles else None)
            for name, candles in timeframes.items()
        }
        data_quality = {
            "mode": "POINT_IN_TIME_REPLAY" if replay_mode else "LIVE_READ_ONLY",
            "context_mode": context_mode,
            "decision_as_of_utc": decision_time.isoformat(),
            "technical_completeness_percent": technical.get(
                "data_completeness_percent"
            ),
            "history_days_observed": technical.get("history_days_observed"),
            "history_sufficient": technical.get("history_sufficient"),
            "last_closed_candle_ms": last_closed_candles,
            "spot_market_data": "AVAILABLE",
            "current_price_source": current_price_source,
            "liquidity_source": liquidity.get("source", "live_orderbook"),
            "fundamentals": fundamental.get("status", "UNAVAILABLE"),
            "news": news.get("status", "UNAVAILABLE"),
            "macro": macro.get("status", "UNAVAILABLE"),
            "on_chain": on_chain.get("status", "UNAVAILABLE"),
            "lookahead_guard": "ENFORCED" if replay_mode else "NOT_APPLICABLE",
            "provider_timings_ms": timings,
            "optional_context_fail_open": {
                "news": bool(news.get("fail_open_applied")),
                "macro": bool(macro.get("fail_open_applied")),
                "on_chain": bool(on_chain.get("fail_open_applied")),
            },
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        result = InvestmentAnalysis(
            symbol=symbol,
            decision=decision,
            horizon=self._horizon(technical),
            score=round(score, 2),
            current_price=current_price,
            technical=technical,
            liquidity=liquidity,
            risk=risk,
            accumulation_plan=accumulation,
            take_profit_plan=take_profit,
            reasons=reasons,
            risks=risks,
            review_after_days=review_days,
            next_review_date=next_review,
            data_quality=data_quality,
            fundamental=fundamental,
            news=news,
            macro=macro,
            on_chain=on_chain,
            event_momentum=event_momentum,
        )
        committee = self.committee_engine.review(
            result.to_dict(), position_exists=position.exists
        )
        committee["base_score"] = round(float(score), 2)
        committee["score_penalty"] = round(
            max(0.0, float(score) - float(committee["committee_score"])), 2
        )
        result.committee = committee
        result.decision = InvestmentDecision(committee["final_decision"])
        result.score = float(committee["committee_score"])
        result.data_quality["committee"] = "COMPLETE"
        result.data_quality["decision_trace"] = "DETERMINISTIC_V1"
        return result

    def _point_in_time_module(
        self, kind: str, symbol: str, decision_time: datetime
    ) -> dict:
        if self.point_in_time_store is None:
            payload = {
                "status": "UNAVAILABLE",
                "reason": "point_in_time_store_not_configured",
            }
        else:
            payload = self.point_in_time_store.latest_payload(
                kind, symbol, decision_time
            )
        status = payload.get("status", "UNAVAILABLE")
        if status == "AVAILABLE":
            return payload
        if kind == "fundamental":
            return {
                **payload,
                "status": status,
                "quality_score": None,
                "unlock_risk": "UNAVAILABLE",
                "blocked": False,
                "warnings": [payload.get("reason", "fundamental replay data unavailable")],
                "critical_flags": [],
            }
        if kind == "news":
            return {
                **payload,
                "status": status,
                "items": [],
                "critical_items": [],
                "bearish_count": 0,
                "bullish_count": 0,
                "unverified_count": 0,
                "impact": "NO_CHANGE_WITH_INCOMPLETE_DATA",
                "position_size_multiplier": 1.0,
                "review_required": False,
            }
        if kind == "macro":
            return {
                **payload,
                "status": status,
                "regime": "NEUTRAL",
                "position_size_multiplier": 1.0,
                "reasons": [payload.get("reason", "macro replay data unavailable")],
            }
        return {
            **payload,
            "status": status,
            "bias": "UNAVAILABLE",
            "position_size_multiplier": 1.0,
            "critical": False,
            "reasons": [],
            "risks": [payload.get("reason", "on-chain replay data unavailable")],
        }

    @staticmethod
    def _horizon(technical: dict) -> str:
        score = float(technical.get("technical_score", 0))
        regime = technical.get("market_regime")
        if regime == "BULLISH" and score >= 75:
            return "3–12 месяцев"
        if score >= 58:
            return "1–6 месяцев"
        return "Наблюдение; пересмотр через 7 дней"

    @staticmethod
    def _take_profit_plan(
        price: float, resistances: list[float], atr_percent: float | None
    ) -> dict:
        volatility = max(float(atr_percent or 4), 2) / 100
        candidates = [float(value) for value in resistances if float(value) > price]
        defaults = [
            price * (1 + max(0.12, volatility * 3)),
            price * (1 + max(0.25, volatility * 6)),
            price * (1 + max(0.45, volatility * 10)),
        ]
        targets: list[float] = []
        for candidate in candidates + defaults:
            if candidate > price and all(
                abs(candidate / existing - 1) > 0.03 for existing in targets
            ):
                targets.append(candidate)
            if len(targets) == 3:
                break
        targets.sort()
        weights = [20, 30, 30]
        return {
            "targets": [
                {
                    "name": f"TP{index}",
                    "price": AccumulationPlanner._round_price(value),
                    "sell_percent_of_position": weights[index - 1],
                }
                for index, value in enumerate(targets, 1)
            ],
            "trailing_exit_percent": round(max(10, volatility * 250), 1),
            "strategic_remainder_percent": 20,
            "risk_exit": (
                "EXIT_ON_RISK when technical or fundamental thesis is invalidated"
            ),
        }
