"""BTC/ETH CORE_LAB audit on the user's local historical cache.

Runs two orthogonal experiments without changing production settings:
1) exit-policy A/B: production vs LONG_HORIZON_EXIT in market_only baseline;
2) layer attribution: baseline -> recycling -> news/event -> full.

The script is intended for Codex/local execution where the large candle/news
cache exists. It never writes to the production portfolio database.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from investment.analysis_engine import SpotInvestmentEngine
from testing.historical_replay import HistoricalReplayConfig, compare_strategy_runs
from testing.strategy_recovery import DEFAULT_RECOVERY_VARIANTS, run_variant_grid


def _variants():
    wanted = {"BASELINE_V480", "LONG_HORIZON_EXIT"}
    return tuple(item for item in DEFAULT_RECOVERY_VARIANTS if item.name in wanted)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", default="2026-06-03")
    parser.add_argument("--end", default="2026-08-31")
    parser.add_argument("--symbols", nargs="+", default=["BTCUSDT", "ETHUSDT"])
    parser.add_argument("--frequencies", nargs="+", default=["1d", "4h"])
    parser.add_argument("--capital", type=float, default=1000.0)
    parser.add_argument("--output", default="output/core_lab_btc_eth")
    parser.add_argument("--skip-layers", action="store_true")
    args = parser.parse_args()

    symbols = [item.upper() for item in args.symbols]
    root = Path(args.output) / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    root.mkdir(parents=True, exist_ok=False)
    manifest = {
        "purpose": "CORE_LAB_BTC_ETH_POLICY_AND_LAYER_AUDIT",
        "production_settings_changed": False,
        "start": args.start,
        "end": args.end,
        "symbols": symbols,
        "frequencies": args.frequencies,
        "runs": [],
    }

    for frequency in args.frequencies:
        frequency_root = root / frequency
        frequency_root.mkdir(parents=True, exist_ok=True)
        policy_result = run_variant_grid(
            start=args.start,
            end=args.end,
            symbols=symbols,
            output_root=frequency_root / "exit_policy_ab",
            variants=_variants(),
            frequency=frequency,
            capital=args.capital,
            candidate_limit=len(symbols),
            max_open_positions=len(symbols),
        )
        row = {"frequency": frequency, "exit_policy_ab": policy_result}

        if not args.skip_layers:
            base = HistoricalReplayConfig(
                start=args.start,
                end=args.end,
                frequency=frequency,
                mode="market_only",
                strategy_mode="baseline",
                universe_mode="fixed",
                universe_size=len(symbols),
                candidate_limit=len(symbols),
                max_open_positions=len(symbols),
                capital=args.capital,
                performance_mode="fast",
                cache_only=True,
            )
            layer_result, layer_dir = compare_strategy_runs(
                lambda: SpotInvestmentEngine(),
                base,
                symbols,
                output_root=frequency_root / "layer_attribution",
            )
            row["layer_attribution"] = layer_result
            row["layer_dir"] = str(layer_dir)
        manifest["runs"].append(row)

    (root / "CORE_LAB_AUDIT_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
