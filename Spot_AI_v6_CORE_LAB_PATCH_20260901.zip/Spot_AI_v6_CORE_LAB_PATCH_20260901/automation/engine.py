from __future__ import annotations

import asyncio
import threading
import time
import uuid
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

from config.settings import (
    AUTO_REQUIRE_FUNDAMENTALS_FOR_ALTCOINS,
    CYCLE_TIMEOUT_SECONDS,
    PORTFOLIO_DB_PATH,
    SHADOW_DB_PATH,
    EVENT_MOMENTUM_DB_PATH,
    EVENT_PAPER_ENABLED,
    EVENT_CAPITAL_POOL_PERCENT,
    EVENT_MAX_SINGLE_TRADE_PERCENT,
    EVENT_TIME_EXIT_HOURS,
    EVENT_CONFIRMATIONS_REQUIRED,
    EVENT_MAX_ADDITIONAL_TRANCHES,
    EVENT_MAX_CHASE_ATR_MULTIPLE,
    EVENT_MAX_CHASE_PERCENT,
    EVENT_RETEST_TOLERANCE_ATR_MULTIPLE,
    EVENT_SHARP_REJECTION_PERCENT,
    EVENT_TRANCHE_COOLDOWN_MINUTES,
    EVENT_WATCH_DURATION_MINUTES,
    EVENT_WATCH_INTERVAL_SECONDS,
    EVENT_DYNAMIC_BASE_ENABLED,
    EVENT_MICRO_PULLBACK_ENABLED,
    EVENT_DYNAMIC_BASE_REQUIRE_RETEST,
    EVENT_MIN_CONSOLIDATION_MINUTES,
    EVENT_MIN_BASE_QUALITY,
    EVENT_MAX_ANCHOR_RESETS,
    EVENT_ANCHOR_RESET_COOLDOWN_MINUTES,
    EVENT_MAX_WATCH_DURATION_MINUTES,
    EVENT_WATCH_EXTENSION_MINUTES,
    EVENT_MAX_BASE_RANGE_ATR,
    EVENT_RANGE_COMPRESSION_MAX_RATIO,
    EVENT_BASE_VOLUME_CONTRACTION_MAX_RATIO,
    EVENT_BASE_VOLUME_FLOOR_RATIO,
    EVENT_BASE_BREAKOUT_BUFFER_ATR,
    EVENT_MAX_TOTAL_EXTENSION_ATR,
    EVENT_MAX_TOTAL_EXTENSION_PERCENT,
    EVENT_MICRO_PULLBACK_MIN_ATR,
    EVENT_MICRO_PULLBACK_MAX_ATR,
    CAPITAL_RECYCLING_ENABLED,
    HARD_CASH_RESERVE_PERCENT,
    RECYCLE_REBUY_SHARE_PERCENT,
    RECYCLE_OPPORTUNITY_SHARE_PERCENT,
    RECYCLE_RETAINED_SHARE_PERCENT,
    SPOT_EVENT_FAST_ENTRY_ENABLED,
    SPOT_EVENT_FAST_ENTRY_ALLOCATION_PERCENT,
    SPOT_EVENT_FAST_ASSET_NEWS_MAX_AGE_MINUTES,
    SPOT_EVENT_FAST_MACRO_NEWS_MAX_AGE_MINUTES,
    SPOT_EVENT_FAST_MIN_RELIABILITY,
    SPOT_EVENT_FAST_TARGET_MIN_5M_PERCENT,
    SPOT_EVENT_FAST_TARGET_MAX_5M_PERCENT,
    SPOT_EVENT_FAST_MIN_VOLUME_RATIO,
    SPOT_EVENT_FAST_BENCHMARK_MIN_CONFIRMATIONS,
    SPOT_EVENT_FAST_BENCHMARK_MIN_5M_PERCENT,
    SPOT_EVENT_FAST_TIME_EXIT_HOURS,
    SPOT_EVENT_FAST_COOLDOWN_MINUTES,
)
from config.runtime import (
    CORE_LAB_PROFILE, CORE_LAB_SYMBOLS, LIVE_ANALYSIS_MODE,
    resolve_runtime_config,
)
from data_engine.symbol_provider import SymbolProvider
from investment.analysis_engine import SpotInvestmentEngine
from investment.capital_recycling import (
    CapitalRecyclingEngine,
    reserve_policy_for_macro,
)
from investment.decision_trace import (
    BUY_DECISIONS,
    build_decision_trace,
    normalize_execution_reason,
)
from investment.deterioration_guard import (
    DeteriorationGuard,
    GuardDecision,
    LOSS_REDUCE_REENTRY_WAIT,
    LOSS_REDUCE_THESIS_RECOVERED,
    MemoryGuardStateStore,
    build_deterioration_snapshot,
)
from investment.event_watch import EventWatchConfig, EventWatchEngine, EventWatchState
from investment.models import PositionState
from investment.spot_event_fast_entry import FastEventPolicy, SpotEventFastEntryEngine
from portfolio.journal import PortfolioJournal
from portfolio.paper_broker import PaperBroker
from portfolio.shadow_journal import ShadowOpportunityJournal
from portfolio.event_momentum_journal import EventMomentumJournal
from portfolio.execution_guard_journal import (
    ExecutionGuardJournal,
    execution_guard_path_for_portfolio,
)
from utils.logger import logger

ProgressCallback = Callable[[dict], object]


class AutonomousPaperPortfolio:
    """Runs one autonomous paper cycle at a time and exposes live progress.

    The lock is shared by manual Telegram cycles and the periodic AUTO loop, so two
    scans cannot overlap. The time limit is cooperative: it is checked between
    symbols. Individual HTTP calls remain bounded by the providers' request timeout.
    """

    def __init__(
        self,
        engine: SpotInvestmentEngine | None = None,
        journal: PortfolioJournal | None = None,
        broker: PaperBroker | None = None,
        symbol_provider: SymbolProvider | None = None,
        shadow_journal: ShadowOpportunityJournal | None = None,
        event_momentum_journal: EventMomentumJournal | None = None,
    ):
        self.engine = engine or SpotInvestmentEngine()
        self.journal = journal or PortfolioJournal()
        self.broker = broker or PaperBroker(self.journal)
        self.execution_guard_journal = ExecutionGuardJournal(
            execution_guard_path_for_portfolio(self.journal.path)
        )
        self.execution_guard = DeteriorationGuard(self.execution_guard_journal)
        self.symbol_provider = symbol_provider or SymbolProvider()
        self.capital_recycling_engine = CapitalRecyclingEngine()
        if shadow_journal is None:
            journal_path = Path(self.journal.path)
            if journal_path.resolve() == Path(PORTFOLIO_DB_PATH).resolve():
                shadow_path = SHADOW_DB_PATH
            else:
                shadow_path = journal_path.with_name(
                    f"{journal_path.stem}_shadow{journal_path.suffix or '.sqlite3'}"
                )
            shadow_journal = ShadowOpportunityJournal(shadow_path)
        self.shadow_journal = shadow_journal
        if event_momentum_journal is None:
            journal_path = Path(self.journal.path)
            if journal_path.resolve() == Path(PORTFOLIO_DB_PATH).resolve():
                event_path = EVENT_MOMENTUM_DB_PATH
            else:
                event_path = journal_path.with_name(
                    f"{journal_path.stem}_event_momentum{journal_path.suffix or '.sqlite3'}"
                )
            event_momentum_journal = EventMomentumJournal(event_path)
        self.event_momentum_journal = event_momentum_journal
        self.event_watch_engine = EventWatchEngine(EventWatchConfig(
            confirmations_required=EVENT_CONFIRMATIONS_REQUIRED,
            duration_minutes=EVENT_WATCH_DURATION_MINUTES,
            max_chase_atr_multiple=EVENT_MAX_CHASE_ATR_MULTIPLE,
            max_chase_percent=EVENT_MAX_CHASE_PERCENT,
            retest_tolerance_atr_multiple=EVENT_RETEST_TOLERANCE_ATR_MULTIPLE,
            sharp_rejection_percent=EVENT_SHARP_REJECTION_PERCENT,
            max_additional_tranches=EVENT_MAX_ADDITIONAL_TRANCHES,
            tranche_cooldown_minutes=EVENT_TRANCHE_COOLDOWN_MINUTES,
            dynamic_base_enabled=EVENT_DYNAMIC_BASE_ENABLED,
            micro_pullback_enabled=EVENT_MICRO_PULLBACK_ENABLED,
            require_retest_after_dynamic_base=EVENT_DYNAMIC_BASE_REQUIRE_RETEST,
            minimum_consolidation_minutes=EVENT_MIN_CONSOLIDATION_MINUTES,
            minimum_base_quality=EVENT_MIN_BASE_QUALITY,
            max_anchor_resets=EVENT_MAX_ANCHOR_RESETS,
            anchor_reset_cooldown_minutes=EVENT_ANCHOR_RESET_COOLDOWN_MINUTES,
            max_duration_minutes=EVENT_MAX_WATCH_DURATION_MINUTES,
            extension_minutes=EVENT_WATCH_EXTENSION_MINUTES,
            max_base_range_atr=EVENT_MAX_BASE_RANGE_ATR,
            range_compression_max_ratio=EVENT_RANGE_COMPRESSION_MAX_RATIO,
            base_volume_contraction_max_ratio=EVENT_BASE_VOLUME_CONTRACTION_MAX_RATIO,
            base_volume_floor_ratio=EVENT_BASE_VOLUME_FLOOR_RATIO,
            base_breakout_buffer_atr=EVENT_BASE_BREAKOUT_BUFFER_ATR,
            max_total_extension_atr=EVENT_MAX_TOTAL_EXTENSION_ATR,
            max_total_extension_percent=EVENT_MAX_TOTAL_EXTENSION_PERCENT,
            micro_pullback_min_atr=EVENT_MICRO_PULLBACK_MIN_ATR,
            micro_pullback_max_atr=EVENT_MICRO_PULLBACK_MAX_ATR,
        ))
        self.fast_event_engine = SpotEventFastEntryEngine(FastEventPolicy(
            allocation_percent=SPOT_EVENT_FAST_ENTRY_ALLOCATION_PERCENT,
            asset_news_max_age_minutes=SPOT_EVENT_FAST_ASSET_NEWS_MAX_AGE_MINUTES,
            macro_news_max_age_minutes=SPOT_EVENT_FAST_MACRO_NEWS_MAX_AGE_MINUTES,
            min_reliability=SPOT_EVENT_FAST_MIN_RELIABILITY,
            target_min_return_5m_percent=SPOT_EVENT_FAST_TARGET_MIN_5M_PERCENT,
            target_max_return_5m_percent=SPOT_EVENT_FAST_TARGET_MAX_5M_PERCENT,
            target_min_volume_ratio=SPOT_EVENT_FAST_MIN_VOLUME_RATIO,
            benchmark_min_confirmations=SPOT_EVENT_FAST_BENCHMARK_MIN_CONFIRMATIONS,
            benchmark_min_return_5m_percent=SPOT_EVENT_FAST_BENCHMARK_MIN_5M_PERCENT,
            time_exit_hours=SPOT_EVENT_FAST_TIME_EXIT_HOURS,
            cooldown_minutes=SPOT_EVENT_FAST_COOLDOWN_MINUTES,
        ))
        self._last_event_universe = list(self.fast_event_engine.policy.benchmark_symbols)
        self._event_watch_lock = threading.Lock()
        self._cycle_lock = threading.Lock()
        self._status_lock = threading.Lock()
        self._cycle_state: dict = {
            "running": False,
            "stage": "IDLE",
            "processed": 0,
            "total": 0,
            "current_symbol": None,
            "started_at": None,
            "elapsed_seconds": 0,
            "errors": 0,
            "cycle_id": None,
            "last_cycle_at": None,
            "next_cycle_at": None,
        }

    def _guard_service(self) -> DeteriorationGuard:
        guard = getattr(self, "execution_guard", None)
        if guard is None:
            # Isolated tests sometimes build this class with ``__new__``.
            # Production always installs the restart-safe sidecar in __init__.
            guard = DeteriorationGuard(MemoryGuardStateStore())
            self.execution_guard = guard
        return guard

    @staticmethod
    def _paper_action_status(action) -> str:
        if isinstance(action, dict):
            return str(action.get("status") or "")
        return str(getattr(action, "status", "") or "")

    def cycle_status(self) -> dict:
        with self._status_lock:
            state = dict(self._cycle_state)
        if state.get("running") and state.get("started_monotonic"):
            state["elapsed_seconds"] = round(
                time.monotonic() - float(state["started_monotonic"]), 1
            )
        state.pop("started_monotonic", None)
        return state

    def is_running(self) -> bool:
        return bool(self.cycle_status().get("running"))

    def _update_state(self, callback: ProgressCallback | None = None, **changes) -> None:
        with self._status_lock:
            self._cycle_state.update(changes)
            payload = dict(self._cycle_state)
        payload.pop("started_monotonic", None)
        if callback:
            try:
                callback(payload)
            except Exception:
                # A UI callback must never break the investment cycle.
                pass

    def _price(self, symbol: str) -> float:
        return float(self.engine.market_data.get_current_price(symbol))

    def _snapshot_prices(self, include_pending: bool = False) -> dict[str, float]:
        symbols = [position.symbol for position in self.journal.positions()]
        # NEWS/EVENT trades are tracked in a separate sleeve journal. Include them
        # explicitly so stop/TP/time exits keep working even if the aggregate paper
        # position representation changes later.
        symbols.extend(item["symbol"] for item in self.event_momentum_journal.open_trades())
        if include_pending:
            symbols.extend(order["symbol"] for order in self.journal.pending_orders())
        prices = {}
        for symbol in dict.fromkeys(symbols):
            try:
                prices[symbol] = self._price(symbol)
            except (RuntimeError, KeyError):
                continue
        return prices

    @staticmethod
    def _fundamentals_execution_gate(symbol: str, analysis: dict) -> dict:
        """Normalize fundamentals availability without treating missing data as bad data."""
        symbol = str(symbol or "").upper()
        fundamental = analysis.get("fundamental") or {}
        raw_status = str(fundamental.get("status") or "UNAVAILABLE").strip().upper()
        explicitly_negative = bool(fundamental.get("blocked")) or raw_status in {
            "NEGATIVE", "FUNDAMENTALS_NEGATIVE",
        }
        if explicitly_negative:
            fundamentals_status = "NEGATIVE"
        elif raw_status in {"", "UNAVAILABLE", "UNKNOWN", "PARTIAL"}:
            fundamentals_status = "UNKNOWN"
        else:
            fundamentals_status = raw_status

        is_core = symbol in {"BTCUSDT", "ETHUSDT"}
        evaluated = bool(AUTO_REQUIRE_FUNDAMENTALS_FOR_ALTCOINS and not is_core)
        soft_gate = bool(evaluated and fundamentals_status == "UNKNOWN")
        blocked = bool(evaluated and fundamentals_status == "NEGATIVE")
        if is_core:
            reason = "core_asset"
        elif not AUTO_REQUIRE_FUNDAMENTALS_FOR_ALTCOINS:
            reason = "fundamentals_optional"
        elif blocked:
            reason = "fundamentals_negative"
        elif soft_gate:
            reason = "fundamentals_unknown_soft_gate"
        else:
            reason = "fundamentals_available"
        return {
            "evaluated": evaluated,
            "pass": not blocked,
            "reason": reason,
            "raw_status": raw_status,
            "fundamentals_status": fundamentals_status,
            "fundamentals_unavailable_soft_gate": soft_gate,
        }

    @classmethod
    def _buy_context_ready(cls, symbol: str, analysis: dict) -> tuple[bool, str]:
        gate = cls._fundamentals_execution_gate(symbol, analysis)
        return bool(gate["pass"]), str(gate["reason"])

    def _revalidate_pending_buy(
        self, order: dict, analysis: dict, current_price: float,
    ) -> tuple[bool, str]:
        """Re-apply the current production BUY gates before a stored zone may fill."""
        symbol = str(order.get("symbol") or analysis.get("symbol") or "").upper()
        if str(analysis.get("decision") or "") not in BUY_DECISIONS:
            return False, "pending_buy_signal_no_longer_active"
        ready, why = self._buy_context_ready(symbol, analysis)
        if not ready:
            return False, f"pending_buy_context_blocked:{why}"
        fundamentals_gate = self._fundamentals_execution_gate(symbol, analysis)
        metadata = order.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
            order["metadata"] = metadata
        metadata.update({
            "fundamentals_status": fundamentals_gate["fundamentals_status"],
            "fundamentals_unavailable_soft_gate": fundamentals_gate[
                "fundamentals_unavailable_soft_gate"
            ],
        })
        reentry = self._guard_service().evaluate_reentry(symbol, analysis)
        metadata["loss_reduce_reentry_guard"] = {
            "reason": reentry.reason, **reentry.details,
        }
        metadata["deterioration_snapshot"] = build_deterioration_snapshot(analysis)
        if not reentry.allowed:
            return False, LOSS_REDUCE_REENTRY_WAIT
        zones = (analysis.get("accumulation_plan") or {}).get("zones") or []
        current_zone = next(
            (item for item in zones if float(item.get("amount_usdt") or 0) > 0), None
        )
        if current_zone is None:
            return False, "pending_buy_no_current_entry_zone"
        lower = float(order.get("lower_price") or 0)
        upper = float(order.get("upper_price") or 0)
        if lower <= float(current_price) <= upper:
            liquidity_assessor = getattr(
                getattr(self, "engine", None), "assess_live_liquidity", None
            )
            if callable(liquidity_assessor):
                liquidity = liquidity_assessor(
                    symbol, float(order.get("amount_usdt") or 0)
                )
                metadata["liquidity_revalidation"] = liquidity
                if bool(
                    liquidity.get(
                        "hard_block", liquidity.get("liquidity_status", "LOW") == "LOW"
                    )
                ):
                    return False, (
                        "pending_buy_liquidity_low:"
                        f"{liquidity.get('reason') or 'LIQUIDITY_LOW'}"
                    )
            current_lower = float(current_zone.get("lower") or 0)
            current_upper = float(current_zone.get("upper") or 0)
            if not current_lower <= float(current_price) <= current_upper:
                return False, "pending_buy_price_outside_current_entry_zone"
            if float(order.get("amount_usdt") or 0) > float(current_zone.get("amount_usdt") or 0) + 1e-8:
                return False, "pending_buy_current_capacity_reduced"
        return True, "pending_buy_revalidated"

    def _record_pending_reentry_fill(self, payload: dict) -> None:
        if str(payload.get("action") or "") != "BUY" or str(
            payload.get("status") or ""
        ) != "FILLED":
            return
        details = payload.get("details") or {}
        guard = details.get("loss_reduce_reentry_guard") or {}
        if guard.get("reason") != LOSS_REDUCE_THESIS_RECOVERED:
            return
        decision = GuardDecision(
            True, LOSS_REDUCE_THESIS_RECOVERED,
            {key: value for key, value in guard.items() if key != "reason"},
        )
        self._guard_service().record_buy_fill(str(payload.get("symbol") or ""), decision)

    def effective_runtime_config(
        self, *, universe_limit: int | None = None,
        candidate_limit: int | None = None,
        interval_seconds: int | None = None,
    ) -> dict:
        return resolve_runtime_config(
            self.journal,
            universe_limit=universe_limit,
            candidate_limit=candidate_limit,
            interval_seconds=interval_seconds,
        ).to_dict()

    def _apply_effective_risk_config(self, runtime_config: dict) -> None:
        risk_manager = getattr(self.engine, "risk_manager", None)
        if risk_manager is None:
            return
        risk_manager.capital_usdt = float(runtime_config["capital_usdt_effective"])
        risk_manager.max_open_ideas = int(runtime_config["max_open_ideas_effective"])

    def _save_analysis_evaluation(
        self, cycle_id: str, analysis: dict, analysis_id: int,
        position_exists: bool,
    ) -> None:
        trace = build_decision_trace(
            analysis, position_exists=position_exists,
            policy=getattr(getattr(self.engine, "decision_engine", None), "policy", None),
        )
        fundamentals_gate = self._fundamentals_execution_gate(
            analysis["symbol"], analysis
        )
        trace["gates"]["altcoin_fundamental_execution"] = {
            "evaluated": fundamentals_gate["evaluated"],
            "pass": fundamentals_gate["pass"],
            "status": fundamentals_gate["fundamentals_status"],
            "raw_status": fundamentals_gate["raw_status"],
            "fundamentals_status": fundamentals_gate["fundamentals_status"],
            "fundamentals_unavailable_soft_gate": fundamentals_gate[
                "fundamentals_unavailable_soft_gate"
            ],
        }
        quality = analysis.get("data_quality") or {}
        committee = analysis.get("committee") or {}
        self.journal.upsert_decision_evaluation(
            cycle_id,
            analysis["symbol"],
            self._analysis_mode(),
            analysis_id=analysis_id,
            eligibility="ELIGIBLE",
            evaluation_status="EVALUATED",
            data_completeness=quality.get("technical_completeness_percent"),
            candidate_score=analysis.get("score"),
            base_score=committee.get("base_score", analysis.get("score")),
            final_score=analysis.get("score"),
            base_decision=trace["base_decision"],
            final_decision=trace["final_decision"],
            primary_reason=trace["primary_reason"],
            secondary_reasons_json=trace["secondary_reasons"],
            context_snapshot_ref=f"analysis:{analysis_id}",
            score_components_json=trace["score_components"],
            gate_results_json=trace["gates"],
            data_quality_json=quality,
            payload_json=analysis,
        )

    def _save_shadow_near_miss(
        self, cycle_id: str, analysis: dict, rejected_reason: str,
    ) -> None:
        zones = (analysis.get("accumulation_plan") or {}).get("zones") or []
        allocation = next(
            (float(item.get("amount_usdt") or 0) for item in zones if float(item.get("amount_usdt") or 0) > 0),
            None,
        )
        self.shadow_journal.save_near_miss(
            cycle_id=cycle_id,
            symbol=analysis["symbol"],
            decision_timestamp=(analysis.get("data_quality") or {}).get(
                "decision_as_of_utc", datetime.now(timezone.utc).isoformat()
            ),
            decision=analysis.get("decision", "WAIT"),
            observed_entry_price=analysis.get("current_price"),
            hypothetical_allocation_usdt=allocation,
            context={
                "score": analysis.get("score"),
                "primary_decision_reason": build_decision_trace(
                    analysis, policy=getattr(getattr(self.engine, "decision_engine", None), "policy", None)
                )["primary_reason"],
                "mode": self._analysis_mode(),
            },
            rejected_reason=rejected_reason,
        )

    def _save_event_momentum_candidate(self, cycle_id: str, analysis: dict) -> None:
        event = analysis.get("event_momentum") or {}
        if event.get("status") in {"NEWS_EVENT_BUY_CANDIDATE", "SHADOW_STARTER_CANDIDATE"}:
            self.event_momentum_journal.save_candidate(cycle_id=cycle_id, analysis=analysis)

    def _measure_due_event_momentum(self, limit: int = 20) -> dict:
        measured = 0
        path_measured = 0
        errors = 0
        now = datetime.now(timezone.utc)
        try:
            due = self.event_momentum_journal.due(now=now, limit=limit)
        except Exception:
            return {"due": 0, "measured": 0, "path_measured": 0, "errors": 1}
        for item in due:
            try:
                symbol = str(item["symbol"]).upper()
                decision_time = self.event_momentum_journal._parse_time(item["decision_timestamp"])
                checkpoint = item.get("next_checkpoint_hours")
                if checkpoint is not None:
                    target = decision_time + timedelta(hours=int(checkpoint))
                    price = float(self.engine.market_data.get_price_at(
                        symbol, int(target.timestamp() * 1000), interval="1m"
                    ))
                    self.event_momentum_journal.record_checkpoint(
                        int(item["id"]), checkpoint_hours=int(checkpoint), price=price,
                        observed_at=target.isoformat(),
                    )
                    measured += 1
                if item.get("need_path_metrics"):
                    start_ms = int(decision_time.timestamp() * 1000)
                    end_ms = int((decision_time + timedelta(hours=72)).timestamp() * 1000)
                    candles = self.engine.market_data.get_historical_klines(
                        symbol, "1h", start_ms, end_ms
                    )
                    if candles:
                        self.event_momentum_journal.record_path_metrics(
                            int(item["id"]),
                            max_price=max(float(c["high"]) for c in candles),
                            min_price=min(float(c["low"]) for c in candles),
                            observed_at=(decision_time + timedelta(hours=72)).isoformat(),
                        )
                        path_measured += 1
            except Exception:
                errors += 1
        return {"due": len(due), "measured": measured, "path_measured": path_measured, "errors": errors}

    def _measure_due_shadow_outcomes(self, limit: int = 20) -> dict:
        """Measure rejected opportunities at their intended historical checkpoint.

        A delayed AUTO cycle must not stamp the *current* market price onto a 24h/7d/30d
        checkpoint.  The target timestamp is reconstructed from the saved decision time and
        read from a fully closed one-minute candle, preserving the observational nature of
        the shadow journal without contaminating it with a late price.
        """
        measured = 0
        errors = 0
        try:
            due = self.shadow_journal.due_for_outcome(limit=limit)
        except Exception:
            return {"due": 0, "measured": 0, "errors": 1}
        for item in due:
            symbol = str(item.get("symbol") or "").upper()
            try:
                checkpoint_hours = int(item["next_checkpoint_hours"])
                target = self.shadow_journal._parse_time(item["decision_timestamp"]) + timedelta(
                    hours=checkpoint_hours
                )
                target_ms = int(target.timestamp() * 1000)
                price = float(
                    self.engine.market_data.get_price_at(symbol, target_ms, interval="1m")
                )
                self.shadow_journal.record_price_checkpoint(
                    int(item["id"]),
                    checkpoint_hours=checkpoint_hours,
                    price=price,
                    observed_at=datetime.now(timezone.utc).isoformat(),
                )
                measured += 1
            except Exception:
                errors += 1
        return {"due": len(due), "measured": measured, "errors": errors}

    def _event_open_quantity(self, symbol: str) -> float:
        return sum(
            float(item.get("remaining_quantity") or 0)
            for item in self.event_momentum_journal.open_trades(symbol)
        )

    def _production_position(self, symbol: str, current_price: float) -> PositionState:
        """Return the normal strategy sleeve without NEWS_EVENT contamination."""
        symbol = str(symbol).upper()
        aggregate = self.journal.position(symbol, current_price)
        try:
            logical_all, all_count = self.journal.paper_order_position(symbol, current_price)
            logical_production, _ = self.journal.paper_order_position(
                symbol, current_price, excluded_trade_types={"NEWS_EVENT"}
            )
        except (AttributeError, TypeError):
            logical_all, all_count, logical_production = aggregate, 0, aggregate
        tolerance = max(1e-10, abs(float(aggregate.quantity)) * 1e-8)
        if all_count > 0 and abs(float(logical_all.quantity) - float(aggregate.quantity)) <= tolerance:
            return logical_production

        event_qty = self._event_open_quantity(symbol)
        production_qty = max(0.0, float(aggregate.quantity) - event_qty)
        if production_qty <= 1e-12:
            return PositionState(symbol=symbol)
        if event_qty <= 1e-12:
            return aggregate
        average = float(aggregate.average_price or 0)
        invested = production_qty * average
        return PositionState(
            symbol=symbol, quantity=production_qty, average_price=average,
            invested_usdt=invested, current_value_usdt=production_qty * float(current_price),
        )

    def _production_quantity(self, symbol: str, current_price: float) -> float:
        return max(0.0, float(self._production_position(symbol, current_price).quantity))

    def _production_positions(self, prices: dict[str, float] | None = None) -> list[PositionState]:
        prices = prices or {}
        output: list[PositionState] = []
        for aggregate in self.journal.positions(prices):
            current_price = float(prices.get(aggregate.symbol) or 0)
            if current_price <= 0 and aggregate.quantity > 0:
                current_price = float(aggregate.current_value_usdt or 0) / float(aggregate.quantity)
            position = self._production_position(aggregate.symbol, current_price)
            if position.exists:
                output.append(position)
        return output

    def _profile_runtime(self) -> dict:
        return self.effective_runtime_config()

    def _analysis_mode(self) -> str:
        return str(self._profile_runtime().get("analysis_mode") or LIVE_ANALYSIS_MODE)

    def _new_event_entries_enabled(self) -> bool:
        return bool(self._profile_runtime().get("new_event_entries_enabled", True))

    def _capital_recycling_enabled(self) -> bool:
        return bool(self._profile_runtime().get("capital_recycling_enabled", True))

    def _profile_allows_new_buy(self, symbol: str) -> bool:
        allowed = tuple(self._profile_runtime().get("new_buy_symbols") or ())
        return not allowed or str(symbol).upper() in set(allowed)

    def _estimate_equity(self, positions=None) -> float:
        positions = positions if positions is not None else self.journal.positions()
        total_value = sum(
            float(item.current_value_usdt or item.invested_usdt or 0) for item in positions
        )
        return max(0.0, float(self.journal.cash_balance()) + total_value)

    def _handle_capital_recycling(
        self, analysis: dict, analysis_id: int, current_price: float, equity_usdt: float,
    ) -> dict | None:
        if not CAPITAL_RECYCLING_ENABLED or not self._capital_recycling_enabled():
            return None
        symbol = str(analysis.get("symbol") or "").upper()
        production_quantity = self._production_quantity(symbol, current_price)
        if production_quantity <= 0:
            # Do not carry an old peak/ladder into a future newly-opened position.
            state = self.journal.recycling_state(symbol)
            if (
                float(state.get("peak_price") or 0) > 0
                or int(state.get("harvest_stage") or 0) > 0
                or int(state.get("weakness_stage") or 0) > 0
            ):
                self.journal.update_recycling_state(
                    symbol, peak_price=0.0, peak_at=None, harvest_stage=0,
                    weakness_stage=0, harvest_reference_quantity=0.0,
                    last_harvest_price=None, last_weakness_buy_price=None,
                )
            return None
        self._guard_service().observe_analysis(
            symbol, analysis, position_exists=True,
        )
        # Frozen baseline hard exits/reductions keep priority over the overlay.
        if str(analysis.get("decision") or "") in {"EXIT_ON_RISK", "REDUCE", "TAKE_PROFIT"}:
            return None

        state = self.journal.observe_recycling_price(symbol, current_price)
        production_position = self._production_position(symbol, current_price)
        signal = self.capital_recycling_engine.assess(
            analysis=analysis,
            current_price=current_price,
            position_pnl_percent=float(production_position.pnl_percent or 0),
            state=state,
        )
        if signal.action == "NONE":
            return None

        common = {
            "trade_type": "CAPITAL_RECYCLING",
            "recycling_action": signal.action,
            "recycling_stage": signal.stage,
            "recycling_signal": signal.to_dict(),
            "reserve_target_percent": signal.reserve_target_percent,
            "hard_floor_percent": signal.hard_floor_percent,
            "reserve_base_usdt": round(float(equity_usdt), 8),
            "strategy_version": "4.8.0+CAPITAL_RECYCLING_V1",
            "reasons": signal.reasons,
            "risks": analysis.get("risks") or [],
            "score": analysis.get("score"),
            "horizon": analysis.get("horizon"),
            "take_profit_plan": analysis.get("take_profit_plan") or {},
            "deterioration_snapshot": build_deterioration_snapshot(analysis),
        }

        if signal.action == "HARVEST_PROFIT":
            reference = float(state.get("harvest_reference_quantity") or 0)
            if reference <= 0:
                reference = production_quantity
            quantity = min(
                production_quantity, reference * float(signal.sell_percent) / 100.0
            )
            if quantity <= 0:
                return None
            reason = (
                f"HARVEST_PROFIT stage {signal.stage}: "
                + "; ".join(signal.reasons[:4])
            )
            action = self.broker.sell(
                symbol, quantity, current_price, reason, analysis_id, common,
                require_positive_net=True, cost_basis_price=production_position.average_price,
            )
            payload = action.to_dict() if hasattr(action, "to_dict") else dict(action)
            if payload.get("status") == "FILLED":
                split = self.journal.add_recycling_proceeds(
                    symbol, float(payload.get("amount_usdt") or 0),
                    rebuy_share_percent=RECYCLE_REBUY_SHARE_PERCENT,
                    opportunity_share_percent=RECYCLE_OPPORTUNITY_SHARE_PERCENT,
                    retained_share_percent=RECYCLE_RETAINED_SHARE_PERCENT,
                )
                details = payload.setdefault("details", {})
                details["proceeds_split"] = split
                details["harvest_reference_quantity"] = reference
                average = float(production_position.average_price or 0)
                peak = float(signal.peak_price or current_price)
                capture = None
                if average > 0 and peak > average:
                    max_gain = peak / average - 1.0
                    sold_gain = float(payload.get("price") or current_price) / average - 1.0
                    capture = max(0.0, min(100.0, sold_gain / max_gain * 100.0))
                    details["peak_capture_percent"] = round(capture, 2)
                self.journal.update_recycling_state(
                    symbol,
                    harvest_stage=signal.stage,
                    harvest_reference_quantity=reference,
                    last_harvest_price=float(payload.get("price") or current_price),
                )
                self.journal.add_recycling_event(
                    symbol, "HARVEST_PROFIT", stage=signal.stage,
                    price=float(payload.get("price") or current_price),
                    quantity=float(payload.get("quantity") or quantity),
                    amount_usdt=float(payload.get("amount_usdt") or 0),
                    pnl_percent=signal.pnl_percent,
                    metadata={**details, "peak_price": signal.peak_price},
                )
                if self._production_quantity(symbol, current_price) <= 1e-12:
                    self._guard_service().reset(symbol, "FULL_CAPITAL_RECYCLING_CLOSE")
            return payload

        if signal.action == "ACCUMULATE_ON_WEAKNESS":
            if str(analysis.get("decision") or "") in BUY_DECISIONS:
                return None
            # This is a ladder allocation based on total current portfolio equity.
            # It is independently capped by asset capacity and the dynamic cash
            # reserve, so the bot cannot spend the whole wallet on a falling asset.
            desired = max(0.0, float(equity_usdt) * signal.buy_percent_of_portfolio / 100.0)
            risk = analysis.get("risk") or {}
            capacity = risk.get("remaining_capacity_before_context_usdt")
            if capacity is None:
                capacity = risk.get("remaining_capacity_usdt")
            try:
                desired = min(desired, max(0.0, float(capacity)))
            except (TypeError, ValueError):
                pass
            reserve_cash = max(0.0, float(equity_usdt) * signal.reserve_target_percent / 100.0)
            spendable_cash = max(0.0, float(self.journal.available_cash()) - reserve_cash)
            amount = min(desired, spendable_cash)
            if amount < 5.0:
                return {
                    "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                    "amount_usdt": round(max(0.0, amount), 8),
                    "reason": "dynamic_cash_reserve_or_asset_capacity_blocks_weakness_buy",
                    "details": common,
                }
            reason = (
                f"ACCUMULATE_ON_WEAKNESS stage {signal.stage}: "
                + "; ".join(signal.reasons[:4])
            )
            reentry = self._guard_service().evaluate_reentry(symbol, analysis)
            common["loss_reduce_reentry_guard"] = {
                "reason": reentry.reason, **reentry.details,
            }
            if not reentry.allowed:
                return {
                    "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                    "amount_usdt": round(max(0.0, amount), 8),
                    "reason": reentry.reason, "details": common,
                }
            action = self.broker.buy(
                symbol, amount, current_price, reason, analysis_id, common,
                reserve_floor_percent=signal.reserve_target_percent,
                reserve_base_usdt=equity_usdt,
                bypass_cooldown=True,
                enforce_post_sell_rebuy_guard=True,
            )
            payload = action.to_dict() if hasattr(action, "to_dict") else dict(action)
            if payload.get("status") == "FILLED":
                self._guard_service().record_buy_fill(symbol, reentry)
                pool_usage = self.journal.consume_recycling_pools(
                    symbol, float(payload.get("amount_usdt") or amount)
                )
                details = payload.setdefault("details", {})
                details["pool_usage"] = pool_usage
                self.journal.update_recycling_state(
                    symbol,
                    weakness_stage=signal.stage,
                    last_weakness_buy_price=float(payload.get("price") or current_price),
                    # A new accumulation tranche begins a fresh future harvest ladder.
                    harvest_stage=0,
                    harvest_reference_quantity=0.0,
                )
                self.journal.add_recycling_event(
                    symbol, "ACCUMULATE_ON_WEAKNESS", stage=signal.stage,
                    price=float(payload.get("price") or current_price),
                    quantity=float(payload.get("quantity") or 0),
                    amount_usdt=float(payload.get("amount_usdt") or amount),
                    pnl_percent=signal.pnl_percent,
                    metadata={**details, "peak_price": signal.peak_price},
                )
            return payload
        return None

    def _event_allocation(self, analysis: dict) -> tuple[float, float, dict]:
        """Return executable USDT, actual initial-capital %, and allocation diagnostics."""
        event = analysis.get("event_momentum") or {}
        initial = max(0.0, float(self.journal.initial_capital()))
        pool_cap = initial * float(EVENT_CAPITAL_POOL_PERCENT) / 100.0
        pool_used = float(self.event_momentum_journal.open_allocation_usdt())
        pool_remaining = max(0.0, pool_cap - pool_used)
        requested_percent = min(
            float(event.get("starter_percent") or 0),
            float(EVENT_MAX_SINGLE_TRADE_PERCENT),
        )
        allocation_base = str(event.get("allocation_base") or "INITIAL_CAPITAL")
        equity_now = max(0.0, self._estimate_equity())
        base_equity = equity_now if allocation_base == "CURRENT_EQUITY" else initial
        desired = base_equity * requested_percent / 100.0
        risk = analysis.get("risk") or {}
        asset_capacity = risk.get("remaining_capacity_before_context_usdt")
        if asset_capacity is None:
            asset_capacity = risk.get("remaining_capacity_usdt")
        try:
            asset_capacity = max(0.0, float(asset_capacity))
        except (TypeError, ValueError):
            asset_capacity = desired
        # A minute watch may execute after the hourly analysis. Reconcile the
        # stale analysis capacity with current paper equity/position before every
        # tranche so staged entries cannot exceed the normal per-asset cap.
        symbol = str(analysis.get("symbol") or "").upper()
        current_price = float(analysis.get("current_price") or 0)
        max_asset_percent = float(
            getattr(getattr(self.engine, "risk_manager", None), "max_single_asset_percent", 20.0)
        )
        current_asset_value = float(
            self.journal.position(symbol, current_price).current_value_usdt or 0
        ) if symbol and current_price > 0 else 0.0
        live_asset_capacity = max(0.0, equity_now * max_asset_percent / 100.0 - current_asset_value)
        asset_capacity = min(asset_capacity, live_asset_capacity)
        cash = max(0.0, float(self.journal.available_cash()))
        amount = max(0.0, min(desired, pool_remaining, asset_capacity, cash))
        actual_percent = (amount / initial * 100.0) if initial > 0 else 0.0
        return amount, actual_percent, {
            "event_pool_cap_usdt": round(pool_cap, 8),
            "event_pool_used_before_usdt": round(pool_used, 8),
            "event_pool_remaining_before_usdt": round(pool_remaining, 8),
            "requested_percent": round(requested_percent, 4),
            "allocation_base": allocation_base,
            "base_equity_usdt": round(base_equity, 8),
            "current_equity_percent": round(amount / equity_now * 100.0, 4) if equity_now > 0 else 0.0,
            "asset_capacity_usdt": round(asset_capacity, 8),
            "live_asset_capacity_usdt": round(live_asset_capacity, 8),
            "cash_before_usdt": round(cash, 8),
        }

    def _start_event_watch(
        self, cycle_id: str, analysis: dict, analysis_id: int,
    ) -> dict:
        event = analysis.get("event_momentum") or {}
        plan = event.get("trade_plan") or {}
        timestamp = (analysis.get("data_quality") or {}).get("decision_as_of_utc")
        try:
            discovered = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
            if discovered.tzinfo is None:
                discovered = discovered.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            discovered = datetime.now(timezone.utc)
        discovered_ms = int(discovered.timestamp() * 1000)
        price = float(analysis.get("current_price") or 0)
        state = self.event_watch_engine.discover(
            symbol=str(analysis.get("symbol") or ""),
            event_type=str(event.get("event_type") or "MARKET_MOMENTUM_EVENT"),
            discovered_at_ms=discovered_ms,
            breakout_price=float(plan.get("breakout_price") or (event.get("metrics") or {}).get("prior_24h_high") or price),
            reference_price=float(plan.get("reference_price") or price),
            atr_price=float(plan.get("atr_price") or max(price * 0.02, 1e-12)),
            overbought=bool(event.get("overbought_exception")),
            entry_scale=float(event.get("entry_scale") or 1.0),
        )
        watch = self.event_momentum_journal.start_watch(
            cycle_id=cycle_id, analysis_id=analysis_id, analysis=analysis,
            state=state.to_dict(),
        )
        return {
            "action": "WATCH",
            "symbol": str(analysis.get("symbol") or "").upper(),
            "status": "STARTED",
            "reason": str(event.get("status") or "EVENT_CONFIRMATION_REQUIRED"),
            "details": {
                "trade_type": "NEWS_EVENT",
                "event_watch_id": int(watch["id"]),
                "event_type": state.event_type,
                "event_score": int(event.get("score") or 0),
                "event_factors": event.get("factors") or [],
                "confirmations_required": EVENT_CONFIRMATIONS_REQUIRED,
                "watch_interval_seconds": EVENT_WATCH_INTERVAL_SECONDS,
                "watch_duration_minutes": EVENT_WATCH_DURATION_MINUTES,
                "watch_max_duration_minutes": EVENT_MAX_WATCH_DURATION_MINUTES,
                "overbought": state.overbought,
                "entry_scale": state.entry_scale,
                "dynamic_base_enabled": self.event_watch_engine.config.dynamic_base_enabled,
                "micro_pullback_enabled": self.event_watch_engine.config.micro_pullback_enabled,
                "retest_required": self.event_watch_engine.config.require_retest_after_dynamic_base,
            },
        }

    def _handle_event_momentum(
        self, cycle_id: str, analysis: dict, analysis_id: int, current_price: float,
    ) -> dict | None:
        event = analysis.get("event_momentum") or {}
        symbol = str(analysis.get("symbol") or "").upper()
        if not EVENT_PAPER_ENABLED:
            return None
        if not self._new_event_entries_enabled():
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_entries_frozen_by_strategy_profile",
                "details": {
                    "trade_type": "NEWS_EVENT",
                    "strategy_profile": self._profile_runtime().get("strategy_profile"),
                },
            }
        event_status = str(event.get("status") or "")
        accepted = {
            "NEWS_EVENT_BUY_CANDIDATE", "EVENT_OVERBOUGHT_REVIEW",
            "EVENT_CONFIRMATION_REQUIRED",
        }
        if event_status not in accepted:
            return None
        if analysis.get("decision") in {"EXIT_ON_RISK", "REDUCE", "TAKE_PROFIT", "AVOID"}:
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_conflicts_with_production_risk_decision",
                "details": {"trade_type": "NEWS_EVENT", "event_score": event.get("score")},
            }
        # If the normal strategy already wants to buy, an additional event fill would
        # contaminate attribution. Keep the event observation, but let production own it.
        if analysis.get("decision") in BUY_DECISIONS:
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_overlaps_production_buy",
                "details": {"trade_type": "NEWS_EVENT", "event_score": event.get("score")},
            }
        if self.event_momentum_journal.has_open_trade(symbol):
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_trade_already_open",
                "details": {"trade_type": "NEWS_EVENT", "event_score": event.get("score")},
            }
        if event_status in {"EVENT_OVERBOUGHT_REVIEW", "EVENT_CONFIRMATION_REQUIRED"}:
            return self._start_event_watch(cycle_id, analysis, analysis_id)
        if not event.get("paper_execution_allowed"):
            return None
        amount, actual_percent, allocation_meta = self._event_allocation(analysis)
        if amount <= 0 or actual_percent < 0.25:
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_capital_pool_or_asset_capacity_exhausted",
                "details": {"trade_type": "NEWS_EVENT", **allocation_meta},
            }
        news_items = event.get("verified_news") or []
        headline = str((news_items[0] if news_items else {}).get("title") or "подтверждённый новостной катализатор")
        reason = (
            f"NEWS/EVENT paper buy: {headline}; event score {int(event.get('score') or 0)}/100; "
            "импульс, пробой и объём подтверждены"
        )
        metadata = {
            "trade_type": "NEWS_EVENT",
            "strategy_sleeve": "SPOT_EVENT_FAST_ENTRY_V1" if event.get("fast_entry") else "EVENT_MOMENTUM_V1",
            "event_score": int(event.get("score") or 0),
            "allocation_percent": round(actual_percent, 4),
            "event_pool_percent": float(EVENT_CAPITAL_POOL_PERCENT),
            "production_decision": analysis.get("decision"),
            "trade_plan": event.get("trade_plan") or {},
            "verified_news": news_items,
            "event_factors": event.get("factors") or [],
            **allocation_meta,
        }
        action = self.broker.buy(
            symbol, amount, current_price, reason, analysis_id, metadata,
            reserve_floor_percent=float(HARD_CASH_RESERVE_PERCENT),
            reserve_base_usdt=max(1.0, self._estimate_equity()),
        )
        payload = action.to_dict() if hasattr(action, "to_dict") else dict(action)
        if payload.get("status") == "FILLED":
            self.event_momentum_journal.record_open_trade(
                cycle_id=cycle_id,
                analysis_id=analysis_id,
                analysis=analysis,
                action=payload,
                allocation_percent=actual_percent,
            )
        return payload

    def _execute_event_watch_entry(
        self, watch: dict, result: dict, market_price: float,
    ) -> dict:
        analysis = dict(watch.get("analysis") or {})
        analysis["current_price"] = float(market_price)
        event = dict(analysis.get("event_momentum") or {})
        event["status"] = "NEWS_EVENT_BUY_CANDIDATE"
        event["paper_execution_allowed"] = True
        analysis["event_momentum"] = event
        symbol = str(watch.get("symbol") or analysis.get("symbol") or "").upper()
        action_name = str(result.get("action") or "ENTER")
        if analysis.get("decision") in {"EXIT_ON_RISK", "REDUCE", "TAKE_PROFIT", "AVOID"}:
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_conflicts_with_production_risk_decision",
                "details": {"trade_type": "NEWS_EVENT", "event_watch_id": watch.get("id")},
            }
        if action_name == "ENTER" and self.event_momentum_journal.has_open_trade(symbol):
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_trade_already_open",
                "details": {"trade_type": "NEWS_EVENT", "event_watch_id": watch.get("id")},
            }
        trades = self.event_momentum_journal.open_trades(symbol)
        if action_name == "ADD_TRANCHE" and not trades:
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_trade_not_open_for_additional_tranche",
                "details": {"trade_type": "NEWS_EVENT", "event_watch_id": watch.get("id")},
            }
        amount, actual_percent, allocation_meta = self._event_allocation(analysis)
        if amount <= 0 or actual_percent < 0.25:
            return {
                "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                "reason": "event_capital_pool_or_asset_capacity_exhausted",
                "details": {"trade_type": "NEWS_EVENT", "event_watch_id": watch.get("id"), **allocation_meta},
            }
        event_type = str(event.get("event_type") or "MARKET_MOMENTUM_EVENT")
        source_label = (
            "подтверждённого новостного события"
            if event_type == "VERIFIED_NEWS_EVENT"
            else "подтверждённого рынком импульса"
        )
        tranche_label = "дополнительный транш" if action_name == "ADD_TRANCHE" else "первый транш"
        state = result.get("state") or {}
        continuation_entry = str(state.get("entry_path") or "ORIGINAL_BREAKOUT") != "ORIGINAL_BREAKOUT"
        reason = (
            f"Событийная покупка: {source_label}; {tranche_label}; "
            + (
                "новая локальная база и продолжение подтверждены"
                if continuation_entry
                else "пробой и объём удерживаются"
            )
        )
        metadata = {
            "trade_type": "NEWS_EVENT",
            "strategy_sleeve": "EVENT_MOMENTUM_V2",
            "event_watch_id": int(watch["id"]),
            "event_type": event_type,
            "event_score": int(event.get("score") or 0),
            "event_exit": None,
            "event_tranche": int(state.get("tranche_count") or 1),
            "overbought": bool(state.get("overbought")),
            "entry_scale": float(state.get("entry_scale") or 1.0),
            "entry_path": str(state.get("entry_path") or "ORIGINAL_BREAKOUT"),
            "original_breakout_price": float(state.get("original_breakout_price") or 0),
            "dynamic_reference_price": float(state.get("breakout_price") or 0),
            "base_low": float(state.get("base_low") or 0),
            "base_high": float(state.get("base_high") or 0),
            "base_quality": float(state.get("base_quality") or 0),
            "anchor_reset_count": int(state.get("anchor_reset_count") or 0),
            "allocation_percent": round(actual_percent, 4),
            "trade_plan": event.get("trade_plan") or {},
            "watch_metrics": result.get("metrics") or {},
            "verified_news": event.get("verified_news") or [],
            "event_factors": event.get("factors") or [],
            **allocation_meta,
        }
        paper = self.broker.buy(
            symbol, amount, float(market_price), reason,
            analysis.get("_analysis_id") or watch.get("analysis_id"), metadata,
            reserve_floor_percent=float(HARD_CASH_RESERVE_PERCENT),
            reserve_base_usdt=max(1.0, self._estimate_equity()),
            bypass_cooldown=True,
        )
        payload = paper.to_dict() if hasattr(paper, "to_dict") else dict(paper)
        if payload.get("status") == "FILLED":
            observed_at = datetime.fromtimestamp(
                int((result.get("metrics") or {}).get("candle_close_ms") or 0) / 1000,
                tz=timezone.utc,
            ).isoformat()
            if action_name == "ADD_TRANCHE":
                self.event_momentum_journal.record_additional_tranche(
                    int(trades[0]["id"]), action=payload, watch_id=int(watch["id"]),
                    observed_at=observed_at,
                )
            else:
                analysis.setdefault("data_quality", {})["decision_as_of_utc"] = observed_at
                self.event_momentum_journal.record_open_trade(
                    cycle_id=str(watch.get("cycle_id") or f"watch-{watch['id']}"),
                    analysis_id=analysis.get("_analysis_id") or watch.get("analysis_id"),
                    analysis=analysis, action=payload, allocation_percent=actual_percent,
                )
        return payload

    def run_event_watch_cycle(self) -> dict:
        """Evaluate only active event symbols on closed 1m candles."""
        if not self._event_watch_lock.acquire(blocking=False):
            return {"status": "ALREADY_RUNNING", "actions": [], "active_watches": 0}
        actions: list[dict] = []
        errors: list[dict] = []
        try:
            watches = self.event_momentum_journal.active_watches()
            if not self._new_event_entries_enabled():
                for watch in watches:
                    state = dict(watch.get("state_payload") or {})
                    state["state"] = "CANCELLED"
                    state["last_reason"] = "STRATEGY_PROFILE_FROZEN"
                    self.event_momentum_journal.record_watch_result(
                        int(watch["id"]), {
                            "state": state, "action": "CANCEL",
                            "reason": "STRATEGY_PROFILE_FROZEN", "metrics": {},
                        },
                    )
                return {
                    "status": "FROZEN", "active_watches": len(watches),
                    "actions": [], "errors": [],
                }
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            for watch in watches:
                symbol = str(watch["symbol"])
                try:
                    candle_limit = max(
                        45,
                        int(self.event_watch_engine.config.max_duration_minutes) + 25,
                    )
                    candles = self.engine.market_data.get_klines(
                        symbol, "1m", candle_limit, as_of_ms=now_ms
                    )
                    state = EventWatchState.from_dict(watch.get("state_payload") or {})
                    outcome = self.event_watch_engine.evaluate(state, candles, as_of_ms=now_ms)
                    result = outcome.to_dict()
                    self.event_momentum_journal.record_watch_result(int(watch["id"]), result)
                    price = float((result.get("metrics") or {}).get("price") or 0)
                    if result.get("action") in {"ENTER", "ADD_TRANCHE"} and price > 0:
                        paper = self._execute_event_watch_entry(watch, result, price)
                        actions.append(paper)
                        if paper.get("status") != "FILLED":
                            cancelled = dict(result.get("state") or {})
                            cancelled["state"] = "CANCELLED"
                            cancelled["last_reason"] = "EVENT_ENTRY_BLOCKED_BY_SAFETY_LIMIT"
                            self.event_momentum_journal.record_watch_result(
                                int(watch["id"]), {
                                    "state": cancelled, "action": "CANCEL",
                                    "reason": "EVENT_ENTRY_BLOCKED_BY_SAFETY_LIMIT",
                                    "metrics": result.get("metrics") or {},
                                },
                            )
                    elif result.get("action") == "INVALIDATE" and price > 0:
                        for trade in self.event_momentum_journal.open_trades(symbol):
                            paper = self._sell_event_trade(
                                trade, quantity=float(trade.get("remaining_quantity") or 0),
                                market_price=price, label="EVENT_INVALIDATED",
                                reason="Событийный импульс отменён: пробой или краткосрочная структура потеряны",
                                analysis_id=watch.get("analysis_id"),
                            )
                            actions.append(paper)
                        closed = dict(result.get("state") or {})
                        if not self.event_momentum_journal.open_trades(symbol):
                            closed["state"] = "CLOSED"
                            self.event_momentum_journal.record_watch_result(
                                int(watch["id"]), {
                                    "state": closed, "action": "CLOSE",
                                    "reason": "EVENT_INVALIDATED",
                                    "metrics": result.get("metrics") or {},
                                },
                            )
                except Exception as error:
                    errors.append({"symbol": symbol, "error": f"{type(error).__name__}: {error}"})
                    logger.exception("event_watch_cycle_failed symbol=%s", symbol)
            return {
                "status": "COMPLETE_WITH_ERRORS" if errors else "COMPLETE",
                "active_watches": len(watches), "actions": actions, "errors": errors,
                "watch_summary": self.event_momentum_journal.watch_summary(),
            }
        finally:
            self._event_watch_lock.release()

    def run_fast_event_cycle(self) -> dict:
        """One paper-only 60s event scan over the last production universe."""
        if not (EVENT_PAPER_ENABLED and SPOT_EVENT_FAST_ENTRY_ENABLED):
            return {"status": "DISABLED", "actions": [], "errors": []}
        if not self._new_event_entries_enabled():
            prices = {}
            for trade in self.event_momentum_journal.open_trades():
                symbol = str(trade["symbol"])
                try:
                    prices[symbol] = self._price(symbol)
                except Exception:
                    pass
            actions = self._process_event_trade_exits(prices)
            return {
                "status": "FROZEN", "events_seen": 0, "symbols_checked": 0,
                "candidates": 0, "actions": actions, "errors": [],
            }
        now = datetime.now(timezone.utc)
        events = self.engine.news_engine.recent_event_feed()
        if not events:
            return {"status": "NO_EVENT_NEWS", "actions": [], "errors": []}
        symbols = list(dict.fromkeys(self._last_event_universe or self.fast_event_engine.policy.benchmark_symbols))
        needed = list(dict.fromkeys(symbols + list(self.fast_event_engine.policy.benchmark_symbols)))
        candles_1m: dict[str, list[dict]] = {}
        candles_15m: dict[str, list[dict]] = {}
        errors = []
        for symbol in needed:
            try:
                candles_1m[symbol] = self.engine.market_data.get_klines(symbol, "1m", 20)
                candles_15m[symbol] = self.engine.market_data.get_klines(symbol, "15m", 20)
            except Exception as error:
                errors.append({"symbol": symbol, "error": f"{type(error).__name__}: {error}"})
        candidates = self.fast_event_engine.scan_snapshot(
            events=events, symbols=symbols, candles_1m=candles_1m, candles_15m=candles_15m, as_of=now,
        )
        actions = []
        cycle_id = f"event-fast-{now.strftime('%Y%m%dT%H%M%S')}"
        for candidate in candidates:
            symbol = candidate["symbol"]
            event = candidate["event_momentum"]
            event_id = str(event.get("event_id") or "")
            if self.event_momentum_journal.has_open_trade(symbol):
                continue
            if self.event_momentum_journal.recently_used_event(
                symbol, event_id, cooldown_minutes=SPOT_EVENT_FAST_COOLDOWN_MINUTES, now=now
            ):
                continue
            current_price = float(candidate["current_price"])
            analysis = {
                "symbol": symbol, "current_price": current_price, "decision": "WAIT",
                "score": 0, "reasons": ["SPOT_EVENT_FAST_ENTRY independent paper lane"],
                "risks": [], "risk": {}, "event_momentum": event,
                "data_quality": {"decision_as_of_utc": now.isoformat()},
                "news": {"status": "AVAILABLE", "items": event.get("verified_news") or []},
            }
            action = self._handle_event_momentum(cycle_id, analysis, None, current_price)
            if action:
                actions.append(action)
        # Existing open event trades are managed on the same minute cadence.
        prices = {}
        for trade in self.event_momentum_journal.open_trades():
            symbol = str(trade["symbol"])
            try:
                prices[symbol] = self._price(symbol)
            except Exception:
                pass
        actions.extend(self._process_event_trade_exits(prices))
        return {
            "status": "COMPLETE_WITH_ERRORS" if errors else "COMPLETE",
            "events_seen": len(events), "symbols_checked": len(symbols),
            "candidates": len(candidates), "actions": actions, "errors": errors,
        }

    async def run_event_watches_forever(
        self, on_cycle: Callable[[dict], object] | None = None,
    ):
        while True:
            summaries = []
            if EVENT_PAPER_ENABLED and self.event_momentum_journal.active_watches():
                summaries.append(await asyncio.to_thread(self.run_event_watch_cycle))
            if EVENT_PAPER_ENABLED and SPOT_EVENT_FAST_ENTRY_ENABLED:
                summaries.append(await asyncio.to_thread(self.run_fast_event_cycle))
            if on_cycle:
                for summary in summaries:
                    callback_result = on_cycle(summary)
                    if asyncio.iscoroutine(callback_result):
                        await callback_result
            await asyncio.sleep(EVENT_WATCH_INTERVAL_SECONDS)

    def _sell_event_trade(
        self,
        trade: dict,
        *,
        quantity: float,
        market_price: float,
        label: str,
        reason: str,
        analysis_id: int | None = None,
        require_positive_net: bool = False,
        observed_at: datetime | None = None,
    ) -> dict:
        plan = dict(trade.get("plan") or {})
        metadata = {
            "trade_type": "NEWS_EVENT",
            "strategy_sleeve": (
                "SPOT_EVENT_FAST_ENTRY_V1"
                if plan.get("management_style") == "SPOT_EVENT_HARVEST_AND_TRAIL"
                else "EVENT_MOMENTUM_V1"
            ),
            "event_exit": label,
            "event_trade_id": int(trade["id"]),
            "allocation_percent": float(trade.get("allocation_percent") or 0),
            "trade_plan": trade.get("plan") or {},
            "verified_news": trade.get("news") or [],
            "event_score": int(trade.get("event_score") or 0),
        }
        action = self.broker.sell(
            trade["symbol"], quantity, market_price, reason, analysis_id, metadata,
            require_positive_net=require_positive_net,
            cost_basis_price=float(trade.get("entry_price") or 0) or None,
        )
        payload = action.to_dict() if hasattr(action, "to_dict") else dict(action)
        if payload.get("status") == "FILLED":
            updated = self.event_momentum_journal.record_exit(
                int(trade["id"]),
                label=label,
                quantity=float(payload.get("quantity") or 0),
                price=float(payload.get("price") or market_price),
                fee_usdt=float(payload.get("fee_usdt") or 0),
                reason=reason,
                observed_at=(observed_at or datetime.now(timezone.utc)).isoformat(),
            )
            if updated:
                details = payload.setdefault("details", {})
                details["event_trade_status"] = updated.get("status")
                details["event_realized_pnl_usdt"] = updated.get("realized_pnl_usdt")
                details["event_realized_return_percent"] = updated.get("realized_return_percent")
                if updated.get("status") == "CLOSED":
                    for watch in self.event_momentum_journal.active_watches(trade["symbol"]):
                        state = dict(watch.get("state_payload") or {})
                        state["state"] = "CLOSED"
                        state["last_reason"] = str(label)
                        self.event_momentum_journal.record_watch_result(
                            int(watch["id"]), {
                                "state": state,
                                "action": "CLOSE",
                                "reason": str(label),
                                "metrics": {},
                            },
                        )
        return payload

    def _process_event_trade_exits(
        self, prices: dict[str, float], *, now: datetime | None = None
    ) -> list[dict]:
        """Manage isolated event sleeves.

        Fast-entry Spot sleeves use protective invalidation + staged profit
        harvesting + a trailing exit for the remainder.  Legacy Event Momentum
        records retain their historical target/stop plan for backwards
        compatibility with existing journals and replays.
        """
        actions: list[dict] = []
        now = now or datetime.now(timezone.utc)
        for original in list(self.event_momentum_journal.open_trades()):
            symbol = original["symbol"]
            if symbol not in prices:
                continue
            price = float(prices[symbol])
            trade = original
            plan = dict(trade.get("plan") or {})

            if plan.get("management_style") == "SPOT_EVENT_HARVEST_AND_TRAIL":
                invalidation = float(plan.get("event_invalidation_price") or 0)
                if invalidation > 0 and price <= invalidation:
                    actions.append(self._sell_event_trade(
                        trade, quantity=float(trade.get("remaining_quantity") or 0),
                        market_price=price, label="EVENT_INVALIDATION",
                        reason=f"Событийный импульс сломан ниже защитного уровня ({invalidation:g})",
                        analysis_id=trade.get("analysis_id"),
                        observed_at=now,
                    ))
                    continue

                hit = {str(item.get("label")) for item in trade.get("exits") or []}
                for step in plan.get("profit_harvests") or []:
                    label = str(step.get("name") or "PROFIT_HARVEST")
                    level = float(step.get("price") or 0)
                    if label in hit or level <= 0 or price < level:
                        continue
                    fresh = next(
                        (item for item in self.event_momentum_journal.open_trades(symbol)
                         if int(item["id"]) == int(trade["id"])),
                        None,
                    )
                    if not fresh:
                        break
                    qty = min(
                        float(fresh.get("remaining_quantity") or 0),
                        float(fresh.get("initial_quantity") or 0)
                        * float(step.get("sell_percent") or 0) / 100.0,
                    )
                    if qty <= 0:
                        continue
                    actions.append(self._sell_event_trade(
                        fresh, quantity=qty, market_price=price, label=label,
                        reason=f"Частичная фиксация прибыли по событийной позиции ({level:g})",
                        analysis_id=fresh.get("analysis_id"),
                        require_positive_net=True,
                        observed_at=now,
                    ))
                    hit.add(label)

                fresh = next(
                    (item for item in self.event_momentum_journal.open_trades(symbol)
                     if int(item["id"]) == int(trade["id"])),
                    None,
                )
                if not fresh:
                    continue
                plan = dict(fresh.get("plan") or plan)
                trailing = dict(plan.get("trailing") or {})
                activate = float(trailing.get("activate_price") or 0)
                peak = max(float(trailing.get("peak_price") or fresh.get("entry_price") or 0), price)
                if peak != float(trailing.get("peak_price") or 0):
                    trailing["peak_price"] = peak
                    plan["trailing"] = trailing
                    updated = self.event_momentum_journal.update_trade_plan(int(fresh["id"]), plan)
                    if updated:
                        fresh = updated
                drawdown_percent = float(trailing.get("drawdown_percent") or 0)
                if activate > 0 and peak >= activate and drawdown_percent > 0:
                    trailing_level = peak * (1.0 - drawdown_percent / 100.0)
                    if price <= trailing_level:
                        actions.append(self._sell_event_trade(
                            fresh, quantity=float(fresh.get("remaining_quantity") or 0),
                            market_price=price, label="TRAILING_PROFIT_EXIT",
                            reason=(
                                f"Фиксация остатка после отката от локального пика {peak:g} "
                                f"на {drawdown_percent:.2f}%"
                            ),
                            analysis_id=fresh.get("analysis_id"),
                            require_positive_net=True,
                            observed_at=now,
                        ))
                        continue

                fresh = next(
                    (item for item in self.event_momentum_journal.open_trades(symbol)
                     if int(item["id"]) == int(trade["id"])),
                    None,
                )
                if not fresh:
                    continue
                entry_time = self.event_momentum_journal._parse_time(fresh["entry_timestamp"])
                age_hours = max(0.0, (now - entry_time).total_seconds() / 3600.0)
                exit_hours = int((fresh.get("plan") or {}).get("time_exit_hours") or EVENT_TIME_EXIT_HOURS)
                if age_hours >= exit_hours:
                    actions.append(self._sell_event_trade(
                        fresh, quantity=float(fresh.get("remaining_quantity") or 0),
                        market_price=price, label=f"TIME_EXIT_{exit_hours}H",
                        reason=f"Событийный сценарий завершён по времени через {exit_hours}ч",
                        analysis_id=fresh.get("analysis_id"),
                        observed_at=now,
                    ))
                continue

            # Legacy Event Momentum management, kept for already-existing
            # journals/replays created before the fast Spot lane.
            stop = float(plan.get("stop_price") or 0)
            if stop > 0 and price <= stop:
                actions.append(self._sell_event_trade(
                    trade, quantity=float(trade.get("remaining_quantity") or 0),
                    market_price=price, label="STOP",
                    reason=f"NEWS/EVENT stop/invalidation reached ({stop:g})",
                    analysis_id=trade.get("analysis_id"),
                ))
                continue

            hit = {str(item.get("label")) for item in trade.get("exits") or []}
            for target in plan.get("targets") or []:
                label = str(target.get("name") or "TP")
                target_price = float(target.get("price") or 0)
                if label in hit or target_price <= 0 or price < target_price:
                    continue
                fresh = next(
                    (item for item in self.event_momentum_journal.open_trades(symbol)
                     if int(item["id"]) == int(trade["id"])),
                    None,
                )
                if not fresh:
                    break
                qty = min(
                    float(fresh.get("remaining_quantity") or 0),
                    float(fresh.get("initial_quantity") or 0)
                    * float(target.get("sell_percent") or 0) / 100.0,
                )
                if qty <= 0:
                    continue
                actions.append(self._sell_event_trade(
                    fresh, quantity=qty, market_price=price, label=label,
                    reason=f"NEWS/EVENT {label} reached ({target_price:g})",
                    analysis_id=fresh.get("analysis_id"),
                ))
                hit.add(label)

            fresh = next(
                (item for item in self.event_momentum_journal.open_trades(symbol)
                 if int(item["id"]) == int(trade["id"])),
                None,
            )
            if not fresh:
                continue
            entry_time = self.event_momentum_journal._parse_time(fresh["entry_timestamp"])
            age_hours = max(0.0, (now - entry_time).total_seconds() / 3600.0)
            exit_hours = int((fresh.get("plan") or {}).get("time_exit_hours") or EVENT_TIME_EXIT_HOURS)
            if age_hours >= exit_hours:
                actions.append(self._sell_event_trade(
                    fresh, quantity=float(fresh.get("remaining_quantity") or 0),
                    market_price=price, label=f"TIME_EXIT_{exit_hours}H",
                    reason=f"NEWS/EVENT time exit after {exit_hours}h",
                    analysis_id=fresh.get("analysis_id"),
                ))
        return actions

    def _close_event_on_analysis_risk(
        self, analysis: dict, current_price: float,
    ) -> list[dict]:
        symbol = str(analysis.get("symbol") or "").upper()
        trades = self.event_momentum_journal.open_trades(symbol)
        if not trades:
            return []
        event = analysis.get("event_momentum") or {}
        blockers = set(event.get("blockers") or [])
        hard_event_risk = bool(blockers & {"CRITICAL_NEWS_RISK", "NEGATIVE_NEWS_CONFLICT", "MACRO_RISK_OFF"})
        hard_production_risk = analysis.get("decision") == "EXIT_ON_RISK"
        if not (hard_event_risk or hard_production_risk):
            return []
        reason = (
            "NEWS/EVENT invalidated by critical news/macro risk"
            if hard_event_risk else "NEWS/EVENT closed by production hard-risk signal"
        )
        output = []
        for trade in trades:
            output.append(self._sell_event_trade(
                trade,
                quantity=float(trade.get("remaining_quantity") or 0),
                market_price=current_price,
                label="RISK_INVALIDATION",
                reason=reason,
                analysis_id=analysis.get("_analysis_id"),
            ))
        return output

    def _handle_analysis(
        self, analysis: dict, analysis_id: int, current_price: float, equity_usdt: float | None = None
    ):
        symbol = analysis["symbol"]
        decision = analysis["decision"]
        position = self._production_position(symbol, current_price)
        production_quantity = float(position.quantity)
        self._guard_service().observe_analysis(
            symbol, analysis, position_exists=production_quantity > 0,
        )
        reasons = "; ".join(analysis.get("reasons") or [decision])
        reserve_policy = reserve_policy_for_macro((analysis.get("macro") or {}).get("regime"))
        common = {
            "decision": decision,
            "score": analysis.get("score"),
            "reasons": analysis.get("reasons") or [],
            "risks": analysis.get("risks") or [],
            "data_quality": analysis.get("data_quality") or {},
            "take_profit_plan": analysis.get("take_profit_plan") or {},
            "accumulation_plan": analysis.get("accumulation_plan") or {},
            "horizon": analysis.get("horizon"),
            "news": analysis.get("news") or {},
            "strategy_version": "4.8.0",
            "reserve_target_percent": reserve_policy.target_percent,
            "hard_floor_percent": reserve_policy.hard_floor_percent,
            "reserve_base_usdt": round(float(equity_usdt or self.journal.initial_capital()), 8),
            "deterioration_snapshot": build_deterioration_snapshot(analysis),
        }

        if decision == "EXIT_ON_RISK" and production_quantity > 0:
            action = self.broker.sell(
                symbol, production_quantity, current_price, reasons, analysis_id, common,
                cost_basis_price=position.average_price,
            )
            if self._paper_action_status(action) == "FILLED":
                self._guard_service().reset(symbol, "FULL_EXIT_ON_RISK")
            return action
        if decision == "TAKE_PROFIT" and production_quantity > 0:
            target = ((analysis.get("take_profit_plan") or {}).get("targets") or [{}])[0]
            fraction = max(0.05, min(float(target.get("sell_percent_of_position", 25)) / 100, 1.0))
            action = self.broker.sell(
                symbol, production_quantity * fraction, current_price, reasons,
                analysis_id, common, require_positive_net=True,
                cost_basis_price=position.average_price,
            )
            if self._paper_action_status(action) == "FILLED" and self._production_quantity(symbol, current_price) <= 1e-12:
                self._guard_service().reset(symbol, "FULL_TAKE_PROFIT_CLOSE")
            return action
        if decision == "REDUCE" and production_quantity > 0:
            reduction = self._guard_service().evaluate_reduce(symbol, analysis)
            common["deterioration_guard"] = {
                "reason": reduction.reason, **reduction.details,
            }
            if not reduction.allowed:
                return {
                    "action": "SELL", "symbol": symbol, "status": "SKIPPED",
                    "reason": reduction.reason, "details": common,
                }
            action = self.broker.sell(
                symbol, production_quantity * 0.25, current_price,
                reasons, analysis_id, common, cost_basis_price=position.average_price,
            )
            if self._paper_action_status(action) == "FILLED":
                action_details = (
                    action.get("details") or {} if isinstance(action, dict)
                    else action.details
                )
                self._guard_service().record_reduce_fill(
                    symbol, reduction,
                    net_pnl_usdt=float(
                        action_details.get("estimated_net_realized_pnl_usdt") or 0.0
                    ),
                    executed_at=datetime.now(timezone.utc).isoformat(),
                    analysis_id=analysis_id,
                )
            return action
        if decision in {"ACCUMULATE", "BUY_PARTIALLY"}:
            fundamentals_gate = self._fundamentals_execution_gate(symbol, analysis)
            common.update({
                "fundamentals_status": fundamentals_gate["fundamentals_status"],
                "fundamentals_unavailable_soft_gate": fundamentals_gate[
                    "fundamentals_unavailable_soft_gate"
                ],
            })
            ready, why = self._buy_context_ready(symbol, analysis)
            if not ready:
                return {"action": "BUY", "symbol": symbol, "status": "SKIPPED", "reason": why}
            if fundamentals_gate["fundamentals_unavailable_soft_gate"]:
                logger.info(
                    "fundamentals_soft_gate symbol=%s fundamentals_status=UNKNOWN "
                    "fundamentals_unavailable_soft_gate=true",
                    symbol,
                )
            zones = (analysis.get("accumulation_plan") or {}).get("zones") or []
            zone = next((item for item in zones if float(item.get("amount_usdt", 0)) > 0), None)
            if not zone:
                return {"action": "BUY", "symbol": symbol, "status": "SKIPPED", "reason": "no_buy_zone"}
            reentry = self._guard_service().evaluate_reentry(symbol, analysis)
            common["loss_reduce_reentry_guard"] = {
                "reason": reentry.reason, **reentry.details,
            }
            if not reentry.allowed:
                return {
                    "action": "BUY", "symbol": symbol, "status": "SKIPPED",
                    "reason": reentry.reason, "details": common,
                }
            if float(zone["lower"]) <= current_price <= float(zone["upper"]):
                action = self.broker.buy(
                    symbol, float(zone["amount_usdt"]), current_price, reasons, analysis_id, common,
                    reserve_floor_percent=reserve_policy.target_percent,
                    reserve_base_usdt=float(equity_usdt or self.journal.initial_capital()),
                    enforce_post_sell_rebuy_guard=True,
                )
                if self._paper_action_status(action) == "FILLED":
                    self._guard_service().record_buy_fill(symbol, reentry)
                return action
            return self.broker.place_buy_zone(
                symbol, zone, reasons, analysis_id, common,
                reserve_floor_percent=reserve_policy.target_percent,
                reserve_base_usdt=float(equity_usdt or self.journal.initial_capital()),
            )
        return {"action": decision, "symbol": symbol, "status": "NO_TRADE", "reason": reasons}

    def run_cycle(
        self,
        universe_limit: int | None = None,
        candidate_limit: int | None = None,
        progress_callback: ProgressCallback | None = None,
        timeout_seconds: int = CYCLE_TIMEOUT_SECONDS,
    ) -> dict:
        if not self._cycle_lock.acquire(blocking=False):
            state = self.cycle_status()
            return {
                "status": "ALREADY_RUNNING",
                "started_at": state.get("started_at"),
                "finished_at": None,
                "symbols_analyzed": state.get("processed", 0),
                "actions": [],
                "errors": [],
                "portfolio": {},
                "progress": state,
            }

        runtime_config = self.effective_runtime_config(
            universe_limit=universe_limit, candidate_limit=candidate_limit
        )
        effective_universe_limit = int(runtime_config["auto_universe_size_effective"])
        effective_candidate_limit = int(runtime_config["candidate_limit_effective"])
        strategy_profile = str(runtime_config.get("strategy_profile") or "FULL")
        analysis_context_mode = str(runtime_config.get("analysis_context_mode") or "full")
        new_buy_symbols = set(runtime_config.get("new_buy_symbols") or ())
        self._apply_effective_risk_config(runtime_config)
        cycle_id = f"spot-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}-{uuid.uuid4().hex[:12]}"
        started_dt = datetime.now(timezone.utc)
        started = started_dt.isoformat()
        started_monotonic = time.monotonic()
        deadline = started_monotonic + max(60, int(timeout_seconds))
        actions: list[dict] = []
        errors: list[dict] = []
        analyses: list[dict] = []
        timed_out = False
        cycle_recorded = False

        try:
            self.journal.begin_decision_cycle(
                cycle_id, self._analysis_mode(), runtime_config, started_at=started
            )
            cycle_recorded = True
        except Exception:
            self._cycle_lock.release()
            raise
        logger.info(
            "autonomous_cycle_started cycle_id=%s journal_db=%s universe=%s candidates=%s max_open=%s",
            cycle_id,
            Path(self.journal.path).resolve(),
            effective_universe_limit,
            effective_candidate_limit,
            runtime_config["max_open_ideas_effective"],
        )

        self._update_state(
            progress_callback,
            running=True,
            stage="PREPARING",
            processed=0,
            total=0,
            current_symbol=None,
            started_at=started,
            started_monotonic=started_monotonic,
            elapsed_seconds=0,
            errors=0,
            cycle_id=cycle_id,
            effective_config=runtime_config,
        )

        try:
            # Shadow outcomes are observational only and cannot affect production decisions.
            shadow_outcomes = self._measure_due_shadow_outcomes(limit=20)
            event_momentum_outcomes = self._measure_due_event_momentum(limit=20)
            self._update_state(progress_callback, stage="PENDING_ORDERS")
            # TTL expiry is safe before analysis and immediately releases stale reserves.
            actions.extend(item.to_dict() for item in self.broker.expire_pending_buy_orders())
            prices = self._snapshot_prices(include_pending=True)
            # Event positions own their TP/SL/time-exit lifecycle and remain tagged
            # separately from the normal accumulation strategy.
            actions.extend(self._process_event_trade_exits(prices))

            self._update_state(progress_callback, stage="BUILDING_UNIVERSE")
            owned = [position.symbol for position in self.journal.positions()]
            if strategy_profile == CORE_LAB_PROFILE:
                top = list(CORE_LAB_SYMBOLS)
                universe_snapshot = {
                    "available_assets": len(top),
                    "asset_filter_eligible_assets": len(top),
                    "liquidity_eligible_assets": len(top),
                    "symbols": top,
                    "profile_limited": True,
                }
            elif hasattr(self.symbol_provider, "get_universe_snapshot"):
                universe_snapshot = self.symbol_provider.get_universe_snapshot(
                    effective_universe_limit
                )
                top = list(universe_snapshot.get("symbols") or [])
            else:
                top = self.symbol_provider.get_top_symbols(effective_universe_limit)
                universe_snapshot = {
                    "available_assets": len(top),
                    "asset_filter_eligible_assets": len(top),
                    "liquidity_eligible_assets": len(top),
                    "symbols": top,
                }
            pending_symbols = [order["symbol"] for order in self.journal.pending_orders()]
            # A pending unowned asset must receive a fresh analysis before it can fill.
            universe = list(dict.fromkeys(owned + pending_symbols + top))
            self._last_event_universe = list(universe)
            portfolio_prices = self._snapshot_prices()
            portfolio_positions = self._production_positions(portfolio_prices)
            for symbol in universe:
                self.journal.upsert_decision_evaluation(
                    cycle_id,
                    symbol,
                    self._analysis_mode(),
                    universe_membership=True,
                    eligibility="PENDING",
                    evaluation_status="PENDING",
                )
            self.journal.update_decision_cycle(
                cycle_id,
                available_assets=int(universe_snapshot.get("available_assets", len(top))),
                asset_filter_eligible_assets=int(
                    universe_snapshot.get("asset_filter_eligible_assets", len(top))
                ),
                liquidity_eligible_assets=int(
                    universe_snapshot.get("liquidity_eligible_assets", len(top))
                ),
                universe_assets=len(universe),
            )
            self._update_state(progress_callback, total=len(universe), stage="ANALYZING")

            history_eligible = 0
            for index, symbol in enumerate(universe, start=1):
                if time.monotonic() >= deadline:
                    timed_out = True
                    errors.append({
                        "symbol": symbol,
                        "error": f"CycleTimeout: limit {timeout_seconds}s reached",
                    })
                    for pending_symbol in universe[index - 1:]:
                        self.journal.upsert_decision_evaluation(
                            cycle_id,
                            pending_symbol,
                            self._analysis_mode(),
                            eligibility="NOT_EVALUATED",
                            evaluation_status="NOT_REACHED",
                            primary_reason="CYCLE_TIMEOUT",
                        )
                    break

                self._update_state(
                    progress_callback,
                    stage="ANALYZING",
                    processed=index - 1,
                    current_symbol=symbol,
                    errors=len(errors),
                )
                try:
                    if symbol not in owned and not self.symbol_provider.has_minimum_history(symbol):
                        self.journal.upsert_decision_evaluation(
                            cycle_id,
                            symbol,
                            self._analysis_mode(),
                            eligibility="INELIGIBLE_HISTORY",
                            evaluation_status="SKIPPED",
                            purchase_possible=False,
                            primary_reason="INSUFFICIENT_LISTING_HISTORY",
                            gate_results_json={
                                "listing_history": {
                                    "evaluated": True, "pass": False,
                                }
                            },
                        )
                        self._update_state(progress_callback, processed=index)
                        continue
                    history_eligible += 1
                    current_price = self._price(symbol)
                    position = self._production_position(symbol, current_price)
                    analyze_kwargs = {
                        "position": position,
                        "portfolio_positions": portfolio_positions,
                    }
                    if analysis_context_mode != "full":
                        analyze_kwargs["context_mode"] = analysis_context_mode
                    result = self.engine.analyze(symbol, **analyze_kwargs).to_dict()
                    analysis_id = self.journal.save_analysis(result)
                    result["_analysis_id"] = analysis_id
                    analyses.append(result)
                    self._save_analysis_evaluation(
                        cycle_id, result, analysis_id, position.exists
                    )
                    self._save_event_momentum_candidate(cycle_id, result)
                except Exception as error:
                    errors.append({"symbol": symbol, "error": f"{type(error).__name__}: {error}"})
                    self.journal.upsert_decision_evaluation(
                        cycle_id,
                        symbol,
                        self._analysis_mode(),
                        eligibility="ELIGIBLE",
                        evaluation_status="ERROR",
                        purchase_possible=False,
                        primary_reason="ANALYSIS_ERROR",
                        secondary_reasons_json=[type(error).__name__],
                    )
                finally:
                    self._update_state(
                        progress_callback,
                        processed=index,
                        errors=len(errors),
                    )

            self.journal.update_decision_cycle(
                cycle_id,
                history_eligible_assets=history_eligible,
                analyzed_assets=len(analyses),
                errors=len(errors),
            )

            self._update_state(progress_callback, stage="APPLYING_DECISIONS", current_symbol=None)
            equity_for_recycling = self._estimate_equity(portfolio_positions)
            priority = {
                "EXIT_ON_RISK": 0, "TAKE_PROFIT": 1, "REDUCE": 2,
                "ACCUMULATE": 3, "BUY_PARTIALLY": 4, "HOLD": 5,
                "WAIT": 6, "AVOID": 7,
            }
            analyses.sort(
                key=lambda item: (
                    priority.get(item.get("decision"), 99),
                    -float(item.get("score", 0)),
                )
            )
            if analyses:
                # Macro is global context, but provider payload is attached to each
                # analysis. Persist the most conservative target observed this cycle
                # so Telegram can explain how much USDT the bot is trying to keep.
                reserve_targets = [
                    reserve_policy_for_macro((item.get("macro") or {}).get("regime")).target_percent
                    for item in analyses
                ]
                self.journal.set_config(
                    "last_cash_reserve_target_percent", max(reserve_targets)
                )

            candidate_rank = 0
            candidate_pool = sum(
                1
                for analysis in analyses
                if not self._production_position(
                    analysis["symbol"], float(analysis.get("current_price") or 0)
                ).exists
                and analysis.get("decision") in BUY_DECISIONS
                and (not new_buy_symbols or analysis["symbol"] in new_buy_symbols)
            )
            final_candidates = min(candidate_pool, effective_candidate_limit)
            for analysis in analyses:
                symbol = analysis["symbol"]
                position_exists = self._production_position(
                    symbol, float(analysis.get("current_price") or 0)
                ).exists
                try:
                    risk_exits = self._close_event_on_analysis_risk(
                        analysis, float(analysis["current_price"])
                    )
                    actions.extend(risk_exits)
                    event_action = self._handle_event_momentum(
                        cycle_id, analysis, int(analysis["_analysis_id"]),
                        float(analysis["current_price"]),
                    )
                    if event_action is not None:
                        actions.append(event_action)
                except Exception as error:
                    errors.append({
                        "symbol": symbol,
                        "error": f"EventExecutionError: {type(error).__name__}: {error}",
                    })
                # Re-read after a possible event fill/exit. Production logic must not
                # accidentally consume the event sleeve quantity.
                position_exists = self._production_position(
                    symbol, float(analysis.get("current_price") or 0)
                ).exists
                pending_exists = self.journal.has_pending_buy(symbol)
                if pending_exists and analysis.get("decision") not in BUY_DECISIONS:
                    pending_actions = self.broker.process_pending(
                        {symbol: float(analysis["current_price"])},
                        validator=lambda order, price, current=analysis: self._revalidate_pending_buy(
                            order, current, price
                        ),
                    )
                    pending_payloads = [item.to_dict() for item in pending_actions]
                    for payload in pending_payloads:
                        self._record_pending_reentry_fill(payload)
                    actions.extend(pending_payloads)
                    pending_exists = self.journal.has_pending_buy(symbol)
                if not position_exists and analysis["decision"] not in BUY_DECISIONS:
                    self.journal.upsert_decision_evaluation(
                        cycle_id,
                        symbol,
                        self._analysis_mode(),
                        purchase_possible=False,
                        execution_status="NO_TRADE",
                    )
                    # Keep a bounded research shadow of plausible rejected opportunities.
                    # This does not change execution and is intentionally broader than the
                    # old candidate-limit-only shadow journal.
                    score = float(analysis.get("score") or 0)
                    if score >= 50 and analysis.get("decision") in {"WAIT", "AVOID"}:
                        trace = build_decision_trace(analysis)
                        self._save_shadow_near_miss(
                            cycle_id, analysis, f"REJECTED:{trace['primary_reason']}"
                        )
                    continue
                if (
                    not position_exists
                    and analysis.get("decision") in BUY_DECISIONS
                    and new_buy_symbols
                    and symbol not in new_buy_symbols
                ):
                    self.journal.upsert_decision_evaluation(
                        cycle_id, symbol, self._analysis_mode(),
                        purchase_possible=False, execution_status="SKIPPED",
                        execution_blocker="STRATEGY_PROFILE_FROZEN_SYMBOL",
                    )
                    self._save_shadow_near_miss(
                        cycle_id, analysis, "STRATEGY_PROFILE_FROZEN_SYMBOL"
                    )
                    continue
                if not position_exists:
                    candidate_rank += 1
                    if candidate_rank > effective_candidate_limit:
                        self.journal.upsert_decision_evaluation(
                            cycle_id,
                            symbol,
                            self._analysis_mode(),
                            candidate_rank=candidate_rank,
                            candidate_selected=False,
                            purchase_possible=False,
                            execution_status="SKIPPED",
                            execution_blocker="CANDIDATE_LIMIT",
                        )
                        self._save_shadow_near_miss(
                            cycle_id, analysis, "CANDIDATE_LIMIT"
                        )
                        continue
                    self.journal.upsert_decision_evaluation(
                        cycle_id,
                        symbol,
                        self._analysis_mode(),
                        candidate_rank=candidate_rank,
                        candidate_selected=True,
                    )
                if pending_exists:
                    pending_actions = self.broker.process_pending(
                        {symbol: float(analysis["current_price"])},
                        validator=lambda order, price, current=analysis: self._revalidate_pending_buy(
                            order, current, price
                        ),
                    )
                    pending_payloads = [item.to_dict() for item in pending_actions]
                    for payload in pending_payloads:
                        self._record_pending_reentry_fill(payload)
                    actions.extend(pending_payloads)
                    attempted_fill = next(
                        (item for item in pending_payloads if item.get("action") == "BUY"), None
                    )
                    if attempted_fill is not None:
                        self.journal.upsert_decision_evaluation(
                            cycle_id, symbol, self._analysis_mode(),
                            execution_action="BUY",
                            execution_status=str(attempted_fill.get("status") or "UNKNOWN"),
                            execution_blocker=(
                                normalize_execution_reason(attempted_fill.get("reason"))
                                if attempted_fill.get("status") == "SKIPPED" else None
                            ),
                        )
                        continue
                    if self.journal.has_pending_buy(symbol):
                        self.journal.upsert_decision_evaluation(
                            cycle_id, symbol, self._analysis_mode(),
                            execution_action="PLACE_BUY_ZONE",
                            execution_status="PENDING",
                            execution_blocker=None,
                        )
                        continue
                try:
                    recycling_action = self._handle_capital_recycling(
                        analysis, int(analysis["_analysis_id"]),
                        float(analysis["current_price"]), equity_for_recycling,
                    )
                    if recycling_action is not None:
                        actions.append(recycling_action)
                        if recycling_action.get("status") == "FILLED":
                            # One capital-changing action per symbol/cycle keeps
                            # attribution clean and prevents double buy/sell.
                            self.journal.upsert_decision_evaluation(
                                cycle_id, symbol, self._analysis_mode(),
                                execution_action=str(recycling_action.get("action") or ""),
                                execution_status="FILLED",
                                execution_blocker=None,
                            )
                            continue
                    action = self._handle_analysis(
                        analysis,
                        int(analysis["_analysis_id"]),
                        float(analysis["current_price"]),
                        equity_for_recycling,
                    )
                    action_payload = action.to_dict() if hasattr(action, "to_dict") else action
                    actions.append(action_payload)
                    action_type = str(action_payload.get("action") or "")
                    action_status = str(action_payload.get("status") or "UNKNOWN")
                    blocker = (
                        normalize_execution_reason(action_payload.get("reason"))
                        if action_status in {"SKIPPED", "NO_TRADE"}
                        else None
                    )
                    purchase_possible = None
                    if not position_exists and analysis.get("decision") in BUY_DECISIONS:
                        purchase_possible = action_status in {"FILLED", "PENDING"}
                    self.journal.upsert_decision_evaluation(
                        cycle_id,
                        symbol,
                        self._analysis_mode(),
                        purchase_possible=purchase_possible,
                        execution_action=action_type,
                        execution_status=action_status,
                        execution_blocker=blocker,
                    )
                    if (
                        not position_exists
                        and analysis.get("decision") in BUY_DECISIONS
                        and action_status == "SKIPPED"
                    ):
                        self._save_shadow_near_miss(
                            cycle_id, analysis, blocker or "EXECUTION_SKIPPED"
                        )
                except Exception as error:
                    errors.append({"symbol": symbol, "error": f"{type(error).__name__}: {error}"})
                    self.journal.upsert_decision_evaluation(
                        cycle_id,
                        symbol,
                        self._analysis_mode(),
                        purchase_possible=False,
                        execution_status="ERROR",
                        execution_blocker="EXECUTION_ERROR",
                    )

            self.journal.update_decision_cycle(
                cycle_id,
                candidate_pool_assets=candidate_pool,
                final_candidate_assets=final_candidates,
                errors=len(errors),
            )

            self._update_state(progress_callback, stage="SAVING_PORTFOLIO")
            final_prices = self._snapshot_prices()
            snapshot = self.journal.portfolio_snapshot(final_prices)
            finished_dt = datetime.now(timezone.utc)
            finished = finished_dt.isoformat()
            duration = round(time.monotonic() - started_monotonic, 1)
            if timed_out:
                status = "TIMEOUT_WITH_PARTIAL_RESULTS"
            else:
                status = "COMPLETE_WITH_ERRORS" if errors else "COMPLETE"
            decision_counts = Counter(
                str(item.get("decision") or "UNKNOWN") for item in analyses
            )
            purchases = sum(
                item.get("action") == "BUY" and item.get("status") == "FILLED"
                for item in actions
            )
            exits = sum(
                item.get("action") == "SELL" and item.get("status") == "FILLED"
                for item in actions
            )
            event_purchases = sum(
                item.get("action") == "BUY"
                and item.get("status") == "FILLED"
                and (item.get("details") or {}).get("trade_type") == "NEWS_EVENT"
                for item in actions
            )
            event_exits = sum(
                item.get("action") == "SELL"
                and item.get("status") == "FILLED"
                and (item.get("details") or {}).get("trade_type") == "NEWS_EVENT"
                for item in actions
            )
            event_trade_summary = self.event_momentum_journal.trade_summary(limit=5)
            event_watch_summary = self.event_momentum_journal.watch_summary(limit=5)
            recycling_summary = self.journal.recycling_summary()
            recycling_buys = sum(
                item.get("status") == "FILLED"
                and (item.get("details") or {}).get("recycling_action") == "ACCUMULATE_ON_WEAKNESS"
                for item in actions
            )
            recycling_harvests = sum(
                item.get("status") == "FILLED"
                and (item.get("details") or {}).get("recycling_action") == "HARVEST_PROFIT"
                for item in actions
            )
            summary = {
                "cycle_id": cycle_id,
                "status": status,
                "mode": self._analysis_mode(),
                "started_at": started,
                "finished_at": finished,
                "duration_seconds": duration,
                "available_assets": int(universe_snapshot.get("available_assets", len(top))),
                "asset_filter_eligible_assets": int(
                    universe_snapshot.get("asset_filter_eligible_assets", len(top))
                ),
                "liquidity_eligible_assets": int(
                    universe_snapshot.get("liquidity_eligible_assets", len(top))
                ),
                "symbols_requested": len(universe),
                "history_eligible_assets": history_eligible,
                "symbols_analyzed": len(analyses),
                "candidate_pool": candidate_pool,
                "final_candidates": final_candidates,
                "candidate_limit": effective_candidate_limit,
                "decision_counts": dict(sorted(decision_counts.items())),
                "purchases": purchases,
                "exits": exits,
                "event_purchases": event_purchases,
                "event_exits": event_exits,
                "recycling_buys": recycling_buys,
                "recycling_harvests": recycling_harvests,
                "capital_recycling": recycling_summary,
                "event_sleeve": {
                    "enabled": bool(EVENT_PAPER_ENABLED),
                    "capital_pool_percent": float(EVENT_CAPITAL_POOL_PERCENT),
                    "capital_pool_cap_usdt": round(
                        self.journal.initial_capital() * float(EVENT_CAPITAL_POOL_PERCENT) / 100.0, 8
                    ),
                    "watches": event_watch_summary,
                    **event_trade_summary,
                },
                "actions": actions,
                "errors": errors,
                "portfolio": snapshot,
                "runtime_config": runtime_config,
                "shadow_outcomes": shadow_outcomes,
                "event_momentum_outcomes": event_momentum_outcomes,
            }
            self.journal.update_decision_cycle(
                cycle_id,
                status=status,
                analyzed_assets=len(analyses),
                candidate_pool_assets=candidate_pool,
                final_candidate_assets=final_candidates,
                purchases=purchases,
                exits=exits,
                errors=len(errors),
                summary_json=summary,
                finished_at=finished,
            )
            self.journal.save_automation_run(status, summary, started, finished)
            self.journal.queue_notification("CYCLE_SUMMARY", summary)
            logger.info(
                "autonomous_cycle_finished cycle_id=%s journal_db=%s status=%s analyzed=%s candidates=%s purchases=%s errors=%s duration=%s",
                cycle_id, Path(self.journal.path).resolve(), status, len(analyses),
                final_candidates, purchases, len(errors), duration,
            )
            self._update_state(
                progress_callback,
                running=False,
                stage="FINISHED",
                current_symbol=None,
                elapsed_seconds=duration,
                errors=len(errors),
                last_status=status,
                finished_at=finished,
                last_cycle_at=finished,
            )
            return summary
        except Exception as error:
            finished = datetime.now(timezone.utc).isoformat()
            duration = round(time.monotonic() - started_monotonic, 1)
            errors.append({"symbol": None, "error": f"{type(error).__name__}: {error}"})
            summary = {
                "cycle_id": cycle_id,
                "status": "FAILED",
                "mode": self._analysis_mode(),
                "started_at": started,
                "finished_at": finished,
                "duration_seconds": duration,
                "symbols_analyzed": len(analyses),
                "actions": actions,
                "errors": errors,
                "portfolio": {},
                "runtime_config": runtime_config,
            }
            if cycle_recorded:
                self.journal.update_decision_cycle(
                    cycle_id,
                    status="FAILED",
                    analyzed_assets=len(analyses),
                    errors=len(errors),
                    summary_json=summary,
                    finished_at=finished,
                )
            self.journal.save_automation_run("FAILED", summary, started, finished)
            logger.exception(
                "autonomous_cycle_failed cycle_id=%s journal_db=%s error=%s",
                cycle_id, Path(self.journal.path).resolve(),
                f"{type(error).__name__}: {error}",
            )
            self._update_state(
                progress_callback,
                running=False,
                stage="FAILED",
                current_symbol=None,
                elapsed_seconds=duration,
                errors=len(errors),
                last_status="FAILED",
                finished_at=finished,
                last_cycle_at=finished,
            )
            return summary
        finally:
            self._cycle_lock.release()

    async def run_forever(
        self,
        interval_seconds: int | None = None,
        on_cycle: Callable[[dict], object] | None = None,
    ):
        while True:
            enabled = bool(self.journal.get_config("automation_enabled", False))
            if enabled:
                summary = await asyncio.to_thread(self.run_cycle)
                if summary.get("status") != "ALREADY_RUNNING" and on_cycle:
                    result = on_cycle(summary)
                    if asyncio.iscoroutine(result):
                        await result
                config = resolve_runtime_config(
                    self.journal, interval_seconds=interval_seconds
                )
                delay = int(config.cycle_interval_seconds_effective)
                next_cycle = datetime.now(timezone.utc) + timedelta(seconds=delay)
                self._update_state(next_cycle_at=next_cycle.isoformat())
                remaining = delay
                while remaining > 0:
                    step = min(60, remaining)
                    await asyncio.sleep(step)
                    remaining -= step
            else:
                self._update_state(next_cycle_at=None)
                await asyncio.sleep(60)
