"""Resolve effective autonomous settings and expose their provenance.

Environment values are the deployment defaults.  Telegram settings stored in the
portfolio journal are explicit runtime overrides.  Keeping this resolution in one
place prevents the status screen, scheduler and autonomous worker from reporting
different limits.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

from config.settings import (
    AUTO_CANDIDATE_LIMIT,
    AUTO_SCAN_INTERVAL_SECONDS,
    AUTO_UNIVERSE_SIZE,
    DEFAULT_CAPITAL_USDT,
    MAX_OPEN_IDEAS,
)


LIVE_ANALYSIS_MODE = "MARKET_MACRO_VERIFIED_NEWS_ONCHAIN"
FULL_PROFILE = "FULL"
CORE_LAB_PROFILE = "CORE_LAB"
CORE_LAB_SYMBOLS = ("BTCUSDT", "ETHUSDT")
VALID_STRATEGY_PROFILES = {FULL_PROFILE, CORE_LAB_PROFILE}


def normalize_strategy_profile(value) -> str:
    profile = str(value or FULL_PROFILE).upper().strip()
    return profile if profile in VALID_STRATEGY_PROFILES else FULL_PROFILE


def strategy_profile_spec(value) -> dict:
    profile = normalize_strategy_profile(value)
    if profile == CORE_LAB_PROFILE:
        return {
            "name": CORE_LAB_PROFILE,
            "analysis_context_mode": "market_only",
            "analysis_mode": "MARKET_ONLY_CORE_LAB",
            "new_buy_symbols": list(CORE_LAB_SYMBOLS),
            "capital_recycling_enabled": False,
            "new_event_entries_enabled": False,
            "description": "BTC/ETH market-only control profile; guards stay enabled",
        }
    return {
        "name": FULL_PROFILE,
        "analysis_context_mode": "full",
        "analysis_mode": LIVE_ANALYSIS_MODE,
        "new_buy_symbols": [],
        "capital_recycling_enabled": True,
        "new_event_entries_enabled": True,
        "description": "Current full production-paper feature set",
    }


@dataclass(frozen=True)
class EffectiveRuntimeConfig:
    capital_usdt_config: float
    capital_usdt_effective: float
    capital_source: str
    auto_universe_size_config: int
    auto_universe_size_effective: int
    auto_universe_size_source: str
    candidate_limit_config: int
    candidate_limit_effective: int
    candidate_limit_source: str
    max_open_ideas_config: int
    max_open_ideas_effective: int
    max_open_ideas_source: str
    cycle_interval_seconds_config: int
    cycle_interval_seconds_effective: int
    cycle_interval_source: str
    analysis_mode: str = LIVE_ANALYSIS_MODE
    strategy_profile: str = FULL_PROFILE
    analysis_context_mode: str = "full"
    capital_recycling_enabled: bool = True
    new_event_entries_enabled: bool = True
    new_buy_symbols: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        return asdict(self)


def _positive_int_override(journal, key: str, fallback: int, minimum: int) -> tuple[int, str]:
    raw = journal.get_config(key)
    if raw is None:
        return int(fallback), "ENV"
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return int(fallback), "ENV_INVALID_DB_FALLBACK"
    if value < minimum:
        return int(fallback), "ENV_INVALID_DB_FALLBACK"
    return value, "DB"


def resolve_runtime_config(
    journal,
    *,
    universe_limit: int | None = None,
    candidate_limit: int | None = None,
    interval_seconds: int | None = None,
) -> EffectiveRuntimeConfig:
    universe, universe_source = _positive_int_override(
        journal, "auto_universe_size", AUTO_UNIVERSE_SIZE, 2
    )
    candidates, candidates_source = _positive_int_override(
        journal, "auto_candidate_limit", AUTO_CANDIDATE_LIMIT, 1
    )
    max_open, max_open_source = _positive_int_override(
        journal, "max_open_ideas", MAX_OPEN_IDEAS, 1
    )
    interval, interval_source = _positive_int_override(
        journal, "auto_scan_interval_seconds", AUTO_SCAN_INTERVAL_SECONDS, 60
    )

    if universe_limit is not None:
        universe = max(2, int(universe_limit))
        universe_source = "EXPLICIT"
    if candidate_limit is not None:
        candidates = max(1, int(candidate_limit))
        candidates_source = "EXPLICIT"
    if interval_seconds is not None:
        interval = max(60, int(interval_seconds))
        interval_source = "EXPLICIT"

    profile = normalize_strategy_profile(journal.get_config("strategy_profile", FULL_PROFILE))
    profile_spec = strategy_profile_spec(profile)
    if profile == CORE_LAB_PROFILE:
        universe = len(CORE_LAB_SYMBOLS)
        universe_source = "PROFILE"
        candidates = min(candidates, len(CORE_LAB_SYMBOLS))
        candidates_source = "PROFILE"

    configured_capital = float(DEFAULT_CAPITAL_USDT)
    effective_capital = float(journal.initial_capital())
    # PortfolioJournal always persists the initial capital.  Even when it equals
    # the ENV deployment default, the effective value is read from the DB.
    capital_source = "DB"
    return EffectiveRuntimeConfig(
        capital_usdt_config=configured_capital,
        capital_usdt_effective=effective_capital,
        capital_source=capital_source,
        auto_universe_size_config=int(AUTO_UNIVERSE_SIZE),
        auto_universe_size_effective=universe,
        auto_universe_size_source=universe_source,
        candidate_limit_config=int(AUTO_CANDIDATE_LIMIT),
        candidate_limit_effective=candidates,
        candidate_limit_source=candidates_source,
        max_open_ideas_config=int(MAX_OPEN_IDEAS),
        max_open_ideas_effective=max_open,
        max_open_ideas_source=max_open_source,
        cycle_interval_seconds_config=int(AUTO_SCAN_INTERVAL_SECONDS),
        cycle_interval_seconds_effective=interval,
        cycle_interval_source=interval_source,
        analysis_mode=str(profile_spec["analysis_mode"]),
        strategy_profile=profile,
        analysis_context_mode=str(profile_spec["analysis_context_mode"]),
        capital_recycling_enabled=bool(profile_spec["capital_recycling_enabled"]),
        new_event_entries_enabled=bool(profile_spec["new_event_entries_enabled"]),
        new_buy_symbols=tuple(profile_spec["new_buy_symbols"]),
    )
