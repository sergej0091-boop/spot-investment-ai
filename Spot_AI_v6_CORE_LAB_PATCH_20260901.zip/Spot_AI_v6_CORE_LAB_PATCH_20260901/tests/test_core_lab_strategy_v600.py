from __future__ import annotations

from types import SimpleNamespace

import pytest

from automation.engine import AutonomousPaperPortfolio
from config.runtime import CORE_LAB_PROFILE, resolve_runtime_config
from investment.decision_engine import DecisionEngine
from investment.models import InvestmentDecision, PositionState
from investment.strategy_policy import PRODUCTION_POLICY
from portfolio.journal import PortfolioJournal
from portfolio.paper_broker import PaperBroker


def _technical(score: float, regime: str) -> dict:
    return {
        "history_sufficient": True,
        "technical_score": score,
        "market_regime": regime,
        "overbought": False,
        "distance_to_support_percent": 5.0,
        "timeframes": {
            "1W": {"ema_trend": "NEUTRAL"},
            "1D": {"ema_trend": "NEUTRAL"},
        },
    }


def _contexts():
    return dict(
        liquidity={"liquidity_status": "HIGH"},
        risk={"blocked": False, "remaining_capacity_usdt": 100.0},
        fundamental={"quality_score": None, "blocked": False},
        news={"position_size_multiplier": 1.0, "critical_items": []},
        macro={"regime": "NEUTRAL"},
        on_chain={"bias": "UNAVAILABLE", "critical": False},
    )


def test_production_policy_creates_red_green_confirmation_asymmetry():
    engine = DecisionEngine(PRODUCTION_POLICY)
    empty = PositionState("BTCUSDT")
    held = PositionState(
        "BTCUSDT", quantity=1.0, average_price=100.0,
        invested_usdt=100.0, current_value_usdt=100.0,
    )
    c = _contexts()

    bearish_new = engine.decide(_technical(70, "BEARISH"), position=empty, **c)[0]
    recovered_new = engine.decide(_technical(60, "NEUTRAL"), position=empty, **c)[0]
    bearish_held = engine.decide(_technical(70, "BEARISH"), position=held, **c)[0]

    assert bearish_new is InvestmentDecision.WAIT
    assert recovered_new is InvestmentDecision.BUY_PARTIALLY
    assert bearish_held is InvestmentDecision.REDUCE


def test_long_horizon_research_variant_removes_bearish_regime_only_reduce():
    policy = PRODUCTION_POLICY.with_overrides(
        reduce_on_bearish_regime=False,
        structural_failure_action="REDUCE",
    )
    held = PositionState(
        "BTCUSDT", quantity=1.0, average_price=100.0,
        invested_usdt=100.0, current_value_usdt=100.0,
    )
    decision = DecisionEngine(policy).decide(
        _technical(70, "BEARISH"), position=held, **_contexts()
    )[0]
    assert decision is InvestmentDecision.HOLD


def test_core_lab_runtime_profile_freezes_layers_without_changing_full_default(tmp_path):
    journal = PortfolioJournal(tmp_path / "portfolio.sqlite3")
    journal.set_initial_capital(1000)
    full = resolve_runtime_config(journal)
    assert full.strategy_profile == "FULL"
    assert full.analysis_context_mode == "full"
    assert full.capital_recycling_enabled is True
    assert full.new_event_entries_enabled is True

    journal.set_config("strategy_profile", CORE_LAB_PROFILE)
    lab = resolve_runtime_config(journal)
    assert lab.strategy_profile == CORE_LAB_PROFILE
    assert lab.analysis_context_mode == "market_only"
    assert lab.capital_recycling_enabled is False
    assert lab.new_event_entries_enabled is False
    assert tuple(lab.new_buy_symbols) == ("BTCUSDT", "ETHUSDT")
    assert lab.auto_universe_size_effective == 2


def test_event_only_fill_is_not_a_production_position(tmp_path):
    journal = PortfolioJournal(tmp_path / "portfolio.sqlite3")
    journal.set_initial_capital(1000)
    broker = PaperBroker(journal, fee_rate=0, slippage_bps=0)
    app = AutonomousPaperPortfolio(engine=SimpleNamespace(), journal=journal, broker=broker)

    action = broker.buy(
        "SOLUSDT", 100.0, 20.0, "event", metadata={"trade_type": "NEWS_EVENT"}
    )
    assert action.status == "FILLED"
    assert journal.position("SOLUSDT", 20.0).exists is True

    production = app._production_position("SOLUSDT", 20.0)
    assert production.exists is False
    assert production.quantity == pytest.approx(0.0)


def test_mixed_event_and_production_position_keeps_production_cost_basis(tmp_path):
    journal = PortfolioJournal(tmp_path / "portfolio.sqlite3")
    journal.set_initial_capital(1000)
    broker = PaperBroker(journal, fee_rate=0, slippage_bps=0)
    app = AutonomousPaperPortfolio(engine=SimpleNamespace(), journal=journal, broker=broker)

    prod = broker.buy("BTCUSDT", 100.0, 10.0, "production")
    event = broker.buy(
        "BTCUSDT", 100.0, 20.0, "event", metadata={"trade_type": "NEWS_EVENT"},
        bypass_cooldown=True,
    )
    assert prod.status == event.status == "FILLED"

    production = app._production_position("BTCUSDT", 20.0)
    assert production.quantity == pytest.approx(10.0)
    assert production.average_price == pytest.approx(10.0)
    assert production.invested_usdt == pytest.approx(100.0)
    assert production.current_value_usdt == pytest.approx(200.0)


def test_market_only_context_skips_optional_provider_calls():
    from investment.analysis_engine import SpotInvestmentEngine
    from tests.test_engine import FakeMarketData, FakeOrderBook

    class BombModule:
        def analyze(self, *args, **kwargs):
            raise AssertionError("optional provider must not be called in CORE_LAB market_only")

    result = SpotInvestmentEngine(
        FakeMarketData(), FakeOrderBook(),
        fundamental_engine=BombModule(), news_engine=BombModule(),
        macro_engine=BombModule(), onchain_engine=BombModule(),
    ).analyze("BTCUSDT", context_mode="market_only")

    assert result.data_quality["context_mode"] == "market_only"
    assert result.fundamental["status"] == "UNAVAILABLE"
    assert result.news["status"] == "UNAVAILABLE"
    assert result.macro["regime"] == "NEUTRAL"
    assert result.on_chain["critical"] is False
    assert result.data_quality["provider_timings_ms"]["news"] == 0.0


def test_decision_trace_uses_experiment_policy_instead_of_hardcoded_thresholds():
    from investment.decision_trace import build_decision_trace

    payload = {
        "decision": "HOLD",
        "score": 70.0,
        "technical": {
            "technical_score": 70.0,
            "history_sufficient": True,
            "market_regime": "BEARISH",
            "overbought": False,
            "distance_to_support_percent": 5.0,
            "timeframes": {
                "1W": {"ema_trend": "NEUTRAL"},
                "1D": {"ema_trend": "NEUTRAL"},
            },
        },
        "liquidity": {"liquidity_status": "HIGH"},
        "risk": {"blocked": False},
        "fundamental": {"quality_score": None, "blocked": False},
        "news": {"critical_items": [], "position_size_multiplier": 1.0},
        "macro": {"regime": "NEUTRAL"},
        "on_chain": {"bias": "UNAVAILABLE", "critical": False},
    }
    long_policy = PRODUCTION_POLICY.with_overrides(reduce_on_bearish_regime=False)
    production_trace = build_decision_trace(payload, position_exists=True)
    long_trace = build_decision_trace(payload, position_exists=True, policy=long_policy)

    assert production_trace["primary_reason"] == "POSITION_QUALITY_WEAKENED"
    assert long_trace["primary_reason"] == "HOLD_NO_NEW_TRANCHE"
    assert long_trace["score_components"]["strategy_policy"]["reduce_on_bearish_regime"] is False


def test_sleeve_cost_basis_override_prevents_event_average_from_flipping_production_pnl(tmp_path):
    journal = PortfolioJournal(tmp_path / "portfolio.sqlite3")
    journal.set_initial_capital(1000)
    broker = PaperBroker(journal, fee_rate=0, slippage_bps=0)
    broker.buy("BTCUSDT", 100.0, 10.0, "production")
    broker.buy(
        "BTCUSDT", 100.0, 20.0, "event", metadata={"trade_type": "NEWS_EVENT"},
        bypass_cooldown=True,
    )
    assert journal.position("BTCUSDT", 12.0).average_price > 10.0

    action = broker.sell(
        "BTCUSDT", 1.0, 12.0, "production reduce",
        cost_basis_price=10.0,
    )
    assert action.status == "FILLED"
    assert action.details["cost_basis_source"] == "SLEEVE_OVERRIDE"
    assert action.details["average_cost_price"] == pytest.approx(10.0)
    assert action.details["estimated_net_realized_pnl_usdt"] == pytest.approx(2.0)
