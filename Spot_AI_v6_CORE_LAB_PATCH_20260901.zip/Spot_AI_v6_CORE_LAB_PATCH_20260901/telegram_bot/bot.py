from __future__ import annotations

import asyncio
import json
import os
import shutil
import time
from dataclasses import asdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from contextlib import suppress

from telegram import BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import BadRequest, TelegramError
from telegram.ext import (
    Application,
    ApplicationHandlerStop,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    TypeHandler,
    filters,
)

from automation.engine import AutonomousPaperPortfolio
from config.runtime import (
    CORE_LAB_PROFILE, CORE_LAB_SYMBOLS, FULL_PROFILE, LIVE_ANALYSIS_MODE,
    normalize_strategy_profile,
)
from config.version import APP_VERSION
from config.settings import (
    ALLOWED_CHAT_IDS,
    AUTO_SCAN_INTERVAL_SECONDS,
    AUTO_CYCLE_SUMMARY_INTERVAL_HOURS,
    EVENT_PAPER_ENABLED,
    EVENT_CAPITAL_POOL_PERCENT,
    HARD_CASH_RESERVE_PERCENT,
    MIN_CASH_RESERVE_PERCENT,
    STRATEGY_VERSION,
    TELEGRAM_PROGRESS_UPDATE_SECONDS,
    TELEGRAM_TOKEN,
)
from investment.analysis_engine import SpotInvestmentEngine
from investment.opportunity_grader import grade_evaluation
from portfolio.journal import PortfolioJournal
from portfolio.trade_chart import TradeChartService
from preflight.checks import PreflightChecker
from testing.historical_replay import (
    HistoricalReplayConfig,
    HistoricalReplayRunner,
    compare_runs,
    compare_strategy_runs,
    move_run_to_trash,
)
from testing.replay import PointInTimeStore
from testing.historical_context import build_context_preflight
from telegram_bot.historical_wizard import (
    PRESET_ALL,
    PRESET_CORE,
    PRESET_RUNTIME,
    add_manual_symbol,
    apply_preset,
    back_step,
    cached_symbol_coverage,
    ensure_draft,
    enter_step,
    normalize_symbol,
    set_available_symbols,
    symbol_page,
    toggle_symbol,
)
from telegram_bot.formatter import (
    display_analysis_mode,
    display_cycle_status,
    display_decision,
    display_event_status,
    display_gate,
    display_market_regime,
    display_provider_status,
    display_reason,
    format_action,
    format_analysis,
    format_cycle,
    format_cycle_progress,
    format_history,
    format_portfolio,
)
from utils.logger import logger
from utils.single_instance import AlreadyRunningError, SingleInstance

VERSION = APP_VERSION
engine = SpotInvestmentEngine()
journal = PortfolioJournal()
autonomous = AutonomousPaperPortfolio(engine=engine, journal=journal)
trade_charts = TradeChartService(engine.market_data, journal)
replay_runner: HistoricalReplayRunner | None = None
replay_task: asyncio.Task | None = None
replay_kind: str | None = None
runtime_lock: SingleInstance | None = None

# Short-lived cache for UI-only reads. Telegram menus should never wait on a
# busy SQLite writer just to decide a button label. Trading decisions still
# read the journal directly; this cache affects presentation only.
_UI_CACHE_TTL_SECONDS = 2.0
_ui_cache: dict[str, tuple[float, object]] = {}


def _ui_cached(key: str, loader, ttl: float = _UI_CACHE_TTL_SECONDS):
    now = time.monotonic()
    cached = _ui_cache.get(key)
    if cached and now - cached[0] <= ttl:
        return cached[1]
    value = loader()
    _ui_cache[key] = (now, value)
    return value


def _ui_cache_invalidate(*keys: str) -> None:
    if not keys:
        _ui_cache.clear()
        return
    for key in keys:
        _ui_cache.pop(key, None)


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


def _strategy_profile() -> str:
    return normalize_strategy_profile(
        _ui_cached("strategy_profile", lambda: journal.get_config("strategy_profile", FULL_PROFILE))
    )


def _profile_status_text() -> str:
    profile = _strategy_profile()
    if profile == CORE_LAB_PROFILE:
        return (
            "🧊 CORE LAB — ВКЛ\n"
            "Новые покупки: BTC, ETH\n"
            "Рынок / техника / ликвидность: ВКЛ\n"
            "Deterioration + re-entry guards: ВКЛ\n"
            "Fundamentals / News / Macro / On-chain: ЗАМОРОЖЕНЫ для решений\n"
            "Capital Recycling: ВЫКЛ\n"
            "Новые News/Event входы: ВЫКЛ\n"
            "Существующие позиции и Event-выходы продолжают управляться.\n\n"
            "Это контрольный режим для чистой проверки базовой Spot-логики; "
            "production thresholds не меняются."
        )
    return (
        "⚪ FULL — ВКЛ\n"
        "Обычный universe: ВКЛ\n"
        "Рынок / техника / ликвидность: ВКЛ\n"
        "Fundamentals / News / Macro / On-chain: ВКЛ\n"
        "Capital Recycling: ВКЛ (если разрешён ENV)\n"
        "News/Event paper layer: ВКЛ (если разрешён ENV)\n"
        "Deterioration + re-entry guards: ВКЛ\n\n"
        "Это текущий полный paper-режим."
    )


def strategy_profile_keyboard() -> InlineKeyboardMarkup:
    profile = _strategy_profile()
    return InlineKeyboardMarkup([
        [_btn(("✅ " if profile == FULL_PROFILE else "") + "FULL", "settings_profile_full")],
        [_btn(("✅ " if profile == CORE_LAB_PROFILE else "") + "🧊 CORE LAB · BTC+ETH", "settings_profile_core_lab")],
        [_btn("⬅️ Настройки", "settings_menu")],
    ])


def main_keyboard() -> InlineKeyboardMarkup:
    buys_paused = bool(_ui_cached("purchases_paused", lambda: journal.get_config("purchases_paused", False)))
    return InlineKeyboardMarkup([
        [_btn("💼 Портфель", "portfolio"), _btn("🎯 Кандидаты", "opportunities")],
        [_btn("📈 График", "chart_menu"), _btn("🧪 Исторический тест", "replay_menu")],
        [_btn("📜 История", "history"), _btn("▶️ Возобновить покупки" if buys_paused else "⏸ Пауза покупок", "resume_buys" if buys_paused else "pause_buys")],
        [_btn("⚙️ Настройки", "settings_menu"), _btn("🛠 Сервис", "service_menu")],
    ])


def service_keyboard() -> InlineKeyboardMarkup:
    frozen = _strategy_profile() == CORE_LAB_PROFILE
    event_label = "⚪ Новостной контур · заморожен" if frozen else "⚡📰 Новостной контур"
    recycling_label = "⚪ Оборот капитала · заморожен" if frozen else "♻️ Оборот капитала"
    return InlineKeyboardMarkup([
        [_btn("🖥 Состояние системы", "status"), _btn("🔬 Диагностика решений", "diag:24")],
        [_btn("🔌 Источники данных", "sources"), _btn(event_label, "event_momentum")],
        [_btn(recycling_label, "recycling"), _btn("🔄 Проверить рынок", "run_cycle")],
        [_btn("🚨 Аварийное управление", "emergency_menu"), _btn("❓ Справка", "help_menu")],
        [_btn("⬅️ Главное меню", "main_menu")],
    ])


def diagnostics_keyboard(hours: int = 24) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("24ч", "diag:24"), _btn("72ч", "diag:72"), _btn("7д", "diag:168")],
        [_btn("📋 Подробнее", f"diag_detail:{int(hours)}")],
        [_btn("⬅️ Сервис", "service_menu")],
    ])


HISTORY_PAGE_SIZE = 5


def history_keyboard(page: int, total: int) -> InlineKeyboardMarkup:
    page = max(0, int(page))
    total = max(0, int(total))
    max_page = max(0, (total - 1) // HISTORY_PAGE_SIZE) if total else 0
    nav = []
    if page > 0:
        nav.append(_btn("⬅️ Новее", f"history_page:{page-1}"))
    nav.append(_btn(f"{page+1}/{max_page+1}", "history_noop"))
    if page < max_page:
        nav.append(_btn("Старее ➡️", f"history_page:{page+1}"))
    rows = [nav]
    rows.append([_btn("⬅️ Главное меню", "main_menu")])
    return InlineKeyboardMarkup(rows)


def chart_period_keyboard(symbol: str) -> InlineKeyboardMarkup:
    symbol = symbol.upper()
    return InlineKeyboardMarkup([
        [_btn("7 дней", f"chart_period:{symbol}:7d"), _btn("30 дней", f"chart_period:{symbol}:30d")],
        [_btn("90 дней", f"chart_period:{symbol}:90d"), _btn("180 дней", f"chart_period:{symbol}:180d")],
        [_btn("1 год", f"chart_period:{symbol}:365d"), _btn("Вся история", f"chart_period:{symbol}:all")],
        [_btn("⬅️ Монеты", "chart_menu"), _btn("🏠 Главное меню", "main_menu")],
    ])


def chart_symbol_keyboard() -> InlineKeyboardMarkup:
    positions = sorted(
        journal.positions(),
        key=lambda item: float(getattr(item,"invested_usdt",0) or 0),
        reverse=True,
    )
    symbols = [position.symbol for position in positions]
    transaction_loader = getattr(journal,"recent_transactions",None)
    if transaction_loader is None:
        transaction_loader = getattr(journal,"recent_transactions_with_realized_pnl",None)
    if transaction_loader is not None:
        symbols.extend(item["symbol"] for item in transaction_loader(100))
    symbols = list(dict.fromkeys(symbols))[:12]
    rows = []
    for index in range(0, len(symbols), 2):
        rows.append([_btn(item, f"chart_symbol:{item}") for item in symbols[index:index+2]])
    rows.append([_btn("✍️ Ввести монету", "chart_custom")])
    rows.append([_btn("⬅️ Главное меню", "main_menu")])
    return InlineKeyboardMarkup(rows)


def history_page_text(page: int = 0) -> tuple[str, InlineKeyboardMarkup]:
    """Synchronous rendering seam used by UI tests and non-async clients."""
    page=max(0,int(page))
    loader=getattr(journal,"recent_transactions_with_realized_pnl")
    counter=getattr(journal,"transactions_count",None)
    if counter is not None:
        total=max(0,int(counter()))
        needed=min(total,(page+1)*HISTORY_PAGE_SIZE)
        rows=loader(needed) if needed else []
    else:
        rows=loader((page+1)*HISTORY_PAGE_SIZE)
        total=len(rows)
    start=page*HISTORY_PAGE_SIZE
    page_rows=rows[start:start+HISTORY_PAGE_SIZE]
    text=format_history(page_rows)
    text += f"\n\nСтраница {page+1}"
    return text,history_keyboard(page,total)


def replay_quick_symbol_keyboard() -> InlineKeyboardMarkup:
    """Internal regression chooser; intentionally not linked from user menus."""
    symbols=("BTC","ETH","SOL","BNB","LINK")
    rows=[[_btn(symbol,f"replay_fixture:{symbol}USDT") for symbol in symbols[:3]],
          [_btn(symbol,f"replay_fixture:{symbol}USDT") for symbol in symbols[3:]]]
    rows.append([_btn("✍️ Другая монета","replay_fixture:manual")])
    rows.append([_btn("⬅️ Исторический тест","replay_menu")])
    return InlineKeyboardMarkup(rows)


def build_recycling_text() -> str:
    summary = journal.recycling_summary()
    target = float(journal.get_config("last_cash_reserve_target_percent", MIN_CASH_RESERVE_PERCENT))
    frozen = _strategy_profile() == CORE_LAB_PROFILE
    lines = [
        "♻️ ОБОРОТ КАПИТАЛА",
        "Статус: ЗАМОРОЖЕН CORE LAB" if frozen else "Статус: ВКЛ",
        f"Целевой USDT-резерв: {target:.1f}%",
        f"Жёсткий минимум: {float(HARD_CASH_RESERVE_PERCENT):.1f}%",
        f"Резерв для повторного набора: {float(summary.get('rebuy_pool_usdt') or 0):,.2f} USDT",
        f"Общий резерв возможностей: {float(summary.get('opportunity_pool_usdt') or 0):,.2f} USDT",
        f"Сохранено в свободных средствах: {float(summary.get('retained_proceeds_usdt') or 0):,.2f} USDT",
        "",
        "Правила:",
        "• при росте и перегреве: частичная фиксация прибыли 20% → 25% → 35%;",
        "• сохраняется стратегическая часть около 20% исходной позиции;",
        "• после отката от пика: поэтапная докупка 5% → 7,5% → 10% портфеля;",
        "• падение само по себе не является сигналом: тезис и risk-фильтры должны оставаться валидными.",
    ]
    events = summary.get("events") or {}
    if events:
        lines.append("")
        lines.append("Статистика:")
        for key, label in (("HARVEST_PROFIT", "Частичная фиксация прибыли"), ("ACCUMULATE_ON_WEAKNESS", "Докупка на слабости")):
            item = events.get(key) or {}
            lines.append(f"• {label}: {item.get('count',0)} | {float(item.get('amount_usdt') or 0):,.2f} USDT")
    return "\n".join(lines)[:4000]


async def send_trade_chart(update: Update, context: ContextTypes.DEFAULT_TYPE, symbol: str, period: str) -> None:
    message = await update.effective_message.reply_text(f"📈 Строю {symbol.upper()} за {period}…")
    try:
        path = await asyncio.to_thread(trade_charts.build, symbol.upper(), period)
        caption = (
            f"📈 {symbol.upper()} · {period.upper()}\n"
            "Покупка = вход · Продажа = выход · пунктир = средняя цена позиции\n"
            "График показывает виртуальные операции."
        )
        send_error = None
        for attempt in range(2):
            try:
                with path.open("rb") as handle:
                    await context.application.bot.send_photo(
                        update.effective_chat.id, photo=handle, caption=caption,
                        read_timeout=30, write_timeout=30, connect_timeout=10, pool_timeout=10,
                    )
                send_error = None
                break
            except Exception as error:
                send_error = error
                logger.warning("trade_chart_send_retry symbol=%s period=%s attempt=%s error_type=%s", symbol, period, attempt + 1, type(error).__name__)
                if attempt == 0:
                    await asyncio.sleep(1.0)
        if send_error is not None:
            raise send_error
        await message.edit_text("График отправлен.", reply_markup=main_keyboard())
    except Exception:
        logger.exception("trade_chart_failed symbol=%s period=%s", symbol, period)
        await message.edit_text(
            "Не удалось построить график. Подробности сохранены в журнале приложения.",
            reply_markup=main_keyboard(),
        )


def _iso_age(value: str | None) -> str:
    if not value:
        return "нет успешных данных"
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        seconds = max(0, int((datetime.now(timezone.utc) - parsed).total_seconds()))
        if seconds < 120:
            return f"{seconds} сек."
        if seconds < 7200:
            return f"{seconds // 60} мин."
        if seconds < 172800:
            return f"{seconds // 3600} ч."
        return f"{seconds // 86400} д."
    except (TypeError, ValueError):
        return "возраст неизвестен"


def _next_cycle_text(latest: dict | None, cycle: dict, interval: int, enabled: bool) -> str:
    if not enabled:
        return "автоматика выключена"
    if cycle.get("running"):
        return "после завершения текущего цикла"
    if cycle.get("next_cycle_at"):
        return _human_datetime(cycle["next_cycle_at"])
    if latest and latest.get("finished_at"):
        try:
            finished = datetime.fromisoformat(str(latest["finished_at"]).replace("Z", "+00:00"))
            return _human_datetime(finished + timedelta(seconds=int(interval)))
        except ValueError:
            pass
    return "после запуска планировщика"


def _human_datetime(value: object) -> str:
    try:
        parsed = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone().strftime("%d.%m.%Y, %H:%M")
    except (TypeError, ValueError):
        return "время не зафиксировано"


def build_status_text() -> str:
    latest = journal.latest_automation_run()
    cycle = autonomous.cycle_status()
    runtime = autonomous.effective_runtime_config()
    positions = journal.positions()
    pending_buys = {
        item["symbol"] for item in journal.pending_orders()
        if item.get("side") == "BUY"
    }
    invested = sum(float(item.invested_usdt) for item in positions)
    enabled = bool(journal.get_config("automation_enabled", False))
    if cycle.get("running"):
        stages = {"PREPARING": "подготовка", "PENDING_ORDERS": "проверка ожидающих цен", "BUILDING_UNIVERSE": "формирование списка монет", "ANALYZING": "анализ рынка", "APPLYING_DECISIONS": "применение решений", "SAVING_PORTFOLIO": "сохранение портфеля"}
        cycle_line = (
            f"выполняется: {cycle.get('processed', 0)}/{cycle.get('total', 0)} — "
            f"{cycle.get('current_symbol') or stages.get(cycle.get('stage'), 'подготовка')}"
        )
    else:
        cycle_line = display_cycle_status(cycle.get("last_status") or "ОЖИДАНИЕ")
    last_orders = journal.recent_orders(1)
    last_transactions = journal.recent_transactions(1)
    if last_orders:
        item = last_orders[0]
        side = "Покупка" if item.get("side") == "BUY" else "Продажа"
        last_action = f"{side} {item.get('symbol')} — {display_cycle_status(item.get('status'))}"
    elif last_transactions:
        item = last_transactions[0]
        side = "Покупка" if item.get("side") == "BUY" else "Продажа"
        last_action = f"{side} {item.get('symbol')} — выполнено"
    else:
        last_action = "нет"
    return (
        "🖥 СОСТОЯНИЕ СИСТЕМЫ\n"
        f"Автоматическая проверка: {'включена' if enabled else 'выключена'}\n"
        f"Режим анализа: {display_analysis_mode(LIVE_ANALYSIS_MODE)}\n"
        f"Новые покупки: {'приостановлены' if journal.get_config('purchases_paused', False) else 'разрешены'}\n"
        f"Проверка рынка: {cycle_line}\n"
        f"Капитал: {journal.initial_capital():,.2f} USDT\n"
        f"Свободно: {journal.available_cash():,.2f} USDT\n"
        f"Инвестировано: {invested:,.2f} USDT\n"
        f"Открытые позиции: {len(positions)}\n"
        f"Ожидающие покупки: {len(pending_buys)}\n"
        f"Последний цикл: {_human_datetime((latest or {}).get('finished_at')) if latest else 'ещё не запускался'}\n"
        f"Следующий цикл: {_next_cycle_text(latest, cycle, runtime['cycle_interval_seconds_effective'], enabled)}\n"
        f"Последнее действие: {last_action}"
    )


def build_status_detail_text() -> str:
    runtime = autonomous.effective_runtime_config()
    return (
        "🖥 ПОДРОБНОЕ СОСТОЯНИЕ\n"
        f"Версия приложения: {VERSION}\n"
        f"Версия стратегии: {STRATEGY_VERSION}\n"
        f"Размер списка монет: {runtime['auto_universe_size_effective']}\n"
        f"Лимит кандидатов: {runtime['candidate_limit_effective']}\n"
        f"Максимум открытых позиций: {runtime['max_open_ideas_effective']}\n"
        f"Интервал автоматической проверки: {runtime['cycle_interval_seconds_effective'] // 60} мин.\n"
        "Технические источники настроек доступны только для диагностики; торговые правила здесь не меняются."
    )


def build_opportunities_text(limit: int = 5) -> str:
    cycle = journal.latest_decision_cycle(completed_only=True)
    if not cycle:
        return "🎯 ВОЗМОЖНОСТИ РЫНКА\nПока нет завершённого цикла для ранжирования."
    rows = journal.decision_cycle_evaluations(cycle["cycle_id"])
    evaluated = [r for r in rows if r.get("evaluation_status") == "EVALUATED"]
    enriched = [(grade_evaluation(r), r) for r in evaluated]
    enriched.sort(key=lambda pair: (pair[0].grade == "BLOCKED", -pair[0].quality))
    lines = [
        "🎯 РЫНОК",
        f"Последняя проверка: {_human_datetime(cycle.get('finished_at'))}",
        "Это обзор: он не меняет решения стратегии.",
        "",
    ]
    if not enriched:
        lines.append("В последнем цикле нет полностью оценённых активов.")
    for grade, row in enriched[:max(1, int(limit))]:
        payload = row.get("payload") or {}
        lines.append(
            f"• {row.get('symbol')} · {display_decision(row.get('final_decision'))}"
        )
        reason = row.get("primary_reason")
        if reason:
            lines.append(f"  Причина: {display_reason(reason)}")
        if grade.blockers:
            lines.append("  Ограничения: " + "; ".join(display_reason(item) for item in grade.blockers[:3]))
        regime = (payload.get("technical") or {}).get("market_regime")
        if regime:
            lines.append(f"  Режим: {display_market_regime(regime)}")
    lines.extend(["", "Подробная диагностика причин доступна в Сервис → Диагностика решений."])
    return "\n".join(line for line in lines if line)[:4000]



def build_event_momentum_text() -> str:
    research = autonomous.event_momentum_journal.summary(limit=5)
    trades = autonomous.event_momentum_journal.trade_summary(limit=8)
    watches = autonomous.event_momentum_journal.watch_summary(limit=5)
    initial = journal.initial_capital()
    cap = initial * float(EVENT_CAPITAL_POOL_PERCENT) / 100.0
    used = float(trades.get("open_allocation_usdt") or 0)
    lines = [
        "⚡📰 НОВОСТНОЙ КОНТУР",
        "Отдельный исследовательский виртуальный контур. Реальные деньги и биржевые ордера не используются.",
        f"Статус: {'ЗАМОРОЖЕН CORE LAB' if _strategy_profile() == CORE_LAB_PROFILE else ('ВКЛ' if EVENT_PAPER_ENABLED else 'ВЫКЛ')}",
        f"Лимит контура: {EVENT_CAPITAL_POOL_PERCENT:.0f}% депозита = {cap:,.2f} USDT",
        f"Сейчас занято: {used:,.2f} USDT ({(used / initial * 100 if initial else 0):.1f}% депозита)",
        f"Открытых сделок: {trades.get('open', 0)}",
        f"Событийных кандидатов: {research.get('total', 0)} | усиленных наблюдений: {watches.get('total', 0)}",
        f"Сейчас наблюдается: {watches.get('active', 0)} | подтверждено: {watches.get('confirmed', 0)} | отменено: {watches.get('cancelled', 0)}",
        f"Слишком поздних входов отклонено: {watches.get('late', 0)} | покупок при перекупленности: {watches.get('overbought', 0)}",
        f"Новых локальных баз: {watches.get('dynamic_bases', 0)} | микро-откатов: {watches.get('micro_pullbacks', 0)}",
        f"Ожидают безопасную базу: {watches.get('waiting_for_base', 0)}",
        f"Закрыто: {trades.get('closed', 0)} | Доля прибыльных: {float(trades.get('win_rate_percent') or 0):.1f}% | "
        f"Результат закрытых: {float(trades.get('realized_pnl_usdt') or 0):+,.2f} USDT",
        "Обычный событийный транш: 5% или 10% депозита; при экстремальной перекупленности размер уменьшается настройкой риска.",
        f"Перед входом нужны {autonomous.event_watch_engine.config.confirmations_required} последовательных подтверждения на закрытых минутных свечах.",
        "",
        "Активные наблюдения:",
    ]
    active_watches = [item for item in watches.get("recent") or [] if item.get("state") in autonomous.event_momentum_journal.ACTIVE_WATCH_STATES]
    if not active_watches:
        lines.append("• Сейчас усиленных наблюдений нет.")
    for watch in active_watches[:5]:
        source = "новость подтверждена" if watch.get("event_type") == "VERIFIED_NEWS_EVENT" else "только реакция рынка"
        lines.append(
            f"• {watch.get('symbol')} | {display_event_status(watch.get('state'))} | "
            f"подтверждений {watch.get('confirmations', 0)}/{autonomous.event_watch_engine.config.confirmations_required} | {source}"
        )
    lines.extend([
        "",
        "Открытые / последние сделки:",
    ])
    recent_trades = trades.get("recent") or []
    if not recent_trades:
        lines.append("• Пока нет покупок по новостному контуру.")
    for trade in recent_trades[:8]:
        status = trade.get("status") or "—"
        lines.append(
            f"• {trade.get('symbol')} | {display_event_status(status)} | Оценка события {trade.get('event_score')}/100 | "
            f"{float(trade.get('allocation_percent') or 0):.1f}% депозита | вход {float(trade.get('entry_price') or 0):g}"
        )
        news_items = trade.get("news") or []
        if news_items:
            headline = " ".join(str(news_items[0].get("title") or "").split())
            if len(headline) > 120:
                headline = headline[:119] + "…"
            lines.append(f"  📰 {headline}")
        plan = trade.get("plan") or {}
        targets = plan.get("targets") or []
        if targets:
            target_names = {"TP1": "Цель 1", "TP2": "Цель 2", "TP3": "Цель 3"}
            lines.append("  Цели: " + " | ".join(
                f"{target_names.get(str(x.get('name')).upper(), 'Цель')} {float(x.get('price') or 0):g}" for x in targets[:3]
            ))
        if plan.get("stop_price"):
            lines.append(f"  Защита: {float(plan.get('stop_price')):g}")

    lines.extend([
        "",
        f"Исследовательских кандидатов сохранено: {research.get('total', 0)}",
        "Правило входа: подтверждённая новость либо особенно сильная рыночная реакция + импульс 1H/4H + "
        "пробой суточного уровня + расширение объёма + приемлемая ликвидность + минутное подтверждение.",
        "Если архив новостей не покрывает период, сигнал называется рыночным, а не новостным.",
        "Основная стратегия учитывается отдельно: новости не добавляют ей баллы.",
    ])
    return "\n".join(lines)[:4000]


def build_daily_report_text() -> str:
    report = journal.decision_diagnostics(24)
    counts = report.get("decision_counts") or {}
    latest = journal.latest_automation_run() or {}
    portfolio = (latest.get("summary") or {}).get("portfolio") or {}
    equity = float(portfolio.get("equity_usdt") or journal.initial_capital())
    result = float(portfolio.get("total_return_percent") or 0)
    event = autonomous.event_momentum_journal.trade_summary(limit=1)
    return (
        "📅 СУТОЧНАЯ СВОДКА SPOT AI\n"
        f"Циклов: {report.get('cycles', 0)} | Проверок: {report.get('evaluations', 0)}\n"
        f"Кандидатов: {report.get('candidates', 0)} | Покупок: {report.get('purchases', 0)}\n"
        f"Купить частично: {counts.get('BUY_PARTIALLY',0)} | Наращивать: {counts.get('ACCUMULATE',0)} | "
        f"Подождать: {counts.get('WAIT',0)} | Не покупать: {counts.get('AVOID',0)}\n"
        f"Капитал: {equity:,.2f} USDT | Результат: {result:+.2f}% | "
        f"Свободно: {journal.available_cash():,.2f} USDT\n"
        f"Новостной контур: {event.get('open',0)} открыто | "
        f"{float(event.get('open_allocation_usdt') or 0):,.2f} USDT занято\n"
        "Сводка информационная; все операции виртуальные."
    )


def build_diagnostics_text(hours: int) -> str:
    report = journal.decision_diagnostics(hours)
    labels = {24: "24ч", 72: "72ч", 168: "7д"}
    counts = report.get("decision_counts") or {}
    lines = [
        f"🔬 ДИАГНОСТИКА РЕШЕНИЙ — {labels.get(hours, str(hours) + 'ч')}",
        f"Циклов: {report['cycles']}",
        f"Активов: {report['unique_assets']}",
        f"Проверок: {report['evaluations']}",
        f"Кандидатов: {report['candidates']} (из списка {report['candidate_pool']})",
        f"Покупок: {report['purchases']}",
        "",
        "Решения:",
    ]
    for decision in (
        "BUY_PARTIALLY", "ACCUMULATE", "WAIT", "HOLD", "REDUCE",
        "TAKE_PROFIT", "EXIT_ON_RISK", "AVOID",
    ):
        lines.append(f"{display_decision(decision)}: {counts.get(decision, 0)}")
    lines.extend(["", "Основные причины отсутствия покупки:"])
    reasons = report.get("top_no_buy_reasons") or []
    if not reasons:
        lines.append("Нет данных за период.")
    for index, item in enumerate(reasons[:3], start=1):
        lines.append(f"{index}. {display_reason(item['reason'])} — {item['count']}")
    if report.get("errors"):
        lines.append(f"Ошибок/таймаутов: {report['errors']}")
    return "\n".join(lines)


def build_diagnostics_detail_text(hours: int) -> str:
    report = journal.decision_diagnostics(hours, detail_limit=20)
    lines = [f"📋 ПОДРОБНО — {hours}ч", "Причины:"]
    for item in (report.get("top_no_buy_reasons") or [])[:10]:
        lines.append(f"• {display_reason(item['reason'])}: {item['count']}")
    lines.append("\nПроверки качества:")
    for gate, stats in (report.get("quality_gate_pass_rates") or {}).items():
        lines.append(
            f"• {display_gate(gate)}: проверено {stats['evaluated']}, прошло {stats['pass']}, "
            f"не прошло {stats['fail']} ({stats['fail_rate_percent']}%)"
        )
    details = report.get("evaluations_detail") or []
    if details:
        lines.append("\nПоследние проверки:")
        for item in details[:12]:
            lines.append(
                f"• {item['symbol']} · {display_decision(item.get('final_decision') or item.get('evaluation_status'))} "
                f"| {display_reason(item.get('primary_reason'))}"
                + (f" | ограничение: {display_reason(item['execution_blocker'])}" if item.get("execution_blocker") else "")
            )
    if len(lines) == 3:
        lines.append("Нет данных за период.")
    return "\n".join(lines)[:4000]


def replay_keyboard() -> InlineKeyboardMarkup:
    running = replay_task is not None and not replay_task.done()
    rows = [
        [_btn("▶️ Новый тест", "replay_new_start"), _btn("📅 Годовой тест", "replay_year_menu")],
        [_btn("✍️ Произвольный период", "replay_custom_dates"), _btn("⚖️ Сравнить слои стратегии", "replay_compare_start")],
    ]
    if running:
        rows.append([_btn("📈 Прогресс", "replay_status")])
        paused = bool(replay_runner and replay_runner.pause_event.is_set())
        rows.append([_btn("▶️ Продолжить" if paused else "⏸ Приостановить", "replay_resume" if paused else "replay_pause"), _btn("⛔ Остановить", "replay_stop")])
    rows.extend([[_btn("📚 История тестов", "replay_history")], [_btn("⬅️ Главное меню", "main_menu")]])
    return InlineKeyboardMarkup(rows)


def settings_keyboard() -> InlineKeyboardMarkup:
    daily_enabled = bool(_ui_cached("daily_report_enabled", lambda: journal.get_config("daily_report_enabled", False)))
    profile = _strategy_profile()
    profile_label = "🧊 Режим: CORE LAB" if profile == CORE_LAB_PROFILE else "⚪ Режим: FULL"
    return InlineKeyboardMarkup([
        [_btn(profile_label, "settings_profile")],
        [_btn("💰 Изменить капитал", "settings_capital")],
        [_btn("⏱ Интервал автосканирования", "settings_interval")],
        [_btn("🪙 Размер списка монет", "settings_universe"), _btn("🎯 Лимит кандидатов", "settings_candidates")],
        [_btn("📦 Максимум позиций", "settings_positions")],
        [_btn("🔕 Выключить суточную сводку" if daily_enabled else "🔔 Включить суточную сводку",
              "settings_daily_off" if daily_enabled else "settings_daily_on")],
        [_btn("⬅️ Главное меню", "main_menu")],
    ])


def settings_preset_keyboard(kind: str) -> InlineKeyboardMarkup:
    definitions = {
        "settings_interval": ("auto_scan_interval_seconds",300,(300,600,900,1800),lambda value:f"{value//60} мин"),
        "settings_universe": ("auto_universe_size",30,(10,20,30,50),lambda value:str(value)),
        "settings_candidates": ("auto_candidate_limit",5,(3,5,8,10),lambda value:str(value)),
        "settings_positions": ("max_open_ideas",5,(3,5,8,10),lambda value:str(value)),
        "settings_capital": ("capital_usdt",1000,(500,1000,2500,5000),lambda value:str(value)),
    }
    if kind not in definitions:
        raise ValueError("UNKNOWN_SETTINGS_PRESET")
    key,default,values,labeler=definitions[kind]
    if kind=="settings_capital" and hasattr(journal,"initial_capital"):
        try: current=float(journal.initial_capital())
        except Exception: current=float(journal.get_config(key,default))
    else:
        current=float(journal.get_config(key,default))
    buttons=[]
    for value in values:
        label=labeler(value)+(" ✅" if abs(current-float(value))<1e-9 else "")
        buttons.append(_btn(label,f"setting_value:{kind}:{value}"))
    return InlineKeyboardMarkup([
        buttons[:2],buttons[2:],
        [_btn("✍️ Ввести вручную",f"setting_manual:{kind}")],
        [_btn("⬅️ Настройки","settings_menu")],
    ])


def _quick_config() -> HistoricalReplayConfig:
    return HistoricalReplayConfig(
        start="2026-08-18", end="2026-08-20", frequency="4h",
        mode="verified_news", strategy_mode="full", universe_mode="fixed", capital=1000,
        universe_size=1, candidate_limit=1, max_open_positions=1,
        performance_mode="balanced",
    )


def replay_year_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("2020", "replay_year:2020"), _btn("2021", "replay_year:2021"), _btn("2022", "replay_year:2022")],
        [_btn("2023", "replay_year:2023"), _btn("2024", "replay_year:2024"), _btn("2025", "replay_year:2025")],
        [_btn("2026 — с начала года", "replay_year:2026")],
        [_btn("⬅️ Назад", "rw:back")],
    ])



def replay_period_keyboard(compare: bool = False) -> InlineKeyboardMarkup:
    prefix = "replay_compare_period" if compare else "replay_period"
    return InlineKeyboardMarkup([
        [_btn("Последние 3 месяца", f"{prefix}:3m"), _btn("Последние 6 месяцев", f"{prefix}:6m")],
        [_btn("Последний полный год", f"{prefix}:1y")],
        [_btn("✍️ Указать даты вручную", f"{prefix}:custom")],
        [_btn("⬅️ Назад", "replay_menu")],
    ])


def replay_frequency_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("4 часа", "rf:4h"), _btn("1 день", "rf:1d"), _btn("1 неделя", "rf:1w")],
        [_btn("⬅️ Назад", "rw:back")],
    ])


def replay_mode_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [_btn("📈 Только рынок", "rm:market_only")],
        [_btn("🌍 Рынок + макроэкономика", "rm:macro_only")],
        [_btn("📰 Рынок + макро + крипто-новости", "rm:verified_news")],
        [_btn("⬅️ Назад", "rw:back")],
    ])


def replay_symbol_keyboard(draft: dict) -> InlineKeyboardMarkup:
    page = symbol_page(draft)
    selected = set(draft.get("selected_symbols") or ())
    rows = []
    for index in range(0, len(page.items), 2):
        pair = []
        for symbol in page.items[index:index + 2]:
            short = symbol.removesuffix("USDT")
            pair.append(_btn(
                f"{'✅' if symbol in selected else '☐'} {short}",
                f"rs:t:{symbol}",
            ))
        rows.append(pair)
    if page.pages > 1:
        nav = []
        if page.page > 0:
            nav.append(_btn("⬅️", f"rs:p:{page.page - 1}"))
        nav.append(_btn(f"{page.page + 1}/{page.pages}", f"rs:p:{page.page}"))
        if page.page + 1 < page.pages:
            nav.append(_btn("➡️", f"rs:p:{page.page + 1}"))
        rows.append(nav)
    rows.extend([
        [_btn("✅ Выбрать все", "rs:all"), _btn("❌ Снять все", "rs:none")],
        [_btn("⭐ Основные", "rs:core"), _btn("🔥 Текущий список", "rs:runtime")],
        [_btn("✍️ Добавить вручную", "rs:manual")],
        [_btn("▶️ Продолжить", "rs:continue")],
        [_btn("⬅️ Назад", "rw:back")],
    ])
    return InlineKeyboardMarkup(rows)


def _symbol_selection_text(draft: dict) -> str:
    selected = list(draft.get("selected_symbols") or ())
    return (
        "🪙 ВЫБОР МОНЕТ\n"
        "Нажатие добавляет или снимает выбор. Список хранится в текущем мастере.\n\n"
        f"Выбрано: {len(selected)}\n"
        + (", ".join(symbol.removesuffix("USDT") for symbol in selected[:20]) if selected else "Пока ничего не выбрано")
    )


async def _prepare_replay_symbols(context: ContextTypes.DEFAULT_TYPE) -> dict:
    draft = ensure_draft(context.user_data)
    if draft.get("available_symbols"):
        return draft
    runtime = await asyncio.to_thread(autonomous.effective_runtime_config)
    limit = int(runtime.get("auto_universe_size_effective") or 30)
    provider = autonomous.symbol_provider
    available_meta, runtime_symbols = await asyncio.gather(
        asyncio.to_thread(provider.get_exchange_symbols),
        asyncio.to_thread(provider.get_top_symbols, limit),
    )
    set_available_symbols(draft, available_meta.keys(), runtime_symbols)
    apply_preset(draft, PRESET_RUNTIME)
    return draft


async def _show_replay_symbols(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        draft = await _prepare_replay_symbols(context)
    except Exception:
        logger.exception("historical_symbol_catalog_failed")
        await _edit_or_reply(
            update,
            "Не удалось проверить список Spot-пар Binance. Ничего не подставлено автоматически.",
            InlineKeyboardMarkup([[_btn("⬅️ Назад", "rw:back")]]),
        )
        return
    await _edit_or_reply(update, _symbol_selection_text(draft), replay_symbol_keyboard(draft))


def _coverage_preview(cfg: HistoricalReplayConfig, symbols: list[str]) -> list[dict]:
    return [
        cached_symbol_coverage(
            cache_root="data/replay_cache", symbol=symbol,
            interval=cfg.frequency, start=cfg.start, end=cfg.end,
        )
        for symbol in symbols
    ]


def _preflight_text(cfg: HistoricalReplayConfig, symbols: list[str], compare: bool) -> tuple[str, bool]:
    store = PointInTimeStore.from_jsonl("data/point_in_time_events.jsonl")
    preflight = build_context_preflight(
        mode="verified_news" if compare else cfg.mode,
        start=cfg.start, end=cfg.end, store=store,
        allow_fallback=False,
    )
    capability = {"AVAILABLE": "ДОСТУПНО", "PARTIAL": "ЧАСТИЧНО", "UNAVAILABLE": "НЕДОСТУПНО"}
    lines = [
        "🔎 ПРОВЕРКА ДАННЫХ ПЕРЕД ЗАПУСКОМ",
        "",
        f"Рыночные данные: проверка по {len(symbols)} выбранным монетам",
        f"Историческая макроэкономика: {capability.get(preflight.macro.status, preflight.macro.status)}",
        f"Исторические крипто-новости: {capability.get(preflight.news.status, preflight.news.status)}",
        "",
        "Покрытие локального кэша за выбранный период:",
    ]
    coverage = _coverage_preview(cfg, symbols)
    for item in coverage[:15]:
        status = item["status"]
        percent = item.get("coverage_percent")
        value = "ещё не загружено" if percent is None else f"{percent:.1f}%"
        lines.append(f"• {item['symbol']}: {value} ({status})")
    if len(coverage) > 15:
        lines.append(f"• ещё монет: {len(coverage) - 15}")
    lines.extend(["", _replay_config_text(cfg, symbols, compare)])
    if compare:
        lines.extend([
            "", "Будут выполнены ровно 4 последовательных запуска:",
            "1. Базовая стратегия",
            "2. Базовая + оборот капитала",
            "3. Базовая + новости/события",
            "4. Полная текущая стратегия",
        ])
    if preflight.confirmation_required:
        lines.extend([
            "",
            "Выбранный внешний контекст покрыт не полностью. "
            "Сравнение не сможет честно измерить вклад отсутствующих новостей или макроэкономики.",
            "Продолжение возможно только с явной отметкой КОНТЕКСТ ОГРАНИЧЕН.",
        ])
    return "\n".join(lines)[:3900], bool(preflight.confirmation_required)


async def _request_replay_preflight(
    update: Update, context: ContextTypes.DEFAULT_TYPE,
    cfg: HistoricalReplayConfig, symbols: list[str], compare: bool,
) -> None:
    text, requires_fallback = await asyncio.to_thread(
        _preflight_text, cfg, symbols, compare,
    )
    context.user_data["replay_pending_run"] = {
        "config": asdict(cfg), "symbols": list(symbols),
        "compare": bool(compare), "requires_fallback": requires_fallback,
    }
    label = "Продолжить с доступным контекстом" if requires_fallback else "▶️ Запустить"
    await _edit_or_reply(update, text, InlineKeyboardMarkup([
        [_btn(label, "replay_preflight_confirm")],
        [_btn("❌ Отмена", "replay_menu")],
    ]))

def _period_dates(code: str) -> tuple[str, str]:
    today = datetime.now(timezone.utc).date()
    end = today - timedelta(days=1)
    if code == "3m":
        start = end - timedelta(days=89)
    elif code == "6m":
        start = end - timedelta(days=179)
    elif code == "1y":
        start = end - timedelta(days=364)
    else:
        raise ValueError("unknown period preset")
    return start.isoformat(), end.isoformat()

def _replay_config_text(cfg: HistoricalReplayConfig, symbols: list[str] | None = None, compare: bool = False) -> str:
    mode_names = {
        "market_only": "Только рынок",
        "macro_only": "Рынок + макро",
        "verified_news": "Рынок + макро + проверенные новости",
    }
    strategy_names = {
        "baseline":"Базовая стратегия", "baseline_recycling":"Базовая + оборот капитала",
        "baseline_news_event":"Базовая + новости/события", "full":"Полная текущая стратегия",
    }
    load_name = {"eco": "экономная", "balanced": "сбалансированная", "fast": "быстрая"}.get(cfg.performance_mode, "сбалансированная")
    frequency_name = {"4h": "4 часа", "1d": "1 день", "1w": "1 неделя"}.get(
        cfg.frequency, cfg.frequency,
    )
    lines = [
        "🧪 ПАРАМЕТРЫ ИСТОРИЧЕСКОГО ТЕСТА",
        f"Период: {cfg.start} → {cfg.end}",
        f"Период данных: {frequency_name}",
        f"Информационный контекст: {mode_names.get(cfg.mode, cfg.mode)}",
        f"Слои стратегии: {'4 последовательных запуска' if compare else strategy_names.get(cfg.strategy_mode, cfg.strategy_mode)}",
        f"Список монет: {'динамический' if cfg.universe_mode == 'dynamic' else 'ручной'}",
        f"Капитал: {cfg.capital:,.2f} USDT",
        f"Монет: {cfg.universe_size}",
        f"Кандидатов: {cfg.candidate_limit}",
        f"Позиций: {cfg.max_open_positions}",
        f"Нагрузка: {load_name}",
    ]
    if symbols:
        lines.append("Монеты: " + ", ".join(symbols))
    if compare:
        lines.append("Количество запусков: 4")
    return "\n".join(lines)


async def access_guard(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    if chat is None or not ALLOWED_CHAT_IDS or chat.id not in ALLOWED_CHAT_IDS:
        if update.effective_message:
            await update.effective_message.reply_text("Доступ для этого чата не настроен.")
        raise ApplicationHandlerStop


async def _edit_or_reply(update: Update, text: str, markup: InlineKeyboardMarkup | None = None):
    if update.callback_query:
        try:
            await update.callback_query.edit_message_text(text, reply_markup=markup)
            return
        except BadRequest:
            pass
    await update.effective_message.reply_text(text, reply_markup=markup)


async def _render_ui_async(update: Update, text_builder, markup_builder=None):
    """Build DB-heavy menu content outside the Telegram event loop."""
    text = await asyncio.to_thread(text_builder)
    markup = await asyncio.to_thread(markup_builder) if markup_builder else None
    await _edit_or_reply(update, text, markup)


async def start(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    await _edit_or_reply(
        update,
        f"Spot Investment AI v{VERSION}\n"
        "Выберите нужное действие. Автоматическая проверка рынка работает по своему расписанию; "
        "все операции в этом боте виртуальные.\n\n"
        "Технические инструменты и аварийное управление находятся в разделе «Сервис».",
        main_keyboard(),
    )


async def analyze(update: Update, context: ContextTypes.DEFAULT_TYPE):
    symbol = (context.args[0] if context.args else "BTCUSDT").upper()
    message = await update.effective_message.reply_text(f"Анализирую {symbol}…")
    try:
        price = await asyncio.to_thread(engine.market_data.get_current_price, symbol)
        position = journal.position(symbol, price)
        result = await asyncio.to_thread(engine.analyze, symbol, position, journal.positions())
        payload = result.to_dict(); journal.save_analysis(payload)
        await message.edit_text(format_analysis(payload))
    except Exception:
        logger.exception("single_symbol_analysis_failed symbol=%s", symbol)
        await message.edit_text("Анализ не выполнен. Подробности сохранены в журнале приложения.")


async def _prices_for_positions() -> dict[str, float]:
    prices = {}
    for position in journal.positions():
        try:
            prices[position.symbol] = await asyncio.to_thread(engine.market_data.get_current_price, position.symbol)
        except RuntimeError:
            continue
    return prices


async def show_portfolio(update: Update):
    prices = await _prices_for_positions()
    snapshot = await asyncio.to_thread(journal.portfolio_snapshot, prices)
    text = format_portfolio(snapshot)
    text += "\n\nОборот капитала и новостной контур: Сервис."
    await _edit_or_reply(update, text, await asyncio.to_thread(main_keyboard))


async def portfolio(update: Update, _context: ContextTypes.DEFAULT_TYPE): await show_portfolio(update)


async def history(update: Update, _context: ContextTypes.DEFAULT_TYPE, page: int = 0):
    page = max(0, int(page))
    total = await asyncio.to_thread(journal.transactions_count)
    if total <= 0:
        await _edit_or_reply(update, format_history([]), history_keyboard(0, 0))
        return
    # The journal helper computes realized PnL chronologically. Request only as
    # much history as needed for the selected page, then slice the newest rows.
    needed = min(total, (page + 1) * HISTORY_PAGE_SIZE)
    rows = await asyncio.to_thread(journal.recent_transactions_with_realized_pnl, needed)
    start = page * HISTORY_PAGE_SIZE
    page_rows = rows[start:start + HISTORY_PAGE_SIZE]
    if not page_rows and page > 0:
        page = max(0, (total - 1) // HISTORY_PAGE_SIZE)
        needed = min(total, (page + 1) * HISTORY_PAGE_SIZE)
        rows = await asyncio.to_thread(journal.recent_transactions_with_realized_pnl, needed)
        start = page * HISTORY_PAGE_SIZE
        page_rows = rows[start:start + HISTORY_PAGE_SIZE]
    text = format_history(page_rows)
    await _edit_or_reply(update, text, history_keyboard(page, total))


async def chart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await _edit_or_reply(update, "📈 Выбери монету для графика сделок.", chart_symbol_keyboard())
        return
    symbol = context.args[0].upper()
    period = context.args[1].lower() if len(context.args) > 1 else "90d"
    await send_trade_chart(update, context, symbol, period)


async def capital(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await _edit_or_reply(update, f"Текущий капитал: {journal.initial_capital():,.2f} USDT\nОткрой Настройки → Изменить капитал.", settings_keyboard())
        return
    try:
        journal.set_initial_capital(float(context.args[0]))
        await _edit_or_reply(update, f"Виртуальный капитал установлен: {journal.initial_capital():,.2f} USDT", main_keyboard())
    except ValueError:
        await _edit_or_reply(update, "Капитал должен быть положительным числом.", settings_keyboard())


async def status(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    text = await asyncio.to_thread(build_status_text)
    await _edit_or_reply(update, text, InlineKeyboardMarkup([
        [_btn("📋 Подробнее", "status_detail")],
        [_btn("⬅️ Сервис", "service_menu")],
    ]))


async def diagnostics(update: Update, _context: ContextTypes.DEFAULT_TYPE, hours: int = 24):
    text = await asyncio.to_thread(build_diagnostics_text, hours)
    await _edit_or_reply(update, text, diagnostics_keyboard(hours))


async def _safe_edit(message, text: str, reply_markup=None) -> None:
    try: await message.edit_text(text, reply_markup=reply_markup)
    except BadRequest as error:
        if "message is not modified" not in str(error).lower(): raise


async def _run_manual_cycle(application: Application, chat_id: int, progress_message) -> None:
    worker = asyncio.create_task(asyncio.to_thread(autonomous.run_cycle))
    try:
        while not worker.done():
            await asyncio.sleep(TELEGRAM_PROGRESS_UPDATE_SECONDS)
            await _safe_edit(progress_message, format_cycle_progress(autonomous.cycle_status()))
        summary = await worker
        for action in summary.get("actions") or []:
            text = format_action(action)
            if text: await application.bot.send_message(chat_id, text)
        await _safe_edit(progress_message, format_cycle(summary), main_keyboard())
    except asyncio.CancelledError:
        worker.cancel(); raise
    except Exception:
        logger.exception("manual_cycle_ui_failed")
        await _safe_edit(progress_message, "Проверка рынка завершилась ошибкой. Подробности сохранены в журнале приложения.", main_keyboard())


async def run_cycle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if autonomous.is_running():
        await _edit_or_reply(update, format_cycle_progress(autonomous.cycle_status()), main_keyboard()); return
    progress_message = await update.effective_message.reply_text("🔄 Внеочередная проверка рынка запущена в фоне.")
    task = context.application.create_task(_run_manual_cycle(context.application, update.effective_chat.id, progress_message), name=f"manual-paper-cycle-{update.effective_chat.id}")
    context.application.bot_data["manual_cycle_task"] = task


async def sources(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    message = await update.effective_message.reply_text("Проверяю источники…")
    report = await asyncio.to_thread(PreflightChecker(network=True).run)
    provider_prefixes = (
        "binance", "coingecko", "fred", "yahoo", "official_news",
        "fed_rss", "sec_rss", "ethereum_official", "bitcoin_official",
        "cryptopanic", "defillama", "etherscan", "blockstream", "solana",
        "token_unlock", "onchain", "whale", "telegram",
    )
    fallback = {
        "fred_connectivity": "резервный источник; отсутствие контекста нейтрально",
        "cryptopanic": "official RSS",
        "token_unlock": "нет данных; оценка не ухудшается",
        "onchain": "нет данных; оценка не ухудшается",
        "etherscan": "другие сетевые источники; отсутствие нейтрально",
        "etherscan_connectivity": "другие сетевые источники; отсутствие нейтрально",
        "solana_rpc_connectivity": "сетевой контекст отсутствует и нейтрален",
    }
    checks = [
        item for item in report["checks"]
        if item["name"].startswith(provider_prefixes)
    ]
    for item in checks:
        status_name = {"PASS": "READY", "WARN": "WARNING", "FAIL": "UNAVAILABLE"}.get(
            item["status"], "WARNING"
        )
        journal.record_provider_health(
            item["name"], status_name,
            detail={"detail": item["detail"], "checked_at": report.get("checked_at")},
            fallback=fallback.get(item["name"]),
            observed_at=report.get("checked_at"),
        )
    summary = {item["provider"]: item for item in journal.provider_health_summary()}
    overall = {"PASS": "в порядке", "WARN": "есть предупреждения", "FAIL": "недоступны важные источники"}.get(report["status"], "есть предупреждения")
    lines = [f"🔌 ИСТОЧНИКИ ДАННЫХ — {overall}"]
    for item in checks:
        health = summary.get(item["name"], {})
        lines.append(
            f"• {item['name']}: {display_provider_status(health.get('status', 'WARNING'))}"
            f" | последнее получение: {_iso_age(health.get('last_success'))}"
            + (f" | резерв: {health['fallback']}" if health.get("fallback") else "")
        )
    warnings = [item for item in checks if item["status"] != "PASS"]
    if warnings:
        lines.append("\nПредупреждения: часть источников временно недоступна или требует проверки. Это не является рыночным сигналом.")
    await message.edit_text("\n".join(lines)[:4000], reply_markup=service_keyboard())


def _replay_runs(limit: int = 20) -> list[Path]:
    root = Path("output"); root.mkdir(exist_ok=True)
    return sorted([p for p in root.glob("replay_*") if p.is_dir()], key=lambda p:p.stat().st_mtime, reverse=True)[:limit]


def _read_summary(run: Path) -> dict:
    try: return json.loads((run/"summary.json").read_text(encoding="utf-8"))
    except Exception: return {"path":str(run),"name":run.name}


def replay_history_keyboard() -> tuple[str, InlineKeyboardMarkup]:
    runs = _replay_runs(10)
    if not runs: return "Исторических тестов пока нет.", InlineKeyboardMarkup([[_btn("⬅️ Назад", "replay_menu")]])
    rows=[]; lines=["📚 ИСТОРИЯ ТЕСТОВ"]
    for i,run in enumerate(runs):
        s=_read_summary(run); validity=s.get("replay_validity") or s.get("context_validity") or "СТАРЫЙ ОТЧЁТ"
        label=f"{i+1}. {s.get('frequency','?')} · {s.get('return_pct','?')}% · {validity}"
        mode = {"market_only": "только рынок", "macro_only": "рынок и макро", "verified_news": "рынок, макро и новости"}.get(str(s.get("mode")), "—")
        fixed=s.get("fixed_symbols") or []
        symbol_text=", ".join(symbol.removesuffix("USDT") for symbol in fixed[:4]) if fixed else f"до {s.get('universe_size','?')} монет"
        lines.append(
            f"{i+1}. v{s.get('version','?')} | {s.get('start','?')}–{s.get('end','?')} | "
            f"{s.get('frequency','?')} | {mode} | {symbol_text} | "
            f"{s.get('return_pct','?')}% | просадка {s.get('max_drawdown_pct','?')}% | "
            f"операций {s.get('trades','?')} | {validity}"
        )
        rows.append([_btn(label, f"replay_run:{i}")])
    rows.append([_btn("⬅️ Исторический тест", "replay_menu")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _format_replay_result(summary: dict, run_dir: Path) -> str:
    universe_mode = str(summary.get("universe_mode", "?")).upper()
    mode = {"market_only": "только рынок", "macro_only": "рынок и макро", "verified_news": "рынок, макро и проверенные новости"}.get(str(summary.get("mode")), "не указан")
    lines = [
        "✅ Исторический тест завершён",
        f"Версия: v{summary.get('version', VERSION)}",
        f"Период: {summary.get('start')}–{summary.get('end')}",
        f"Период данных: {str(summary.get('frequency', '?')).upper()}",
        f"Режим: {mode}",
        f"Список монет: {'фиксированный' if universe_mode == 'FIXED' else 'динамический'}",
    ]
    fixed = summary.get("fixed_symbols") or []
    if universe_mode == "FIXED":
        lines.append("Монеты: " + (", ".join(fixed) if fixed else "не указаны"))
    else:
        lines.append(f"Размер списка монет: {summary.get('universe_size', '?')}")
    lines.extend([
        f"Кандидатов: {summary.get('candidate_limit', '?')}",
        f"Макс. позиций: {summary.get('max_open_positions', '?')}",
        f"Стартовый капитал: {float(summary.get('initial_capital', 0)):,.2f} USDT",
        f"Итоговая стоимость по рынку: {float(summary.get('ending_mtm_equity_usdt', summary.get('final_equity', 0))):,.2f} USDT",
        f"Доходность: {summary.get('return_pct', 0)}%",
        f"Просадка: {summary.get('max_drawdown_pct', 0)}%",
        f"Свободные USDT: {float(summary.get('free_cash_usdt', summary.get('final_cash_usdt', 0))):,.2f}",
        f"Зарезервировано для ожидающих покупок: {float(summary.get('reserved_cash_usdt', 0)):,.2f} USDT",
        f"Себестоимость открытых позиций: {float(summary.get('cost_basis_open_positions_usdt', 0)):,.2f} USDT",
        f"Рыночная стоимость открытых позиций: {float(summary.get('market_value_open_positions_usdt', summary.get('final_invested_usdt', 0))):,.2f} USDT",
        f"Зафиксированный результат: {float(summary.get('realized_pnl_usdt', 0)):+,.2f} USDT",
        f"Нереализованный результат: {float(summary.get('unrealized_pnl_usdt', 0)):+,.2f} USDT",
        f"Покупок: {int(summary.get('buys', 0))}",
        f"Продаж: {int(summary.get('sell_actions', 0))}",
        f"Циклов: {summary.get('cycles_completed', 0)}",
        f"Комиссии: {summary.get('fees_usdt', 0)} USDT",
        f"Проскальзывание: {summary.get('slippage_usdt', 0)} USDT",
        f"Данные: {summary.get('replay_validity', 'статус не указан')}",
        f"Контекст: {summary.get('context_validity', 'статус не указан')}",
    ])
    positions = summary.get("open_positions") or []
    if positions:
        lines.extend(["", "Открытые позиции:"])
        for row in positions[:12]:
            lines.append(
                f"• {row.get('symbol')}: {float(row.get('quantity') or 0):.8f} | "
                f"средняя {float(row.get('average_price') or 0):,.4f} | "
                f"последняя {float(row.get('last_price') or 0):,.4f} | "
                f"стоимость {float(row.get('market_value_usdt') or 0):,.2f} USDT | "
                f"результат {float(row.get('unrealized_pnl_usdt') or 0):+,.2f} USDT"
            )
    close_all = summary.get("hypothetical_close_all") or {}
    lines.extend([
        "",
        "Если закрыть все позиции по последней цене теста:",
        f"Расчётная комиссия: {float(close_all.get('estimated_closing_fee_usdt') or 0):,.2f} USDT",
        f"Расчётное проскальзывание: {float(close_all.get('estimated_closing_slippage_usdt') or 0):,.2f} USDT",
        f"Расчётный итог: {float(close_all.get('estimated_final_usdt') or 0):,.2f} USDT" if close_all.get("estimated_final_usdt") is not None else "Расчётный итог: недоступен из-за отсутствующих цен",
    ])
    counts = summary.get("decision_counts") or {}
    if counts:
        order = ["ACCUMULATE","BUY_PARTIALLY","WAIT","HOLD","REDUCE","TAKE_PROFIT","EXIT_ON_RISK","AVOID"]
        rendered = [f"{display_decision(key)}: {counts.get(key, 0)}" for key in order if key in counts or counts.get(key, 0)]
        if rendered:
            lines.append("Решения: " + "; ".join(rendered))
    reasons = summary.get("top_rejection_reasons") or []
    if reasons:
        lines.append("Основные причины решений:")
        for item in reasons[:5]:
            lines.append(f"• {display_reason(item.get('reason'))}: {item.get('count')}")
    exec_reasons = summary.get("execution_rejection_reasons") or []
    if exec_reasons:
        lines.append(f"Отклонено исполнений: {summary.get('execution_rejections', 0)}")
        for item in exec_reasons[:5]:
            lines.append(f"• {display_reason(item.get('reason'))}: {item.get('count')}")
    if summary.get("mode") != "market_only":
        lines.append(
            f"Контекст: макро-события {summary.get('macro_events_used',0)} / изменений {summary.get('macro_context_changes',0)}; "
            f"новостные события {summary.get('news_events_used',0)} / изменений {summary.get('news_context_changes',0)}"
        )
        if summary.get("context_warning") != "OK":
            lines.append("⚠️ Исторический информационный контекст не использован: режим фактически не отличался по внешним данным.")
    benchmarks = summary.get("benchmarks") or {}
    available = [(name, data) for name, data in benchmarks.items() if isinstance(data, dict) and data.get("status") == "AVAILABLE"]
    if available:
        lines.append("Сравнение с ориентиром:")
        labels = {
            "BTC_BUY_HOLD":"BTC — купить и держать", "ETH_BUY_HOLD":"ETH — купить и держать", "SOL_BUY_HOLD":"SOL — купить и держать",
            "BTC_ETH_SOL_EQUAL_WEIGHT":"BTC/ETH/SOL: поровну", "BTC_ETH_SOL_DCA":"BTC/ETH/SOL: регулярные покупки",
        }
        for name, data in available:
            lines.append(f"• {labels.get(name,name)}: {data.get('return_pct',0)}%")
    duration = float(summary.get("duration_seconds", 0) or 0)
    lines.append(f"Длительность: {duration/60:.1f} мин")
    lines.append(f"Папка: {run_dir}")
    return "\n".join(lines)


def _format_replay_assets(summary: dict) -> str:
    rows = summary.get("asset_results") or []
    if not rows:
        return "🪙 ПО МОНЕТАМ\n\nОпераций и открытых позиций нет."
    lines = ["🪙 РЕЗУЛЬТАТ ПО МОНЕТАМ", ""]
    for row in rows[:40]:
        lines.extend([
            f"{row.get('symbol', '—')}",
            f"Покупок / продаж: {int(row.get('buys') or 0)} / {int(row.get('sells') or 0)}",
            f"Оборот: {float(row.get('turnover_usdt') or 0):,.2f} USDT",
            f"Зафиксировано: {float(row.get('realized_pnl_usdt') or 0):+,.2f} USDT",
            f"Не реализовано: {float(row.get('unrealized_pnl_usdt') or 0):+,.2f} USDT",
            f"Комиссии: {float(row.get('fees_usdt') or 0):,.2f} USDT",
            f"Стоимость в конце: {float(row.get('ending_market_value_usdt') or 0):,.2f} USDT",
            f"Вклад: {float(row.get('contribution_usdt') or 0):+,.2f} USDT",
            "",
        ])
    return "\n".join(lines)[:4000]


async def _run_replay_job(message, cfg: HistoricalReplayConfig, symbols: list[str]):
    global replay_runner, replay_task, replay_kind
    try:
        store = PointInTimeStore.from_jsonl("data/point_in_time_events.jsonl")
        replay_engine = SpotInvestmentEngine(point_in_time_store=store)
        replay_runner = HistoricalReplayRunner(replay_engine, cfg, symbols)
        summary, run_dir = await asyncio.to_thread(replay_runner.run, "output")
        await message.edit_text(_format_replay_result(summary, run_dir), reply_markup=replay_keyboard())
    except Exception:
        logger.exception("historical_replay_failed")
        await message.edit_text("Исторический тест завершился ошибкой. Подробности сохранены в журнале приложения.", reply_markup=replay_keyboard())
    finally:
        replay_task=None; replay_kind=None


def _format_compare_result(result: dict, root: Path) -> str:
    if "best" in result and "baseline_final_equity" not in result:
        best = result.get("best") or {}
        return "\n".join([
            "✅ Сравнение 9 режимов завершено",
            f"Запусков: {int(result.get('runs') or 0)}",
            # Legacy nine-run artifacts retain their historical label verbatim;
            # the current four-layer UI below is fully Russian.
            f"Лучший период данных / режим: {str(best.get('frequency') or '—').upper()} / {best.get('mode') or '—'}",
            f"Доходность: {float(best.get('return_pct') or 0):+.2f}%",
            f"Макс. просадка: {float(best.get('max_drawdown_pct') or 0):+.2f}%",
            f"Сделок: {int(best.get('trades') or 0)}",
            f"Коэффициент прибыльных к убыточным: {best.get('profit_factor') if best.get('profit_factor') is not None else '—'}",
            f"Папка: {root}",
            "Полная таблица сохранена в папке результатов.",
        ])
    return "\n".join([
        "✅ Сравнение четырёх вариантов завершено",
        f"Запусков: {int(result.get('runs') or 0)}",
        f"Базовая стратегия: {float(result.get('baseline_final_equity') or 0):,.2f} USDT",
        f"С оборотом капитала: {float(result.get('capital_recycling_final_equity') or 0):,.2f} USDT",
        f"С новостями/событиями: {float(result.get('news_event_final_equity') or 0):,.2f} USDT",
        f"Полная стратегия: {float(result.get('full_final_equity') or 0):,.2f} USDT",
        f"Вклад оборота капитала: {float(result.get('capital_recycling_contribution_usdt') or 0):+.2f} USDT",
        f"Вклад новостей/событий: {float(result.get('news_event_contribution_usdt') or 0):+.2f} USDT",
        f"Папка: {root}",
        "Полная таблица сохранена в папке результатов.",
    ])


async def _run_compare_job(message, cfg: HistoricalReplayConfig, symbols: list[str]):
    global replay_task, replay_kind, replay_runner
    try:
        store_path="data/point_in_time_events.jsonl"
        def factory(): return SpotInvestmentEngine(point_in_time_store=PointInTimeStore.from_jsonl(store_path))
        result, root = await asyncio.to_thread(compare_strategy_runs, factory, cfg, symbols, "output")
        await message.edit_text(_format_compare_result(result, root), reply_markup=replay_keyboard())
    except Exception:
        logger.exception("historical_compare_failed")
        await message.edit_text("Сравнение завершилось ошибкой. Подробности сохранены в журнале приложения.", reply_markup=replay_keyboard())
    finally:
        replay_task=None; replay_kind=None; replay_runner=None


async def _start_single_replay(update: Update, context: ContextTypes.DEFAULT_TYPE, cfg: HistoricalReplayConfig, symbols: list[str]):
    global replay_task, replay_kind
    if replay_task and not replay_task.done():
        await _edit_or_reply(update,"Исторический тест уже выполняется. Откройте «Прогресс».",replay_keyboard()); return
    msg=await update.effective_message.reply_text("🧪 Исторический тест запущен в фоне.")
    replay_kind="single"; replay_task=context.application.create_task(_run_replay_job(msg,cfg,symbols),name="historical-replay")


async def _start_compare(update: Update, context: ContextTypes.DEFAULT_TYPE, cfg: HistoricalReplayConfig, symbols: list[str]):
    global replay_task, replay_kind
    if replay_task and not replay_task.done():
        await _edit_or_reply(update,"Исторический тест уже выполняется. Откройте «Прогресс».",replay_keyboard()); return
    msg=await update.effective_message.reply_text("📊 Сравнение четырёх вариантов стратегии запущено последовательно. Это долгий тест.")
    replay_kind="compare"; replay_task=context.application.create_task(_run_compare_job(msg,cfg,symbols),name="replay-comparison")


async def replay_default(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cfg=_quick_config()
    await _edit_or_reply(update,_replay_config_text(cfg,["ETHUSDT"])+"\n\nЗапустить?",InlineKeyboardMarkup([[_btn("✅ Запустить","replay_quick_confirm"),_btn("❌ Отмена","replay_menu")]]))


async def replay_custom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args)<4:
        await _edit_or_reply(update,"Используй меню Исторический тест → Настроить тест.",replay_keyboard()); return
    start,end,frequency,mode=context.args[:4]; universe_mode=context.args[4] if len(context.args)>4 else "dynamic"; symbols=context.args[5].split(",") if len(context.args)>5 else []
    try:
        selected=mode.lower(); context_mode="verified_news" if selected=="full" else selected
        cfg=HistoricalReplayConfig(start=start,end=end,frequency=frequency.lower(),mode=context_mode,strategy_mode="full" if selected=="full" else "baseline",universe_mode=universe_mode.lower(),capital=1000,universe_size=30,candidate_limit=5,max_open_positions=5); cfg.validate()
    except Exception:
        await _edit_or_reply(update,"Параметры исторического теста некорректны.",replay_keyboard()); return
    await _start_single_replay(update,context,cfg,symbols)


async def replay_status_command(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    if not (replay_task and not replay_task.done()):
        await _edit_or_reply(update,"Исторический тест сейчас не выполняется.",replay_keyboard()); return
    if replay_kind=="compare" and replay_runner is None:
        await _edit_or_reply(update,"📈 Выполняется сравнение четырёх вариантов стратегии. Результаты сохраняются в папке теста.",replay_keyboard()); return
    p=replay_runner.progress if replay_runner else {}
    percent = max(0.0, min(100.0, float(p.get("percent") or 0.0)))
    stages = {"PREPARING": "подготовка", "RUNNING": "расчёт", "PAUSE_REQUESTED": "пауза запрошена", "STOPPING": "завершение", "FINISHED": "завершено"}
    current = p.get("current") or ""
    try:
        current = datetime.fromisoformat(str(current).replace("Z", "+00:00")).strftime("%d.%m.%Y %H:%M")
    except (TypeError, ValueError):
        current = current or "—"
    await _edit_or_reply(
        update,
        f"📈 Исторический тест: {percent:.1f}%\n"
        f"Циклы: {p.get('cycles_done', p.get('processed',0))}/{p.get('cycles_total', p.get('total',0))}\n"
        f"Монеты текущего цикла: {p.get('symbols_done_current_cycle',0)}/{p.get('symbols_total_current_cycle',0)}\n"
        f"Этап: {stages.get(p.get('stage'), 'расчёт')}\n"
        f"Текущая дата: {current}\n"
        f"Текущая монета: {p.get('symbol') or '—'}\n"
        f"Операций: {p.get('operations',0)}\n"
        f"Стоимость портфеля: {float(p.get('portfolio_value') or 0):,.2f} USDT",
        replay_keyboard(),
    )


async def replay_history_command(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    text,kb=replay_history_keyboard(); await _edit_or_reply(update,text,kb)


async def settings_command(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    runtime = await asyncio.to_thread(autonomous.effective_runtime_config)
    daily_enabled = bool(_ui_cached("daily_report_enabled", lambda: journal.get_config("daily_report_enabled", False)))
    reserve_target = float(_ui_cached("reserve_target", lambda: journal.get_config("last_cash_reserve_target_percent", MIN_CASH_RESERVE_PERCENT)))
    await _edit_or_reply(update,
        "🛠 НАСТРОЙКИ\n"
        f"Режим: {runtime.get('strategy_profile', FULL_PROFILE)}\n"
        f"Капитал: {runtime['capital_usdt_effective']:,.2f} USDT\n"
        f"Интервал проверки: {runtime['cycle_interval_seconds_effective'] // 60} мин.\n"
        f"Размер списка монет: {runtime['auto_universe_size_effective']}\n"
        f"Лимит кандидатов: {runtime['candidate_limit_effective']}\n"
        f"Максимум позиций: {runtime['max_open_ideas_effective']}\n"
        f"Суточная сводка: {'ВКЛ' if daily_enabled else 'ВЫКЛ'}\n"
        f"Целевой / минимальный резерв: {reserve_target:.1f}% / {float(HARD_CASH_RESERVE_PERCENT):.1f}%\n"
        "Настройки меняют только параметры запуска; правила отбора и риски не изменяются автоматически.",
        settings_keyboard())


def _set_input(context: ContextTypes.DEFAULT_TYPE, kind: str, **extra):
    context.user_data["input_state"]={"kind":kind,**extra}


async def text_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state=context.user_data.get("input_state")
    if not state: return
    value=(update.effective_message.text or "").strip(); kind=state["kind"]
    try:
        if kind=="replay_manual_symbol":
            draft=ensure_draft(context.user_data)
            symbol=normalize_symbol(value)
            if symbol not in set(draft.get("available_symbols") or ()):
                raise ValueError("Эта Spot-пара сейчас не поддерживается Binance")
            first = await asyncio.to_thread(
                autonomous.symbol_provider.market_data.get_first_daily_candle,
                symbol,
            )
            end_ms = int(datetime.combine(
                date.fromisoformat(draft["end"]), datetime.max.time(),
                tzinfo=timezone.utc,
            ).timestamp() * 1000)
            if not first or int(first.get("open_time") or 0) > end_ms:
                raise ValueError("За выбранный период исторические свечи недоступны")
            add_manual_symbol(draft, symbol)
            if (draft.get("step_stack") or [None])[-1] == "manual_symbol":
                back_step(draft)
            context.user_data.pop("input_state",None)
            await update.effective_message.reply_text(
                f"{symbol} добавлен. Полнота свечей будет показана до запуска.",
                reply_markup=replay_symbol_keyboard(draft),
            ); return
        if kind=="chart_symbol":
            symbol=value.upper().replace("/", "").replace("-", "")
            if not symbol.endswith("USDT"):
                symbol += "USDT"
            if not symbol.replace("USDT", "").isalnum():
                raise ValueError("Некорректный тикер")
            context.user_data.pop("input_state",None)
            await update.effective_message.reply_text(
                f"Период для {symbol}:", reply_markup=chart_period_keyboard(symbol)
            ); return
        if kind=="settings_capital":
            amount=float(value)
            if amount<=0: raise ValueError("Сумма должна быть положительной")
            context.user_data["pending_capital"]=amount; context.user_data.pop("input_state",None)
            await update.effective_message.reply_text(f"Начать новый виртуальный портфель с {amount:,.2f} USDT? Текущие позиции и журнал могут быть сброшены.",reply_markup=InlineKeyboardMarkup([[_btn("✅ Подтвердить","capital_confirm"),_btn("❌ Отмена","settings_menu")]])); return
        if kind.startswith("settings_"):
            num=int(value)
            minimum = {"settings_interval":60,"settings_universe":2}.get(kind,1)
            if num<minimum: raise ValueError(f"Минимальное значение: {minimum}")
            key={"settings_interval":"auto_scan_interval_seconds","settings_universe":"auto_universe_size","settings_candidates":"auto_candidate_limit","settings_positions":"max_open_ideas"}[kind]
            journal.set_config(key,num); _ui_cache_invalidate(); context.user_data.pop("input_state",None)
            await update.effective_message.reply_text("Настройка сохранена и будет действовать со следующей автоматической проверки.",reply_markup=settings_keyboard()); return
        draft=context.user_data.setdefault("replay_draft",{})
        if kind=="replay_start":
            date.fromisoformat(value); draft["start"]=value
            enter_step(draft,"custom_end"); _set_input(context,"replay_end")
            await update.effective_message.reply_text(
                "Введите дату окончания YYYY-MM-DD:",
                reply_markup=InlineKeyboardMarkup([[_btn("⬅️ Назад","rw:back")]]),
            ); return
        if kind=="replay_end":
            date.fromisoformat(value); draft["end"]=value
            if date.fromisoformat(draft["start"]) > date.fromisoformat(value):
                raise ValueError("Дата окончания раньше даты начала")
            context.user_data.pop("input_state",None); enter_step(draft,"frequency")
            await update.effective_message.reply_text(
                "Выберите период данных:", reply_markup=replay_frequency_keyboard(),
            ); return
        if kind=="replay_symbols":
            symbols=[normalize_symbol(x) for x in value.replace(";",",").split(",") if x.strip()]
            if not symbols: raise ValueError("Список пуст")
            draft["symbols"]=symbols; context.user_data.pop("input_state",None); _set_input(context,"replay_capital"); await update.effective_message.reply_text("Введите капитал USDT, например 1000:"); return
        if kind in {"replay_capital","replay_universe_size","replay_candidates","replay_positions"}:
            key={"replay_capital":"capital","replay_universe_size":"universe_size","replay_candidates":"candidate_limit","replay_positions":"max_open_positions"}[kind]
            draft[key]=float(value) if kind=="replay_capital" else int(value)
            nxt={"replay_capital":"replay_universe_size","replay_universe_size":"replay_candidates","replay_candidates":"replay_positions"}.get(kind)
            if nxt:
                step={"replay_universe_size":"universe_size","replay_candidates":"candidates","replay_positions":"positions"}[nxt]
                enter_step(draft,step); _set_input(context,nxt)
                prompt={"replay_universe_size":"Введите максимум монет (по умолчанию 30):","replay_candidates":"Введите лимит кандидатов (по умолчанию 5):","replay_positions":"Введите максимум позиций (по умолчанию 5):"}[nxt]
                await update.effective_message.reply_text(prompt,reply_markup=InlineKeyboardMarkup([[_btn("⬅️ Назад","rw:back")]])); return
            context.user_data.pop("input_state",None)
            enter_step(draft,"performance")
            await update.effective_message.reply_text("Выберите нагрузку:",reply_markup=InlineKeyboardMarkup([[_btn("🐢 Экономная","rp:eco"),_btn("⚖️ Сбалансированная","rp:balanced"),_btn("🚀 Быстрая","rp:fast")],[_btn("⬅️ Назад","rw:back")]])); return
    except Exception as exc:
        detail = str(exc) if str(exc) and not str(exc).isupper() else "Некорректное значение"
        await update.effective_message.reply_text(f"{detail}. Попробуйте ещё раз.")


def _draft_config(context: ContextTypes.DEFAULT_TYPE) -> tuple[HistoricalReplayConfig,list[str],bool]:
    d=ensure_draft(context.user_data)
    cfg=HistoricalReplayConfig(start=d["start"],end=d["end"],frequency=d.get("frequency","1d"),mode=d.get("mode","verified_news"),strategy_mode=d.get("strategy_mode","full"),universe_mode=d.get("universe_mode","dynamic"),capital=float(d.get("capital",1000)),universe_size=int(d.get("universe_size",30)),candidate_limit=int(d.get("candidate_limit",5)),max_open_positions=int(d.get("max_open_positions",5)),performance_mode=d.get("performance_mode","balanced")); cfg.validate()
    return cfg,list(d.get("selected_symbols") or d.get("symbols") or ()),bool(d.get("compare"))


async def _render_replay_step(
    update: Update, context: ContextTypes.DEFAULT_TYPE, step: str,
) -> None:
    draft = ensure_draft(context.user_data)
    context.user_data.pop("input_state", None)
    if step == "menu":
        await _edit_or_reply(update, "🧪 ИСТОРИЧЕСКИЕ ТЕСТЫ\nВыберите способ запуска.", replay_keyboard())
    elif step == "period":
        await _edit_or_reply(
            update,
            "Выберите период сравнения:" if draft.get("compare") else "Выберите период теста:",
            replay_period_keyboard(bool(draft.get("compare"))),
        )
    elif step == "year":
        await _edit_or_reply(update, "Выберите год. Стартовый капитал — 1000 USDT.", replay_year_keyboard())
    elif step == "custom_start":
        _set_input(context,"replay_start")
        await _edit_or_reply(update,"Введите дату начала YYYY-MM-DD:",InlineKeyboardMarkup([[_btn("⬅️ Назад","rw:back")]]))
    elif step == "custom_end":
        _set_input(context,"replay_end")
        await _edit_or_reply(update,"Введите дату окончания YYYY-MM-DD:",InlineKeyboardMarkup([[_btn("⬅️ Назад","rw:back")]]))
    elif step == "frequency":
        await _edit_or_reply(update,"Выберите период данных:",replay_frequency_keyboard())
    elif step == "mode":
        await _edit_or_reply(
            update,
            "Выберите информационный режим. Недоступный исторический контекст не будет подменён текущими данными.",
            replay_mode_keyboard(),
        )
    elif step == "symbols":
        await _show_replay_symbols(update,context)
    elif step == "manual_symbol":
        _set_input(context,"replay_manual_symbol")
        await _edit_or_reply(
            update,
            "Введите тикер, например PYTH, BMT или BTCUSDT. Поддержка пары и дата начала истории будут проверены.",
            InlineKeyboardMarkup([[_btn("⬅️ Назад","rw:back")]]),
        )
    elif step in {"capital","universe_size","candidates","positions"}:
        inputs = {
            "capital": ("replay_capital","Введите капитал USDT, например 1000:"),
            "universe_size": ("replay_universe_size","Введите максимум монет:"),
            "candidates": ("replay_candidates","Введите лимит кандидатов:"),
            "positions": ("replay_positions","Введите максимум позиций:"),
        }
        kind,prompt=inputs[step]; _set_input(context,kind)
        await _edit_or_reply(update,prompt,InlineKeyboardMarkup([[_btn("⬅️ Назад","rw:back")]]))
    elif step == "performance":
        await _edit_or_reply(update,"Выберите нагрузку:",InlineKeyboardMarkup([
            [_btn("🐢 Экономная","rp:eco"),_btn("⚖️ Сбалансированная","rp:balanced"),_btn("🚀 Быстрая","rp:fast")],
            [_btn("⬅️ Назад","rw:back")],
        ]))
    elif step == "confirm":
        cfg,symbols,compare=_draft_config(context)
        await _edit_or_reply(
            update,
            _replay_config_text(cfg,symbols,compare)+"\n\nСледующий экран проверит доступность данных и контекста.",
            InlineKeyboardMarkup([[_btn("🔎 Проверить данные","replay_draft_confirm")],[_btn("⬅️ Назад","rw:back")]]),
        )


async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query=update.callback_query
    # Telegram invalidates callback IDs quickly.  Navigation can still be
    # rendered from the attached message, so an expired acknowledgement is not
    # a fatal UI error and must not emit an unhandled traceback.
    with suppress(BadRequest, TelegramError):
        await query.answer()
    data=query.data or ""
    if data=="main_menu": await start(update,context)
    elif data=="service_menu": await _edit_or_reply(update, "🧰 СЕРВИС\nТехнические и редкие инструменты. Они не меняют стратегию автоматически.", service_keyboard())
    elif data=="portfolio": await show_portfolio(update)
    elif data=="status": await status(update,context)
    elif data=="status_detail": await _render_ui_async(update, build_status_detail_text, lambda: InlineKeyboardMarkup([[_btn("⬅️ Состояние", "status")], [_btn("⬅️ Сервис", "service_menu")]]))
    elif data=="help_menu": await help_command(update, context)
    elif data=="emergency_menu":
        enabled = bool(journal.get_config("automation_enabled", False))
        await _edit_or_reply(update, "🚨 АВАРИЙНОЕ УПРАВЛЕНИЕ\nИспользуйте только при необходимости. Остановка автоматической проверки не закрывает позиции и не меняет стратегию.", InlineKeyboardMarkup([
            [_btn("⏹ Выключить автоматику" if enabled else "▶️ Включить автоматику", "auto_off_request" if enabled else "auto_on_request")],
            [_btn("⬅️ Сервис", "service_menu")],
        ]))
    elif data.startswith("diag_detail:"):
        hours=int(data.split(":",1)[1])
        text = await asyncio.to_thread(build_diagnostics_detail_text, hours)
        await _edit_or_reply(update, text, diagnostics_keyboard(hours))
    elif data.startswith("diag:"):
        hours=int(data.split(":",1)[1])
        await diagnostics(update,context,hours)
    elif data=="history": await history(update,context,0)
    elif data.startswith("history_page:"):
        await history(update, context, int(data.split(":", 1)[1]))
    elif data=="history_noop":
        return
    elif data=="chart_menu": await _edit_or_reply(update, "📈 Выберите монету для графика операций.", await asyncio.to_thread(chart_symbol_keyboard))
    elif data=="chart_custom":
        _set_input(context,"chart_symbol"); await query.edit_message_text("Введите тикер, например ETH или ETHUSDT:")
    elif data.startswith("chart_symbol:"):
        symbol=data.split(":",1)[1]; await query.edit_message_text(f"Период для {symbol}:", reply_markup=chart_period_keyboard(symbol))
    elif data.startswith("chart_period:"):
        _,symbol,period=data.split(":",2); await send_trade_chart(update,context,symbol,period)
    elif data=="recycling": await _render_ui_async(update, build_recycling_text, service_keyboard)
    elif data=="opportunities": await _render_ui_async(update, build_opportunities_text, main_keyboard)
    elif data=="event_momentum": await _render_ui_async(update, build_event_momentum_text, service_keyboard)
    elif data in {"auto_on", "auto_on_request"}:
        await _edit_or_reply(update, "Включить автоматическую проверку рынка?", InlineKeyboardMarkup([[_btn("✅ Включить", "auto_on_confirm"), _btn("❌ Отмена", "emergency_menu")]]))
    elif data in {"auto_off", "auto_off_request"}:
        await _edit_or_reply(update, "Выключить автоматическую проверку рынка? Это не закрывает позиции.", InlineKeyboardMarkup([[_btn("✅ Выключить", "auto_off_confirm"), _btn("❌ Отмена", "emergency_menu")]]))
    elif data=="auto_on_confirm":
        journal.set_config("automation_enabled", True)
        _ui_cache_invalidate()
        await _edit_or_reply(update, "Автоматическая проверка включена.", service_keyboard())
    elif data=="auto_off_confirm":
        journal.set_config("automation_enabled", False)
        _ui_cache_invalidate()
        await _edit_or_reply(update, "Автоматическая проверка выключена.", service_keyboard())
    elif data=="pause_buys": journal.set_config("purchases_paused",True); _ui_cache_invalidate("purchases_paused"); await _edit_or_reply(update,"Новые покупки приостановлены. Продажи риска остаются активны.",main_keyboard())
    elif data=="resume_buys": journal.set_config("purchases_paused",False); _ui_cache_invalidate("purchases_paused"); await _edit_or_reply(update,"Новые виртуальные покупки снова разрешены.",main_keyboard())
    elif data=="run_cycle": await run_cycle(update,context)
    elif data=="sources": await sources(update,context)
    elif data=="settings_menu": await settings_command(update,context)
    elif data=="settings_profile":
        await _edit_or_reply(update, _profile_status_text(), strategy_profile_keyboard())
    elif data=="settings_profile_full":
        journal.set_config("strategy_profile", FULL_PROFILE)
        _ui_cache_invalidate()
        await _edit_or_reply(update, _profile_status_text(), strategy_profile_keyboard())
    elif data=="settings_profile_core_lab":
        journal.set_config("strategy_profile", CORE_LAB_PROFILE)
        # Old non-Core pending buys must not survive activation of the control profile.
        for order in journal.pending_orders():
            if str(order.get("side") or "").upper() == "BUY" and str(order.get("symbol") or "").upper() not in set(CORE_LAB_SYMBOLS):
                journal.cancel_order(int(order["id"]), "STRATEGY_PROFILE_CORE_LAB")
        _ui_cache_invalidate()
        await _edit_or_reply(update, _profile_status_text(), strategy_profile_keyboard())
    elif data=="settings_daily_on":
        journal.set_config("daily_report_enabled", True)
        _ui_cache_invalidate("daily_report_enabled")
        await _edit_or_reply(update, "Суточная сводка включена. Она будет отправляться не чаще одного раза в 24 часа после завершённого цикла.", settings_keyboard())
    elif data=="settings_daily_off":
        journal.set_config("daily_report_enabled", False)
        _ui_cache_invalidate("daily_report_enabled")
        await _edit_or_reply(update, "Суточная сводка выключена.", settings_keyboard())
    elif data.startswith("setting_value:"):
        _,kind,raw=data.split(":",2)
        if kind=="settings_capital":
            amount=float(raw); context.user_data["pending_capital"]=amount
            await query.edit_message_text(
                f"Начать новый виртуальный портфель с {amount:,.2f} USDT? Текущие позиции и журнал могут быть сброшены.",
                reply_markup=InlineKeyboardMarkup([[_btn("✅ Подтвердить","capital_confirm"),_btn("❌ Отмена","settings_menu")]]),
            )
        else:
            value=int(raw)
            key={"settings_interval":"auto_scan_interval_seconds","settings_universe":"auto_universe_size","settings_candidates":"auto_candidate_limit","settings_positions":"max_open_ideas"}[kind]
            journal.set_config(key,value); _ui_cache_invalidate()
            await query.edit_message_text("Настройка сохранена и будет действовать со следующей автоматической проверки.",reply_markup=settings_keyboard())
    elif data.startswith("setting_manual:"):
        kind=data.split(":",1)[1]
        prompts={"settings_capital":"Введите новый капитал в USDT:","settings_interval":"Введите интервал в секундах:","settings_universe":"Введите размер списка монет:","settings_candidates":"Введите лимит кандидатов:","settings_positions":"Введите максимум позиций:"}
        _set_input(context,kind); await query.edit_message_text(prompts[kind])
    elif data.startswith("settings_"):
        prompts={"settings_capital":"Введите новый капитал в USDT:","settings_interval":"Введите интервал в секундах:","settings_universe":"Введите размер списка монет:","settings_candidates":"Введите лимит кандидатов:","settings_positions":"Введите максимум позиций:"}
        await query.edit_message_text(prompts[data]+"\nИли выберите готовое значение:",reply_markup=settings_preset_keyboard(data))
    elif data=="capital_confirm":
        amount=float(context.user_data.pop("pending_capital")); journal.set_initial_capital(amount); _ui_cache_invalidate(); await query.edit_message_text(f"Новый виртуальный портфель: {amount:,.2f} USDT",reply_markup=main_keyboard())
    elif data=="replay_menu": await query.edit_message_text("🧪 ИСТОРИЧЕСКИЕ ТЕСТЫ\nВыберите способ запуска.",reply_markup=replay_keyboard())
    elif data=="replay_quick": await replay_default(update,context)
    elif data=="replay_quick_confirm": await _start_single_replay(update,context,_quick_config(),["ETHUSDT"])
    elif data=="replay_new_start":
        draft=ensure_draft(context.user_data,compare=False,reset=True); enter_step(draft,"period")
        await _render_replay_step(update,context,"period")
    elif data=="replay_year_menu":
        draft=ensure_draft(context.user_data,compare=False,reset=True); enter_step(draft,"year")
        await _render_replay_step(update,context,"year")
    elif data.startswith("replay_year:"):
        year=int(data.split(":",1)[1]); today=date.today()
        end=(today-timedelta(days=1)).isoformat() if year==today.year else f"{year}-12-31"
        draft=ensure_draft(context.user_data,compare=False)
        draft.update({"start":f"{year}-01-01","end":end,"frequency":"1d","capital":1000})
        enter_step(draft,"mode"); await _render_replay_step(update,context,"mode")
    elif data in {"replay_custom_dates"}:
        draft=ensure_draft(context.user_data,compare=False,reset=True); enter_step(draft,"custom_start")
        await _render_replay_step(update,context,"custom_start")
    elif data=="replay_custom_start":
        draft=ensure_draft(context.user_data,compare=False,reset=True); enter_step(draft,"period")
        await _render_replay_step(update,context,"period")
    elif data=="replay_compare_start":
        draft=ensure_draft(context.user_data,compare=True,reset=True); enter_step(draft,"period")
        await _render_replay_step(update,context,"period")
    elif data.startswith("replay_period:") or data.startswith("replay_compare_period:"):
        compare=data.startswith("replay_compare_period:")
        code=data.split(":",1)[1]
        draft=ensure_draft(context.user_data,compare=compare)
        if code=="custom":
            enter_step(draft,"custom_start")
            await _render_replay_step(update,context,"custom_start")
        else:
            start_date,end_date=_period_dates(code)
            draft.update({"start":start_date,"end":end_date}); enter_step(draft,"frequency")
            await _render_replay_step(update,context,"frequency")
    elif data.startswith("rf:"):
        draft=ensure_draft(context.user_data); draft["frequency"]=data.split(":",1)[1]
        enter_step(draft,"mode"); await _render_replay_step(update,context,"mode")
    elif data.startswith("rm:"):
        draft=ensure_draft(context.user_data); draft["mode"]=data.split(":",1)[1]
        draft["universe_mode"]="fixed"; enter_step(draft,"symbols")
        await _render_replay_step(update,context,"symbols")
    elif data.startswith("ru:"):
        draft=ensure_draft(context.user_data); draft["universe_mode"]="fixed"
        enter_step(draft,"symbols"); await _render_replay_step(update,context,"symbols")
    elif data.startswith("rs:t:"):
        draft=ensure_draft(context.user_data)
        try: toggle_symbol(draft,data.split(":",2)[2])
        except ValueError: pass
        await query.edit_message_text(_symbol_selection_text(draft),reply_markup=replay_symbol_keyboard(draft))
    elif data.startswith("rs:p:"):
        draft=ensure_draft(context.user_data); symbol_page(draft,int(data.split(":",2)[2]))
        await query.edit_message_text(_symbol_selection_text(draft),reply_markup=replay_symbol_keyboard(draft))
    elif data in {"rs:all","rs:none","rs:core","rs:runtime"}:
        draft=ensure_draft(context.user_data)
        if data=="rs:none": draft["selected_symbols"]=[]
        else: apply_preset(draft,{"rs:all":PRESET_ALL,"rs:core":PRESET_CORE,"rs:runtime":PRESET_RUNTIME}[data])
        await query.edit_message_text(_symbol_selection_text(draft),reply_markup=replay_symbol_keyboard(draft))
    elif data=="rs:manual":
        draft=ensure_draft(context.user_data); enter_step(draft,"manual_symbol")
        await _render_replay_step(update,context,"manual_symbol")
    elif data=="rs:continue":
        draft=ensure_draft(context.user_data)
        selected=list(draft.get("selected_symbols") or ())
        if not selected:
            await query.edit_message_text("Выберите хотя бы одну монету.",reply_markup=replay_symbol_keyboard(draft))
        else:
            draft["symbols"]=selected; draft["universe_mode"]="fixed"
            enter_step(draft,"capital"); await _render_replay_step(update,context,"capital")
    elif data.startswith("rp:"):
        draft=ensure_draft(context.user_data); draft["performance_mode"]=data.split(":",1)[1]
        enter_step(draft,"confirm"); await _render_replay_step(update,context,"confirm")
    elif data=="replay_draft_confirm":
        cfg,symbols,compare=_draft_config(context)
        await _request_replay_preflight(update,context,cfg,symbols,compare)
    elif data=="replay_preflight_confirm":
        pending=context.user_data.pop("replay_pending_run",None)
        if not pending:
            await query.edit_message_text("Параметры запуска устарели. Настройте тест заново.",reply_markup=replay_keyboard())
        else:
            raw=dict(pending["config"])
            raw["allow_context_fallback"]=bool(pending.get("requires_fallback"))
            cfg=HistoricalReplayConfig(**raw); symbols=list(pending.get("symbols") or ())
            if pending.get("compare"): await _start_compare(update,context,cfg,symbols)
            else: await _start_single_replay(update,context,cfg,symbols)
    elif data=="rw:back":
        draft=ensure_draft(context.user_data); step=back_step(draft)
        await _render_replay_step(update,context,step)
    elif data=="replay_status": await replay_status_command(update,context)
    elif data=="replay_pause":
        if replay_runner:
            replay_runner.progress["stage"]="PAUSE_REQUESTED"
            replay_runner.pause_event.set()
            await query.edit_message_text("⏸ Пауза запрошена. Бот остановится после текущего сетевого запроса или анализа одной монеты, обычно в течение нескольких секунд.",reply_markup=replay_keyboard())
        else: await query.edit_message_text("Пауза недоступна для пакетного сравнения.",reply_markup=replay_keyboard())
    elif data=="replay_resume":
        if replay_runner:
            replay_runner.pause_event.clear()
            replay_runner.progress["stage"]="RUNNING"
            await query.edit_message_text("▶️ Исторический тест продолжен.",reply_markup=replay_keyboard())
    elif data=="replay_stop":
        if replay_runner:
            replay_runner.progress["stage"]="STOPPING"
            replay_runner.cancel_event.set()
            replay_runner.pause_event.clear()
            await query.edit_message_text("⛔ Остановка запрошена. Текущий сетевой запрос завершится, затем тест сохранит частичный журнал и освободит запуск нового теста.",reply_markup=replay_keyboard())
        else: await query.edit_message_text("Пакетное сравнение пока нельзя остановить из Telegram.",reply_markup=replay_keyboard())
    elif data=="replay_history": await replay_history_command(update,context)
    elif data.startswith("replay_run:"):
        i=int(data.split(":",1)[1]); runs=_replay_runs(10)
        if i>=len(runs): await query.edit_message_text("Тест больше не найден.",reply_markup=replay_keyboard()); return
        run=runs[i]; s=_read_summary(run); context.user_data["selected_run"]=str(run)
        text=_format_replay_result(s, run)
        await query.edit_message_text(text,reply_markup=InlineKeyboardMarkup([
            [_btn("🪙 По монетам","replay_symbol_results")],
            [_btn("📈 График портфеля","replay_equity_chart"),_btn("🕯 Графики монет","replay_coin_chart_menu")],
            [_btn("📦 Скачать архив","replay_zip"),_btn("▶️ Повторить","replay_repeat")],
            [_btn("🗑 В корзину","replay_trash")],[_btn("⬅️ История","replay_history")]
        ]))
    elif data == "replay_symbol_results":
        run=Path(context.user_data.get("selected_run","")); summary=_read_summary(run)
        await query.edit_message_text(
            _format_replay_assets(summary),
            reply_markup=InlineKeyboardMarkup([[_btn("⬅️ К результату","replay_selected_run")]]),
        )
    elif data == "replay_selected_run":
        run=Path(context.user_data.get("selected_run","")); summary=_read_summary(run)
        await query.edit_message_text(_format_replay_result(summary,run),reply_markup=InlineKeyboardMarkup([
            [_btn("🪙 По монетам","replay_symbol_results")],
            [_btn("📈 График портфеля","replay_equity_chart"),_btn("🕯 Графики монет","replay_coin_chart_menu")],
            [_btn("📦 Скачать архив","replay_zip"),_btn("▶️ Повторить","replay_repeat")],
            [_btn("🗑 В корзину","replay_trash")],[_btn("⬅️ История","replay_history")],
        ]))
    elif data == "replay_equity_chart":
        run=Path(context.user_data.get("selected_run","")); chart=run/"equity_curve.png"
        if not chart.is_file():
            await query.edit_message_text("График портфеля для этого теста не найден.",reply_markup=replay_keyboard()); return
        with chart.open("rb") as handle:
            await context.application.bot.send_photo(
                update.effective_chat.id, photo=handle,
                caption="📈 Стоимость исторического портфеля и свободные USDT.",
            )
    elif data == "replay_coin_chart_menu":
        run=Path(context.user_data.get("selected_run",""))
        charts=sorted(run.glob("*USDT_candles.png")) if run.is_dir() else []
        if not charts:
            await query.edit_message_text("Свечные графики для этого теста не найдены.",reply_markup=replay_keyboard()); return
        context.user_data["selected_replay_charts"]=[str(path) for path in charts[:20]]
        rows=[]
        for i,path in enumerate(charts[:20]):
            rows.append([_btn(path.name.replace("_candles.png", ""),f"replay_coin_chart:{i}")])
        rows.append([_btn("⬅️ К результату","replay_history")])
        await query.edit_message_text("🕯 Выберите монету:",reply_markup=InlineKeyboardMarkup(rows))
    elif data.startswith("replay_coin_chart:"):
        i=int(data.split(":",1)[1]); charts=context.user_data.get("selected_replay_charts") or []
        if i >= len(charts) or not Path(charts[i]).is_file():
            await query.edit_message_text("Свечной график больше не найден.",reply_markup=replay_keyboard()); return
        chart=Path(charts[i]); symbol=chart.name.replace("_candles.png", "")
        with chart.open("rb") as handle:
            await context.application.bot.send_photo(
                update.effective_chat.id, photo=handle,
                caption=f"🕯 {symbol}: свечи, покупки, продажи и новостные операции исторического теста.",
            )
    elif data=="replay_zip":
        run=Path(context.user_data.get("selected_run",""))
        if not run.is_dir(): await query.edit_message_text("Папка теста не найдена.",reply_markup=replay_keyboard()); return
        archive=Path(shutil.make_archive(str(run),"zip",root_dir=run))
        await context.application.bot.send_document(update.effective_chat.id,document=archive.open("rb"),filename=archive.name,caption="Полный журнал исторического теста")
        await query.edit_message_text("Архив отправлен.",reply_markup=replay_keyboard())
    elif data=="replay_trash":
        await query.edit_message_text("Переместить выбранный тест в корзину?",reply_markup=InlineKeyboardMarkup([[_btn("✅ Да","replay_trash_confirm"),_btn("❌ Нет","replay_history")]]))
    elif data=="replay_trash_confirm":
        run=Path(context.user_data.get("selected_run",""))
        try: target=move_run_to_trash(run,"output"); await query.edit_message_text(f"Тест перемещён в корзину: {target}",reply_markup=replay_keyboard())
        except Exception:
            logger.exception("replay_move_to_trash_failed")
            await query.edit_message_text("Не удалось переместить тест в корзину. Подробности сохранены в журнале приложения.",reply_markup=replay_keyboard())
    elif data=="replay_repeat":
        run=Path(context.user_data.get("selected_run","")); cfg_path=run/"config.json"
        try:
            d=json.loads(cfg_path.read_text(encoding="utf-8")); allowed={f.name for f in HistoricalReplayConfig.__dataclass_fields__.values()}; cfg=HistoricalReplayConfig(**{k:v for k,v in d.items() if k in allowed}); await _start_single_replay(update,context,cfg,[])
        except Exception:
            logger.exception("replay_repeat_failed")
            await query.edit_message_text("Не удалось повторить тест. Подробности сохранены в журнале приложения.",reply_markup=replay_keyboard())


def _notification_due(last_value, interval_hours: int, *, now: datetime | None = None) -> bool:
    now = now or datetime.now(timezone.utc)
    if not last_value:
        return True
    try:
        parsed = datetime.fromisoformat(str(last_value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return now - parsed >= timedelta(hours=max(1, int(interval_hours)))
    except (TypeError, ValueError):
        return True


async def broadcast_cycle(application: Application, summary: dict):
    now = datetime.now(timezone.utc)
    send_cycle_summary = _notification_due(
        journal.get_config("last_cycle_summary_at"),
        AUTO_CYCLE_SUMMARY_INTERVAL_HOURS,
        now=now,
    )
    send_daily = bool(journal.get_config("daily_report_enabled", False)) and _notification_due(
        journal.get_config("last_daily_report_at"), 24, now=now
    )
    for chat_id in ALLOWED_CHAT_IDS:
        for action in summary.get("actions") or []:
            text=format_action(action)
            if text: await application.bot.send_message(chat_id,text)
        if send_cycle_summary:
            await application.bot.send_message(chat_id,format_cycle(summary),reply_markup=main_keyboard())
        if send_daily:
            await application.bot.send_message(chat_id, build_daily_report_text(), reply_markup=main_keyboard())
    if ALLOWED_CHAT_IDS and send_cycle_summary:
        journal.set_config("last_cycle_summary_at", now.isoformat())
    if ALLOWED_CHAT_IDS and send_daily:
        journal.set_config("last_daily_report_at", now.isoformat())
    for notification in journal.pending_notifications(100): journal.mark_notification_sent(notification["id"])


async def broadcast_event_watch(application: Application, summary: dict):
    """Send only state-changing paper actions; minute observations stay quiet."""
    for chat_id in ALLOWED_CHAT_IDS:
        for action in summary.get("actions") or []:
            text = format_action(action)
            if text:
                await application.bot.send_message(chat_id, text)


async def post_init(application: Application):
    commands=[
        BotCommand("start","Главное меню"), BotCommand("status","Статус автоматики"),
        BotCommand("portfolio","Текущий портфель"), BotCommand("cycle","Проверить рынок"),
        BotCommand("history","История операций"), BotCommand("chart","График покупок/продаж"),
        BotCommand("opportunities","Обзор рынка"), BotCommand("settings","Настройки"),
        BotCommand("help","Справка"),
    ]
    with suppress(TelegramError): await application.bot.set_my_commands(commands)
    recovered_cycles = journal.reconcile_running_decision_cycles("BOT_STARTUP_SINGLE_INSTANCE_HELD")
    if recovered_cycles:
        logger.warning("reconciled_stale_decision_cycles count=%s", recovered_cycles)
    identity = await application.bot.get_me()
    with suppress(TelegramError):
        await application.bot.set_my_name(f"Spot Investment AI v{VERSION}")
    if runtime_lock:
        runtime_lock.update(
            status="INITIALIZED",
            bot_id=identity.id,
            bot_username=identity.username,
            polling="READY",
        )
    async def on_cycle(summary: dict): await broadcast_cycle(application,summary)
    application.bot_data["automation_task"]=asyncio.create_task(
        autonomous.run_forever(None,on_cycle=on_cycle),
        name="automatic-paper-cycle-loop",
    )
    async def on_event_watch(summary: dict): await broadcast_event_watch(application, summary)
    application.bot_data["event_watch_task"] = asyncio.create_task(
        autonomous.run_event_watches_forever(on_cycle=on_event_watch),
        name="event-minute-watch-loop",
    )
    if runtime_lock:
        runtime_lock.update(autonomous_worker="ON")


async def post_shutdown(application: Application):
    for key in ("automation_task","event_watch_task","manual_cycle_task"):
        task=application.bot_data.get(key)
        if task: task.cancel();
        if task:
            with suppress(asyncio.CancelledError): await task
    if runtime_lock:
        runtime_lock.update(polling="OFF",autonomous_worker="OFF",status="SHUTTING_DOWN")


async def telegram_error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    error = context.error
    if isinstance(error, TelegramError):
        logger.warning("telegram_update_error type=%s detail=%s", type(error).__name__, error)
        return
    logger.exception("telegram_update_error", exc_info=error)


async def help_command(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    await _edit_or_reply(
        update,
        f"❓ СПРАВКА\n\n"
        "• Портфель — средства, позиции и результат.\n"
        "• Рынок — последние решения по монетам.\n"
        "• График — виртуальные покупки и продажи.\n"
        "• История — денежная история операций, включая результат продаж.\n"
        "• Проверить рынок — внеочередной цикл; обычный цикл продолжает работать по расписанию.\n"
        "• Пауза новых покупок не отключает защитные продажи.\n\n"
        "Исторический тест доступен прямо в главном меню. Диагностика, источники данных, новостной контур, оборот капитала и аварийное управление находятся в «Сервисе».\n\n"
        "Пример графика: /chart ETHUSDT 90d",
        service_keyboard(),
    )


async def main():
    global runtime_lock
    if not TELEGRAM_TOKEN: raise RuntimeError("SPOT_AI_TELEGRAM_TOKEN is not configured")
    canonical = Path(__file__).resolve().parents[1]
    runtime_lock = SingleInstance(
        canonical / "data" / "spot_ai_runtime.lock", canonical_path=canonical
    )
    try:
        runtime_lock.acquire()
    except AlreadyRunningError as error:
        print(str(error))
        return
    app=(Application.builder().token(TELEGRAM_TOKEN).post_init(post_init).post_shutdown(post_shutdown).build())
    app.add_handler(TypeHandler(Update,access_guard),group=-1)
    app.add_handler(CommandHandler("start",start)); app.add_handler(CommandHandler("help",help_command))
    app.add_handler(CommandHandler("analyze",analyze)); app.add_handler(CommandHandler("portfolio",portfolio)); app.add_handler(CommandHandler("history",history)); app.add_handler(CommandHandler("chart",chart_command)); app.add_handler(CommandHandler("capital",capital)); app.add_handler(CommandHandler("status",status)); app.add_handler(CommandHandler("diagnostics",diagnostics)); app.add_handler(CommandHandler("opportunities",lambda u,c:_edit_or_reply(u,build_opportunities_text(),main_keyboard()))); app.add_handler(CommandHandler("event_momentum",lambda u,c:_edit_or_reply(u,build_event_momentum_text(),service_keyboard()))); app.add_handler(CommandHandler("cycle",run_cycle)); app.add_handler(CommandHandler("sources",sources)); app.add_handler(CommandHandler("settings",settings_command)); app.add_handler(CommandHandler("replay",lambda u,c:_edit_or_reply(u,"🧪 ИСТОРИЧЕСКИЕ ТЕСТЫ\nВыберите способ запуска.",replay_keyboard()))); app.add_handler(CommandHandler("replay_status",replay_status_command)); app.add_handler(CommandHandler("replay_history",replay_history_command))
    app.add_handler(CallbackQueryHandler(callback)); app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_input))
    app.add_error_handler(telegram_error_handler)
    try:
        # Application.initialize()/shutdown() deliberately do not invoke the
        # optional post_init/post_shutdown callbacks.  This entrypoint manages
        # the lifecycle manually, so invoke the hooks explicitly; otherwise the
        # autonomous worker is never created even though Telegram polling runs.
        await app.initialize()
        await post_init(app)
        await app.start(); await app.updater.start_polling()
        runtime_lock.update(status="RUNNING",polling="ON",autonomous_worker="ON")
        while True: await asyncio.sleep(3600)
    finally:
        try:
            if app.updater.running: await app.updater.stop()
            await post_shutdown(app)
            if app.running: await app.stop()
            await app.shutdown()
        finally:
            runtime_lock.release()
            runtime_lock = None


if __name__ == "__main__": asyncio.run(main())
