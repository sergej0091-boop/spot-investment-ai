from __future__ import annotations

import csv
from collections import Counter
import hashlib
import html
import json
import os
import platform
import shutil
import sys
import threading
import time as time_module
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Iterable

from config.version import APP_VERSION
from data_engine.ohlcv_quality import audit_candles
from data_engine.symbol_provider import SymbolProvider
from data_engine.replay_cache import ReplayMarketDataCache
from investment.decision_trace import build_decision_trace
from investment.capital_recycling import CapitalRecyclingEngine, reserve_policy_for_macro
from investment.models import PositionState
from investment.event_watch import EventWatchConfig, EventWatchEngine
from investment.deterioration_guard import (
    DeteriorationGuard,
    MemoryGuardStateStore,
    REDUCE_NEW_DETERIORATION_STAGE,
    LOSS_REDUCE_THESIS_RECOVERED,
)
from testing.daily_replay import ReplayPortfolio, BUY_DECISIONS, SELL_DECISIONS
from testing.replay import LookAheadError, PointInTimeStore
from testing.historical_context import (
    build_context_preflight,
    require_context_preflight,
)
from config.settings import (
    EVENT_CAPITAL_POOL_PERCENT,
    EVENT_MAX_SINGLE_TRADE_PERCENT,
    EVENT_CONFIRMATIONS_REQUIRED,
    EVENT_MAX_ADDITIONAL_TRANCHES,
    EVENT_MAX_CHASE_ATR_MULTIPLE,
    EVENT_MAX_CHASE_PERCENT,
    EVENT_RETEST_TOLERANCE_ATR_MULTIPLE,
    EVENT_SHARP_REJECTION_PERCENT,
    EVENT_TRANCHE_COOLDOWN_MINUTES,
    EVENT_WATCH_DURATION_MINUTES,
    EVENT_DYNAMIC_BASE_ENABLED,
    EVENT_MICRO_PULLBACK_ENABLED,
    EVENT_DYNAMIC_BASE_REQUIRE_RETEST,
    EVENT_MIN_CONSOLIDATION_MINUTES,
    EVENT_MIN_BASE_QUALITY,
    EVENT_MAX_ANCHOR_RESETS,
    EVENT_ANCHOR_RESET_COOLDOWN_MINUTES,
    EVENT_MAX_WATCH_DURATION_MINUTES,
    EVENT_WATCH_EXTENSION_MINUTES,
    EVENT_MAX_BASE_RANGE_ATR,
    EVENT_RANGE_COMPRESSION_MAX_RATIO,
    EVENT_BASE_VOLUME_CONTRACTION_MAX_RATIO,
    EVENT_BASE_VOLUME_FLOOR_RATIO,
    EVENT_BASE_BREAKOUT_BUFFER_ATR,
    EVENT_MAX_TOTAL_EXTENSION_ATR,
    EVENT_MAX_TOTAL_EXTENSION_PERCENT,
    EVENT_MICRO_PULLBACK_MIN_ATR,
    EVENT_MICRO_PULLBACK_MAX_ATR,
    HARD_CASH_RESERVE_PERCENT,
    AUTO_BUY_COOLDOWN_HOURS,
    PENDING_BUY_TTL_HOURS,
    PAPER_MIN_EXECUTION_NOTIONAL_USDT,
    RECYCLE_OPPORTUNITY_SHARE_PERCENT,
    RECYCLE_REBUY_SHARE_PERCENT,
    RECYCLE_RETAINED_SHARE_PERCENT,
)

VALID_FREQUENCIES = {"4h", "1d", "1w"}
VALID_MODES = {"market_only", "macro_only", "verified_news"}
VALID_UNIVERSE_MODES = {"dynamic", "fixed"}
VALID_STRATEGY_MODES = {"baseline", "baseline_recycling", "baseline_news_event", "full"}
VALID_EVENT_CONTINUATION_MODES = {
    "production", "current", "dynamic_base", "dynamic_micro", "dynamic_retest",
}

FINGERPRINT_SCHEMA = "spot_historical_replay_observability_v2_reduce_reentry"
_RUNTIME_ONLY_CONFIG_FIELDS = {"performance_mode"}
_VOLATILE_SUMMARY_FIELDS = {
    "duration_seconds",
    "cache",
    "input_fingerprint",
    "input_provenance",
    "analytical_output_hash",
    "fingerprint_schema",
}


def _canonical_json(value) -> str:
    """Serialize replay evidence in a stable, platform-independent form."""
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _sha256_json(value) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _execution_observability(
    trades: list[dict], equity: list[dict], initial_capital: float
) -> dict:
    """Derive metrics from fills without changing replay execution.

    A closed cycle starts when a symbol moves from zero to a positive quantity
    and ends when subsequent recorded sells return it to zero.  Because replay
    always starts with an empty portfolio, aggregate cash spent and net sell
    proceeds are sufficient for a defensible closed-cycle PnL.
    """
    buy_rows = [row for row in trades if str(row.get("side")) == "BUY"]
    sell_rows = [row for row in trades if str(row.get("side")) == "SELL"]
    accumulate_buys = sum(
        str(row.get("decision")) == "ACCUMULATE" for row in buy_rows
    )
    partial_buys = sum(
        str(row.get("decision")) == "BUY_PARTIALLY" for row in buy_rows
    )
    full_exits = sum(
        str(row.get("decision")) == "EXIT_ON_RISK" for row in sell_rows
    )

    traded_notional = 0.0
    states: dict[str, dict] = {}
    closed_cycles: list[dict] = []
    unmatched_sells = 0
    tolerance = 1e-10
    for row in trades:
        symbol = str(row.get("symbol") or "").upper()
        side = str(row.get("side") or "").upper()
        quantity = max(0.0, float(row.get("quantity") or 0.0))
        execution_price = max(0.0, float(row.get("execution_price") or 0.0))
        state = states.setdefault(
            symbol,
            {
                "quantity": 0.0,
                "cash_spent": 0.0,
                "net_proceeds": 0.0,
                "opened_at": None,
                "buy_actions": 0,
                "sell_actions": 0,
            },
        )
        if side == "BUY":
            notional = max(
                0.0,
                float(row.get("notional") or quantity * execution_price),
            )
            traded_notional += notional
            if state["quantity"] <= tolerance:
                state.update(
                    {
                        "quantity": 0.0,
                        "cash_spent": 0.0,
                        "net_proceeds": 0.0,
                        "opened_at": row.get("execution_time"),
                        "buy_actions": 0,
                        "sell_actions": 0,
                    }
                )
            state["quantity"] += quantity
            state["cash_spent"] += notional
            state["buy_actions"] += 1
        elif side == "SELL":
            gross = quantity * execution_price
            traded_notional += gross
            if state["quantity"] <= tolerance:
                unmatched_sells += 1
                continue
            net_proceeds = float(
                row.get("proceeds")
                if row.get("proceeds") is not None
                else gross - float(row.get("fee") or 0.0)
            )
            state["quantity"] = max(0.0, state["quantity"] - quantity)
            state["net_proceeds"] += net_proceeds
            state["sell_actions"] += 1
            if state["quantity"] <= tolerance:
                pnl = state["net_proceeds"] - state["cash_spent"]
                closed_cycles.append(
                    {
                        "symbol": symbol,
                        "opened_at": state["opened_at"],
                        "closed_at": row.get("execution_time"),
                        "cash_spent_usdt": state["cash_spent"],
                        "net_proceeds_usdt": state["net_proceeds"],
                        "pnl_usdt": pnl,
                        "buy_actions": state["buy_actions"],
                        "sell_actions": state["sell_actions"],
                    }
                )
                state.update(
                    {
                        "quantity": 0.0,
                        "cash_spent": 0.0,
                        "net_proceeds": 0.0,
                        "opened_at": None,
                        "buy_actions": 0,
                        "sell_actions": 0,
                    }
                )

    open_cycles = sum(state["quantity"] > tolerance for state in states.values())
    invested_values = [
        max(0.0, float(row.get("equity") or 0.0) - float(row.get("cash") or 0.0))
        for row in equity
    ]
    equity_values = [float(row.get("equity") or 0.0) for row in equity]
    average_invested = (
        sum(invested_values) / len(invested_values) if invested_values else 0.0
    )
    average_equity = (
        sum(equity_values) / len(equity_values)
        if equity_values
        else float(initial_capital)
    )
    cash_utilization = (
        sum(invested_values) / sum(equity_values) * 100
        if equity_values and sum(equity_values) > 0
        else 0.0
    )
    turnover_ratio = traded_notional / average_equity if average_equity > 0 else None

    cycle_pnls = [float(row["pnl_usdt"]) for row in closed_cycles]
    winners = sum(value > 0 for value in cycle_pnls)
    gross_profit = sum(value for value in cycle_pnls if value > 0)
    gross_loss = -sum(value for value in cycle_pnls if value < 0)
    if not cycle_pnls:
        cycle_metrics = {
            "status": "UNAVAILABLE",
            "reason": "no_closed_position_cycles",
            "closed_cycles": 0,
            "winning_cycles": 0,
            "losing_cycles": 0,
            "win_rate_percent": None,
            "profit_factor": None,
            "profit_factor_status": "UNAVAILABLE_NO_CLOSED_CYCLES",
            "expectancy_usdt": None,
            "realized_cycle_pnl_usdt": 0.0,
        }
    else:
        if gross_loss > 0:
            profit_factor = gross_profit / gross_loss
            profit_factor_status = "AVAILABLE"
        elif gross_profit > 0:
            profit_factor = None
            profit_factor_status = "UNAVAILABLE_NO_LOSING_CLOSED_CYCLES"
        else:
            profit_factor = 0.0
            profit_factor_status = "AVAILABLE_NO_GROSS_PROFIT"
        cycle_metrics = {
            "status": "AVAILABLE",
            "reason": None,
            "closed_cycles": len(cycle_pnls),
            "winning_cycles": winners,
            "losing_cycles": sum(value < 0 for value in cycle_pnls),
            "win_rate_percent": round(winners / len(cycle_pnls) * 100, 6),
            "profit_factor": (
                round(profit_factor, 8) if profit_factor is not None else None
            ),
            "profit_factor_status": profit_factor_status,
            "expectancy_usdt": round(sum(cycle_pnls) / len(cycle_pnls), 8),
            "realized_cycle_pnl_usdt": round(sum(cycle_pnls), 8),
        }

    return {
        "buys": len(buy_rows),
        "accumulate_buys": accumulate_buys,
        "partial_buys": partial_buys,
        "sell_actions": len(sell_rows),
        "exits": full_exits,
        "exit_definition": "filled EXIT_ON_RISK actions that close the full replay position",
        "closed_trades": cycle_metrics["closed_cycles"],
        "closed_position_cycles": cycle_metrics["closed_cycles"],
        "open_position_cycles_at_end": open_cycles,
        "unmatched_sell_actions": unmatched_sells,
        "traded_notional_usdt": round(traded_notional, 8),
        "turnover_ratio": round(turnover_ratio, 8) if turnover_ratio is not None else None,
        "turnover_percent": (
            round(turnover_ratio * 100, 6) if turnover_ratio is not None else None
        ),
        "average_invested_capital_usdt": round(average_invested, 8),
        "average_equity_usdt": round(average_equity, 8),
        "cash_utilization_percent": round(cash_utilization, 6),
        "closed_cycle_metrics": cycle_metrics,
    }


def _context_coverage(decisions: list[dict], mode: str) -> dict:
    total = len(decisions)

    def module(name: str) -> dict:
        status_key = f"{name}_status"
        observed_key = f"{name}_observed_at"
        available = sum(row.get(status_key) == "AVAILABLE" for row in decisions)
        covered_rows = [
            row
            for row in decisions
            if row.get(status_key) == "AVAILABLE" and row.get(observed_key)
        ]
        events = sorted({str(row[observed_key]) for row in covered_rows})
        return {
            "evaluations": total,
            "available_status_evaluations": available,
            "covered_evaluations": len(covered_rows),
            "coverage_percent": round(len(covered_rows) / total * 100, 6)
            if total
            else 0.0,
            "unique_events_used": len(events),
            "first_observed_at": events[0] if events else None,
            "last_observed_at": events[-1] if events else None,
        }

    macro = module("macro")
    news = module("news")
    warnings: list[str] = []

    def require(label: str, coverage: dict) -> None:
        if coverage["covered_evaluations"] == 0:
            warnings.append(f"NO_HISTORICAL_{label}_CONTEXT_USED")
        elif coverage["covered_evaluations"] < total:
            warnings.append(f"PARTIAL_HISTORICAL_{label}_COVERAGE")

    if mode == "macro_only":
        require("MACRO", macro)
    elif mode == "verified_news":
        require("MACRO", macro)
        require("NEWS", news)
    return {"macro": macro, "news": news, "warnings": warnings}

@dataclass(frozen=True)
class HistoricalReplayConfig:
    start: str
    end: str
    frequency: str = "1d"
    mode: str = "market_only"
    universe_mode: str = "dynamic"
    universe_size: int = 30
    candidate_limit: int = 5
    max_open_positions: int = 5
    capital: float = 1000.0
    fee_rate: float = 0.001
    slippage_bps: float = 5.0
    min_cash_reserve_percent: float = 20.0
    max_trades_per_step: int = 4
    performance_mode: str = "balanced"
    strict_cutoff: bool = True
    btc_cap_percent: float = 30.0
    eth_cap_percent: float = 25.0
    alt_cap_percent: float = 15.0
    churn_guard_enabled: bool = True
    buy_cooldown_hours: float = float(AUTO_BUY_COOLDOWN_HOURS)
    # Production has no generic hold-time or time-only post-sell blocker.
    # The exact economic rebuy guard below replaces these legacy replay gates.
    reduce_min_hold_hours: float = 0.0
    reentry_cooldown_hours: float = 0.0
    pending_buy_ttl_hours: float = float(PENDING_BUY_TTL_HOURS)
    minimum_execution_notional_usdt: float = float(
        PAPER_MIN_EXECUTION_NOTIONAL_USDT
    )
    cache_only: bool = False
    strategy_mode: str = "full"
    event_continuation_mode: str = "production"
    # Requested macro/news context is never discarded silently.  This flag is
    # set only after an explicit user confirmation in CLI/Telegram.
    allow_context_fallback: bool = False

    def validate(self) -> None:
        if self.frequency not in VALID_FREQUENCIES:
            raise ValueError(f"frequency must be one of {sorted(VALID_FREQUENCIES)}")
        if self.mode not in VALID_MODES:
            raise ValueError(f"mode must be one of {sorted(VALID_MODES)}")
        if self.universe_mode not in VALID_UNIVERSE_MODES:
            raise ValueError(f"universe_mode must be one of {sorted(VALID_UNIVERSE_MODES)}")
        if self.strategy_mode not in VALID_STRATEGY_MODES:
            raise ValueError(f"strategy_mode must be one of {sorted(VALID_STRATEGY_MODES)}")
        if self.event_continuation_mode not in VALID_EVENT_CONTINUATION_MODES:
            raise ValueError(
                "event_continuation_mode must be one of "
                f"{sorted(VALID_EVENT_CONTINUATION_MODES)}"
            )
        if date.fromisoformat(self.start) > date.fromisoformat(self.end):
            raise ValueError("start date must not be after end date")
        if self.capital <= 0 or self.universe_size < 1 or self.candidate_limit < 1:
            raise ValueError("capital and limits must be positive")

class HistoricalReplayRunner:
    def __init__(self, engine, config: HistoricalReplayConfig, symbols: Iterable[str] | None = None):
        config.validate()
        self.engine = engine
        self.config = config
        self.fixed_symbols = list(dict.fromkeys(self._norm_symbol(x) for x in (symbols or []) if str(x).strip()))
        self.symbol_provider = SymbolProvider(client=engine.market_data.client, market_data=engine.market_data)
        self.cancel_event = threading.Event()
        self.pause_event = threading.Event()
        self.progress = self._progress_state(0, running=False, stage="IDLE")
        self._first_candle_cache: dict[str, int | None] = {}
        self._replay_cache: ReplayMarketDataCache | None = None
        self._daily_pool: list[str] = []
        self._last_buy_time: dict[str, datetime] = {}
        self._last_sell_time: dict[str, datetime] = {}
        self._position_opened_time: dict[str, datetime] = {}
        self._pending_buys: dict[str, dict] = {}
        self._post_sell_rebuy_reference: dict[str, dict] = {}
        self._execution_guard_store = MemoryGuardStateStore()
        self.execution_guard = DeteriorationGuard(self._execution_guard_store)
        self._guard_metrics = {
            "duplicate_reduce_blocked": 0,
            "new_deterioration_stage_executed": 0,
            "loss_reentry_blocked": 0,
            "loss_reentry_recovered": 0,
        }
        self._pending_metrics = {
            "placed": 0, "filled": 0, "expired": 0, "cancelled": 0,
            "reserved_peak_usdt": 0.0,
        }
        self.capital_recycling_engine = CapitalRecyclingEngine()
        self._recycling_state: dict[str, dict] = {}
        self._recycling_pools = {
            "rebuy_by_symbol": {}, "opportunity_usdt": 0.0,
            "retained_usdt": 0.0,
        }
        self._event_trades: list[dict] = []
        self._event_watch_rows: list[dict] = []
        event_mode = str(config.event_continuation_mode)
        dynamic_enabled = (
            EVENT_DYNAMIC_BASE_ENABLED if event_mode == "production"
            else event_mode in {"dynamic_base", "dynamic_micro", "dynamic_retest"}
        )
        micro_enabled = (
            EVENT_MICRO_PULLBACK_ENABLED if event_mode == "production"
            else event_mode == "dynamic_micro"
        )
        require_retest = (
            EVENT_DYNAMIC_BASE_REQUIRE_RETEST if event_mode == "production"
            else event_mode == "dynamic_retest"
        )
        self.event_watch_engine = EventWatchEngine(EventWatchConfig(
            confirmations_required=EVENT_CONFIRMATIONS_REQUIRED,
            duration_minutes=EVENT_WATCH_DURATION_MINUTES,
            max_chase_atr_multiple=EVENT_MAX_CHASE_ATR_MULTIPLE,
            max_chase_percent=EVENT_MAX_CHASE_PERCENT,
            retest_tolerance_atr_multiple=EVENT_RETEST_TOLERANCE_ATR_MULTIPLE,
            sharp_rejection_percent=EVENT_SHARP_REJECTION_PERCENT,
            max_additional_tranches=EVENT_MAX_ADDITIONAL_TRANCHES,
            tranche_cooldown_minutes=EVENT_TRANCHE_COOLDOWN_MINUTES,
            dynamic_base_enabled=dynamic_enabled,
            micro_pullback_enabled=micro_enabled,
            require_retest_after_dynamic_base=require_retest,
            minimum_consolidation_minutes=EVENT_MIN_CONSOLIDATION_MINUTES,
            minimum_base_quality=EVENT_MIN_BASE_QUALITY,
            max_anchor_resets=EVENT_MAX_ANCHOR_RESETS,
            anchor_reset_cooldown_minutes=EVENT_ANCHOR_RESET_COOLDOWN_MINUTES,
            max_duration_minutes=(
                EVENT_WATCH_DURATION_MINUTES
                if event_mode == "current" else EVENT_MAX_WATCH_DURATION_MINUTES
            ),
            extension_minutes=EVENT_WATCH_EXTENSION_MINUTES,
            max_base_range_atr=EVENT_MAX_BASE_RANGE_ATR,
            range_compression_max_ratio=EVENT_RANGE_COMPRESSION_MAX_RATIO,
            base_volume_contraction_max_ratio=EVENT_BASE_VOLUME_CONTRACTION_MAX_RATIO,
            base_volume_floor_ratio=EVENT_BASE_VOLUME_FLOOR_RATIO,
            base_breakout_buffer_atr=EVENT_BASE_BREAKOUT_BUFFER_ATR,
            max_total_extension_atr=EVENT_MAX_TOTAL_EXTENSION_ATR,
            max_total_extension_percent=EVENT_MAX_TOTAL_EXTENSION_PERCENT,
            micro_pullback_min_atr=EVENT_MICRO_PULLBACK_MIN_ATR,
            micro_pullback_max_atr=EVENT_MICRO_PULLBACK_MAX_ATR,
        ))
        self._recycling_metrics = {
            "weakness_signals": 0, "weakness_buys": 0,
            "weakness_added_usdt": 0.0, "harvests": 0,
            "harvest_proceeds_usdt": 0.0, "harvest_realized_pnl_usdt": 0.0,
            "rebuy_pool_usdt": 0.0, "opportunity_pool_usdt": 0.0,
            "retained_cash_usdt": 0.0, "reserve_blocked_buys": 0,
            "prevented_overallocation": 0,
            "weakness_drawdown_total_percent": 0.0,
            "reinvested_from_rebuy_pool_usdt": 0.0,
            "opportunity_allocations": 0,
            "reinvested_from_opportunity_pool_usdt": 0.0,
            "portfolio_cash_used_usdt": 0.0,
        }

    def _progress_state(
        self, cycles_total: int, *, running: bool, stage: str
    ) -> dict:
        return {
            "running": running, "stage": stage, "current": "", "symbol": "",
            "cycles_done": 0, "cycles_total": max(0, int(cycles_total)),
            "symbols_done_current_cycle": 0,
            "symbols_total_current_cycle": 0,
            "cache_symbols_done": 0, "cache_symbols_total": 0,
            "work_done": 0, "work_total": max(0, int(cycles_total)),
            "percent": 0.0,
            # Backward-compatible aliases for older Telegram readers.
            "processed": 0, "total": max(0, int(cycles_total)),
            "symbols_total": 0, "operations": 0,
            "portfolio_value": float(self.config.capital),
        }

    def _refresh_progress(self) -> None:
        cycles_done = min(
            max(0, int(self.progress.get("cycles_done") or 0)),
            max(0, int(self.progress.get("cycles_total") or 0)),
        )
        cache_done = min(
            max(0, int(self.progress.get("cache_symbols_done") or 0)),
            max(0, int(self.progress.get("cache_symbols_total") or 0)),
        )
        total = max(
            0,
            int(self.progress.get("cycles_total") or 0)
            + int(self.progress.get("cache_symbols_total") or 0),
        )
        done = min(total, cycles_done + cache_done)
        self.progress.update({
            "cycles_done": cycles_done,
            "cache_symbols_done": cache_done,
            "work_done": done,
            "work_total": total,
            "percent": max(0.0, min(100.0, done / total * 100 if total else 0.0)),
            "processed": cycles_done,
            "total": int(self.progress.get("cycles_total") or 0),
            "symbols_total": int(
                self.progress.get("symbols_total_current_cycle") or 0
            ),
        })

    def _control_checkpoint(self, *, current: str = "", symbol: str = "") -> bool:
        """Return False when cancellation was requested; block while paused.

        A checkpoint is deliberately called between network/analysis units so pause/stop
        reacts after the current request, not after a whole historical candle.
        """
        if current:
            self.progress["current"] = current
        if symbol:
            self.progress["symbol"] = symbol
        if self.cancel_event.is_set():
            self.progress["stage"] = "STOPPING"
            return False
        while self.pause_event.is_set():
            self.progress["stage"] = "PAUSED"
            if self.cancel_event.wait(0.2):
                self.progress["stage"] = "STOPPING"
                return False
        if self.progress.get("stage") in {"PAUSED", "PAUSE_REQUESTED"}:
            self.progress["stage"] = "RUNNING"
        return not self.cancel_event.is_set()

    @staticmethod
    def _norm_symbol(value: str) -> str:
        value = str(value).strip().upper()
        return value if value.endswith("USDT") else value + "USDT"

    def _step_delta(self) -> timedelta:
        return {"4h": timedelta(hours=4), "1d": timedelta(days=1), "1w": timedelta(days=7)}[self.config.frequency]

    def _interval(self) -> str:
        return {"4h": "4h", "1d": "1d", "1w": "1w"}[self.config.frequency]

    def _times(self) -> list[datetime]:
        start = datetime.combine(date.fromisoformat(self.config.start), time.min, tzinfo=timezone.utc)
        end = datetime.combine(date.fromisoformat(self.config.end), time.max, tzinfo=timezone.utc)
        # Binance weekly candles open on Monday 00:00 UTC.  v4.7 generated
        # weekly execution timestamps from the literal user start date, which meant
        # Sunday-start replays asked Binance for a non-existent weekly candle.
        if self.config.frequency == "1w":
            days_to_monday = (7 - start.weekday()) % 7
            start = start + timedelta(days=days_to_monday)
        result = []
        current = start
        delta = self._step_delta()
        while current <= end:
            result.append(current)
            current += delta
        return result

    def _first_open_ms(self, symbol: str) -> int | None:
        if symbol not in self._first_candle_cache:
            first = self.engine.market_data.get_first_daily_candle(symbol)
            self._first_candle_cache[symbol] = int(first["open_time"]) if first else None
        return self._first_candle_cache[symbol]

    def _age_info(self, symbol: str, cutoff_ms: int) -> tuple[int, str, float]:
        first_ms = self._first_open_ms(symbol)
        if first_ms is None or first_ms > cutoff_ms:
            return -1, "NOT_LISTED", 0.0
        age = int((cutoff_ms - first_ms) / 86_400_000)
        if age < 30:
            return age, "EXCLUDED", 0.0
        if age < 90:
            return age, "WATCH_ONLY", 0.0
        if age < 180:
            return age, "NORMAL_BUY_ALLOWED", 5.0
        if age < 365:
            return age, "HIGHER_CONFIDENCE", 10.0
        cap = self.config.btc_cap_percent if symbol == "BTCUSDT" else self.config.eth_cap_percent if symbol == "ETHUSDT" else self.config.alt_cap_percent
        return age, "MATURE_HISTORY", cap

    def _historical_volume(self, symbol: str, cutoff_ms: int) -> float:
        try:
            rows = self.engine.market_data.get_klines(symbol, "1d", 30, as_of_ms=cutoff_ms)
            values = [float(r.get("quote_asset_volume") or r.get("quote_volume") or 0) for r in rows]
            return sum(values) / len(values) if values else 0.0
        except Exception:
            return 0.0

    def _prepare_cache(self, times: list[datetime]) -> None:
        original = self.engine.market_data
        start_ms = int(times[0].timestamp() * 1000) if times else int(datetime.now(timezone.utc).timestamp() * 1000)
        end_ms = int((times[-1] + self._step_delta()).timestamp() * 1000) if times else start_ms
        self._replay_cache = ReplayMarketDataCache(
            original, start_ms, end_ms, cache_only=self.config.cache_only
        )
        self.engine.market_data = self._replay_cache
        self.symbol_provider.market_data = self._replay_cache

        pool = self.fixed_symbols if self.config.universe_mode == "fixed" else list(self.symbol_provider.get_exchange_symbols())
        self._daily_pool = list(dict.fromkeys(pool))
        self.progress.update({
            "stage": "CACHE_DAILY", "current": "", "symbol": "",
            "cache_symbols_done": 0,
            "cache_symbols_total": len(self._daily_pool),
        })
        self._refresh_progress()
        for idx, symbol in enumerate(self._daily_pool, 1):
            if not self._control_checkpoint(symbol=symbol):
                break
            try:
                self._replay_cache.ensure(symbol, "1d")
            except Exception:
                pass
            self.progress["cache_symbols_done"] = idx
            self._refresh_progress()

    def _restore_market_data(self, original_market_data) -> None:
        self.engine.market_data = original_market_data
        self.symbol_provider.market_data = original_market_data

    def _universe(self, cutoff_ms: int) -> tuple[list[str], list[dict]]:
        if self.config.universe_mode == "fixed":
            pool = self.fixed_symbols
        else:
            pool = self._daily_pool or list(self.symbol_provider.get_exchange_symbols())
        rows = []
        for symbol in pool:
            age, status, cap = self._age_info(symbol, cutoff_ms)
            volume = self._historical_volume(symbol, cutoff_ms) if status not in {"NOT_LISTED", "EXCLUDED"} else 0.0
            rows.append({"symbol": symbol, "age_days": age, "age_status": status, "position_cap_percent": cap, "volume_30d": volume})
        eligible = [r for r in rows if r["age_status"] not in {"NOT_LISTED", "EXCLUDED"}]
        eligible.sort(key=lambda r: (r["symbol"] not in {"BTCUSDT", "ETHUSDT"}, -r["volume_30d"]))
        selected = eligible[: self.config.universe_size]
        selected_symbols = [r["symbol"] for r in selected]
        # A live pending order remains monitored even if the dynamic rank later
        # moves outside today's top-N universe.
        for symbol in self._pending_buys:
            if symbol not in selected_symbols:
                selected_symbols.append(symbol)
        return selected_symbols, rows

    def _filter_store(
        self, store: PointInTimeStore | None, *, mode: str | None = None
    ) -> PointInTimeStore:
        events = list((store or PointInTimeStore([])).events)
        selected_mode = mode or self.config.mode
        if selected_mode == "market_only":
            events = []
        elif selected_mode == "macro_only":
            events = [e for e in events if e.get("kind") == "macro"]
        else:
            events = [e for e in events if e.get("kind") in {"macro", "news"}]
        return PointInTimeStore(events)

    def _assert_safe(self, analysis: dict, cutoff: datetime) -> None:
        quality = analysis.get("data_quality") or {}
        if quality.get("mode") != "POINT_IN_TIME_REPLAY" or quality.get("lookahead_guard") != "ENFORCED":
            raise LookAheadError("point-in-time guard not enforced")
        for close_ms in (quality.get("last_closed_candle_ms") or {}).values():
            if close_ms is not None and int(close_ms) > int(cutoff.timestamp() * 1000):
                raise LookAheadError("future candle detected")

    def _execution_open(self, symbol: str, execution_time: datetime) -> float:
        interval = self._interval()
        step = self._step_delta()
        start_ms = int(execution_time.timestamp() * 1000)
        end_ms = int((execution_time + step).timestamp() * 1000) - 1
        rows = self.engine.market_data.get_historical_klines(symbol, interval, start_ms, end_ms, page_size=2)
        if not rows:
            raise RuntimeError("execution candle unavailable")
        first_open = int(rows[0].get("open_time") or -1)
        if first_open != start_ms:
            raise RuntimeError(
                f"execution candle misaligned: expected {start_ms}, got {first_open}"
            )
        return float(rows[0]["open"])

    def _hours_since(self, value: datetime | None, now: datetime) -> float | None:
        if value is None:
            return None
        return max(0.0, (now - value).total_seconds() / 3600.0)

    def _execution_guard(
        self, portfolio: ReplayPortfolio, analysis: dict, execution_time: datetime
    ) -> tuple[bool, str]:
        """Strategy-level anti-churn guard for historical spot replay.

        EXIT_ON_RISK is never delayed.  Ordinary REDUCE is allowed only after a
        minimum holding period, repeated buys are cooled down, and a recent sell
        cannot immediately flip back into a new buy.  Every rejection is audited.
        """
        if not self.config.churn_guard_enabled:
            return True, "ok"
        symbol = analysis["symbol"]
        decision = analysis.get("decision")
        position = portfolio.get(symbol)
        self.execution_guard.observe_analysis(
            symbol, analysis,
            position_exists=self._production_quantity(portfolio, symbol) > 0,
        )
        if decision == "REDUCE" and position.quantity > 0:
            deterioration = self.execution_guard.evaluate_reduce(symbol, analysis)
            analysis["_deterioration_guard_proposal"] = deterioration
            if not deterioration.allowed:
                self._guard_metrics["duplicate_reduce_blocked"] += 1
                return False, deterioration.reason
        if decision in BUY_DECISIONS:
            reentry = self.execution_guard.evaluate_reentry(symbol, analysis)
            analysis["_loss_reentry_guard_proposal"] = reentry
            if not reentry.allowed:
                self._guard_metrics["loss_reentry_blocked"] += 1
                analysis["_loss_reentry_guard_counted"] = True
                return False, reentry.reason
            since_buy = self._hours_since(self._last_buy_time.get(symbol), execution_time)
            if since_buy is not None and since_buy < self.config.buy_cooldown_hours:
                return False, "BUY_COOLDOWN_ACTIVE"
            since_sell = self._hours_since(self._last_sell_time.get(symbol), execution_time)
            if since_sell is not None and since_sell < self.config.reentry_cooldown_hours:
                return False, "REENTRY_COOLDOWN_ACTIVE"
            if position.quantity <= 0 and len(portfolio.open_positions()) >= self.config.max_open_positions:
                return False, "MAX_OPEN_POSITIONS"
        if decision == "REDUCE" and position.quantity > 0:
            held = self._hours_since(self._position_opened_time.get(symbol), execution_time)
            if held is not None and held < self.config.reduce_min_hold_hours:
                return False, "MIN_HOLD_BEFORE_REDUCE"
        return True, "ok"

    @staticmethod
    def _context_fields(result: dict) -> dict:
        technical = result.get("technical") or {}
        macro = result.get("macro") or {}
        news = result.get("news") or {}
        # InvestmentAnalysis exposes the v5.1.1 sleeve at top level.  Older
        # replay artifacts used ``research.event_momentum``; retain that as a
        # read-only compatibility fallback.
        event = result.get("event_momentum") or (
            (result.get("research") or {}).get("event_momentum") or {}
        )
        return {
            "technical_score": technical.get("technical_score"),
            "macro_status": macro.get("status", "UNAVAILABLE"),
            "macro_regime": macro.get("regime", "UNAVAILABLE"),
            "macro_multiplier": macro.get("position_size_multiplier", 1.0),
            "macro_observed_at": ((macro.get("point_in_time") or {}).get("observed_at")),
            "news_status": news.get("status", "UNAVAILABLE"),
            "news_impact": news.get("impact", "UNAVAILABLE"),
            "news_multiplier": news.get("position_size_multiplier", 1.0),
            "news_observed_at": ((news.get("point_in_time") or {}).get("observed_at")),
            "final_score": result.get("score"),
            "event_state": event.get("state") or event.get("status", "NO_EVENT"),
            "event_shadow_action": event.get("shadow_action") or (
                "STARTER_BUY" if event.get("status") == "NEWS_EVENT_BUY_CANDIDATE" else "NONE"
            ),
            "event_grade": event.get("grade") or event.get("score"),
            "event_allocation_fraction": event.get("allocation_fraction") or float(event.get("starter_percent") or 0) / 100,
            "event_entry_price": result.get("current_price"),
            "event_factors": "|".join(event.get("factors") or []),
            "event_blockers": "|".join(event.get("blockers") or []),
        }

    def _event_momentum_outcomes(self, decisions: list[dict]) -> list[dict]:
        rows: list[dict] = []
        replay_end = datetime.combine(
            date.fromisoformat(self.config.end), time.max, tzinfo=timezone.utc
        )
        for decision in decisions:
            if str(decision.get("event_shadow_action") or "") != "STARTER_BUY":
                continue
            try:
                entry = float(decision.get("event_entry_price") or 0)
                if entry <= 0:
                    continue
                when = datetime.fromisoformat(str(decision["timestamp"]).replace("Z", "+00:00"))
                if when.tzinfo is None:
                    when = when.replace(tzinfo=timezone.utc)
                output = {
                    "timestamp": decision["timestamp"],
                    "symbol": decision["symbol"],
                    "production_decision": decision.get("decision"),
                    "production_score": decision.get("score"),
                    "event_grade": decision.get("event_grade"),
                    "allocation_fraction": decision.get("event_allocation_fraction"),
                    "entry_price": entry,
                    "event_factors": decision.get("event_factors"),
                }
                for hours in (1, 4, 24, 72):
                    target = when + timedelta(hours=hours)
                    if target > replay_end:
                        output[f"return_{hours}h_percent"] = None
                        output[f"mfe_{hours}h_percent"] = None
                        output[f"mae_{hours}h_percent"] = None
                        continue
                    target_ms = int(target.timestamp() * 1000)
                    try:
                        px = float(self.engine.market_data.get_price_at(
                            decision["symbol"], target_ms, interval="1h"
                        ))
                        candles = self.engine.market_data.get_historical_klines(
                            decision["symbol"], "1h",
                            int(when.timestamp() * 1000), target_ms, page_size=1000
                        )
                        highs = [float(item["high"]) for item in candles if item.get("high") is not None]
                        lows = [float(item["low"]) for item in candles if item.get("low") is not None]
                        output[f"return_{hours}h_percent"] = round((px / entry - 1) * 100, 6)
                        output[f"mfe_{hours}h_percent"] = round(((max(highs) if highs else px) / entry - 1) * 100, 6)
                        output[f"mae_{hours}h_percent"] = round(((min(lows) if lows else px) / entry - 1) * 100, 6)
                    except Exception:
                        output[f"return_{hours}h_percent"] = None
                        output[f"mfe_{hours}h_percent"] = None
                        output[f"mae_{hours}h_percent"] = None
                rows.append(output)
            except Exception:
                continue
        return rows

    @staticmethod
    def _event_momentum_summary(rows: list[dict]) -> dict:
        summary = {"signals": len(rows), "research_only": True}
        for hours in (1, 4, 24, 72):
            values = [
                float(row[f"return_{hours}h_percent"])
                for row in rows if row.get(f"return_{hours}h_percent") is not None
            ]
            if not values:
                summary[f"{hours}h"] = {"measured": 0}
                continue
            ordered = sorted(values)
            n = len(ordered)
            median = ordered[n // 2] if n % 2 else (ordered[n // 2 - 1] + ordered[n // 2]) / 2
            summary[f"{hours}h"] = {
                "measured": n,
                "win_rate_percent": round(sum(value > 0 for value in values) / n * 100, 2),
                "mean_return_percent": round(sum(values) / n, 6),
                "median_return_percent": round(median, 6),
            }
        return summary

    def _position_states(self, portfolio: ReplayPortfolio, marks: dict[str, float]) -> list[PositionState]:
        return [p.state(marks.get(p.symbol, p.average_price)) for p in portfolio.open_positions()]

    @property
    def _recycling_enabled(self) -> bool:
        return self.config.strategy_mode in {"baseline_recycling", "full"}

    @property
    def _event_enabled(self) -> bool:
        return self.config.strategy_mode in {"baseline_news_event", "full"}

    def _event_quantity(self, symbol: str) -> float:
        return sum(
            float(item.get("remaining_quantity") or 0)
            for item in self._event_trades
            if item.get("symbol") == symbol and item.get("status") in {"OPEN", "PARTIAL"}
        )

    def _production_quantity(self, portfolio: ReplayPortfolio, symbol: str) -> float:
        return max(0.0, portfolio.get(symbol).quantity - self._event_quantity(symbol))

    def _reserve_policy(self, analysis: dict):
        return reserve_policy_for_macro((analysis.get("macro") or {}).get("regime"))

    def _reserved_cash(self, *, exclude_symbol: str | None = None) -> float:
        return sum(
            max(0.0, float(order.get("amount_usdt") or 0.0))
            for symbol, order in self._pending_buys.items()
            if symbol != exclude_symbol
        )

    def _available_cash(self, portfolio: ReplayPortfolio) -> float:
        return max(0.0, portfolio.cash - self._reserved_cash())

    @staticmethod
    def _fundamentals_execution_gate(symbol: str, analysis: dict) -> dict:
        # Reuse the live production normalization rather than copying a second
        # UNKNOWN/PARTIAL policy into the tester.
        from automation.engine import AutonomousPaperPortfolio

        return AutonomousPaperPortfolio._fundamentals_execution_gate(symbol, analysis)

    def _evaluate_post_sell_rebuy_guard(
        self, symbol: str, market_price: float
    ) -> tuple[bool, dict]:
        reference = self._post_sell_rebuy_reference.get(symbol)
        if not reference:
            return True, {"active": False, "result": "ALLOW"}
        fill = float(market_price) * (1 + self.config.slippage_bps / 10_000)
        denominator = 1.0 - self.config.fee_rate
        all_in = fill / denominator if denominator > 0 else float("inf")
        sell_net = float(reference["last_sell_net_unit_proceeds"])
        allowed = all_in < sell_net
        return allowed, {
            "active": True,
            "result": "ALLOW" if allowed else "BLOCK",
            "last_sell_at": reference["created_at"],
            "last_sell_price": reference["last_sell_price"],
            "last_sell_net_unit_proceeds": sell_net,
            "expected_buy_fill_price": fill,
            "expected_buy_all_in_unit_cost": all_in,
            "net_discount_pct": (
                (sell_net - all_in) / sell_net * 100 if sell_net > 0 else None
            ),
        }

    def _buy_terms(
        self,
        portfolio: ReplayPortfolio,
        analysis: dict,
        raw_price: float,
        marks: dict[str, float],
        age_cap: float,
    ) -> tuple[dict | None, float, str]:
        symbol = str(analysis["symbol"])
        position = portfolio.get(symbol)
        total = portfolio.value(marks)
        reserve_policy = self._reserve_policy(analysis)
        reserve = total * reserve_policy.target_percent / 100
        spendable = max(0.0, self._available_cash(portfolio) - reserve)
        cap = total * age_cap / 100
        remaining = max(0.0, cap - position.quantity * raw_price)
        zones = (analysis.get("accumulation_plan") or {}).get("zones") or []
        zone = next(
            (item for item in zones if float(item.get("amount_usdt") or 0) > 0),
            None,
        )
        if not zone:
            return None, 0.0, "NO_BUY_ZONE"
        requested = float(zone.get("amount_usdt") or 0)
        notional = min(requested, spendable, remaining)
        if requested > notional + 1e-9:
            self._recycling_metrics["prevented_overallocation"] += 1
        if spendable < self.config.minimum_execution_notional_usdt:
            self._recycling_metrics["reserve_blocked_buys"] += 1
        return dict(zone), notional, "OK"

    def _place_pending_buy(
        self,
        portfolio: ReplayPortfolio,
        analysis: dict,
        raw_price: float,
        marks: dict[str, float],
        age_cap: float,
        execution_time: datetime,
    ) -> str:
        symbol = str(analysis["symbol"])
        if symbol in self._pending_buys:
            return "PENDING_BUY_EXISTS"
        zone, amount, reason = self._buy_terms(
            portfolio, analysis, raw_price, marks, age_cap
        )
        if zone is None:
            return reason
        if amount < self.config.minimum_execution_notional_usdt:
            return "BUY_NOTIONAL_BELOW_MINIMUM"
        self._pending_buys[symbol] = {
            "symbol": symbol,
            "created_at": execution_time,
            "lower_price": float(zone["lower"]),
            "upper_price": float(zone["upper"]),
            "amount_usdt": float(amount),
            "decision": str(analysis.get("decision") or "BUY_PARTIALLY"),
            "age_cap": float(age_cap),
            "reserve_target_percent": self._reserve_policy(analysis).target_percent,
            "historical_liquidity_capability": "PARITY_UNAVAILABLE_ORDER_BOOK_DEPTH",
        }
        self._pending_metrics["placed"] += 1
        self._pending_metrics["reserved_peak_usdt"] = max(
            float(self._pending_metrics["reserved_peak_usdt"]),
            self._reserved_cash(),
        )
        return "PENDING_BUY_PLACED"

    def _cancel_pending_buy(self, symbol: str, reason: str) -> dict:
        order = self._pending_buys.pop(symbol)
        if reason.startswith("PENDING_BUY_TTL_EXPIRED"):
            self._pending_metrics["expired"] += 1
        else:
            self._pending_metrics["cancelled"] += 1
        return {
            "event": "PENDING_BUY_CANCELLED",
            "symbol": symbol,
            "reason": reason,
            "reserved_cash_released_usdt": float(order["amount_usdt"]),
        }

    def _process_pending_buys(
        self,
        portfolio: ReplayPortfolio,
        analyses: list[dict],
        marks: dict[str, float],
        execution_time: datetime,
    ) -> tuple[list[dict], list[dict]]:
        fills: list[dict] = []
        events: list[dict] = []
        by_symbol = {str(row.get("symbol")): row for row in analyses}
        ttl = timedelta(hours=self.config.pending_buy_ttl_hours)
        for symbol in sorted(tuple(self._pending_buys)):
            order = self._pending_buys.get(symbol)
            if order is None:
                continue
            if execution_time - order["created_at"] >= ttl:
                events.append(self._cancel_pending_buy(
                    symbol,
                    f"PENDING_BUY_TTL_EXPIRED:{self.config.pending_buy_ttl_hours:g}h",
                ))
                continue
            analysis = by_symbol.get(symbol)
            if analysis is None:
                continue
            if str(analysis.get("decision")) not in BUY_DECISIONS:
                events.append(self._cancel_pending_buy(
                    symbol, "PENDING_BUY_SIGNAL_NO_LONGER_ACTIVE"
                ))
                continue
            fundamentals = self._fundamentals_execution_gate(symbol, analysis)
            if not fundamentals["pass"]:
                events.append(self._cancel_pending_buy(
                    symbol, f"PENDING_BUY_CONTEXT_BLOCKED:{fundamentals['reason']}"
                ))
                continue
            try:
                raw_price = self._execution_open(symbol, execution_time)
            except Exception:
                continue
            marks[symbol] = raw_price
            if not (
                float(order["lower_price"]) <= raw_price <= float(order["upper_price"])
            ):
                continue
            current_zones = (analysis.get("accumulation_plan") or {}).get("zones") or []
            current_zone = next(
                (row for row in current_zones if float(row.get("amount_usdt") or 0) > 0),
                None,
            )
            if current_zone is None:
                events.append(self._cancel_pending_buy(
                    symbol, "PENDING_BUY_NO_CURRENT_ENTRY_ZONE"
                ))
                continue
            if not (
                float(current_zone["lower"]) <= raw_price <= float(current_zone["upper"])
            ):
                events.append(self._cancel_pending_buy(
                    symbol, "PENDING_BUY_PRICE_OUTSIDE_CURRENT_ENTRY_ZONE"
                ))
                continue
            if float(order["amount_usdt"]) > float(current_zone.get("amount_usdt") or 0) + 1e-8:
                events.append(self._cancel_pending_buy(
                    symbol, "PENDING_BUY_CURRENT_CAPACITY_REDUCED"
                ))
                continue
            if portfolio.get(symbol).quantity <= 0 and len(portfolio.open_positions()) >= self.config.max_open_positions:
                events.append(self._cancel_pending_buy(symbol, "MAX_OPEN_POSITIONS"))
                continue
            allowed, guard_reason = self._execution_guard(
                portfolio, analysis, execution_time
            )
            if not allowed:
                events.append(self._cancel_pending_buy(symbol, guard_reason))
                continue
            rebuy_allowed, rebuy = self._evaluate_post_sell_rebuy_guard(symbol, raw_price)
            if not rebuy_allowed:
                events.append(self._cancel_pending_buy(
                    symbol, "REBUY_NOT_CHEAPER_THAN_LAST_SELL"
                ))
                continue
            amount = float(order["amount_usdt"])
            # Match production: release the reservation before normal fill
            # checks, so it cannot be counted twice against available cash.
            self._pending_buys.pop(symbol, None)
            action, reason = self._buy_notional(
                portfolio, symbol, raw_price, amount, str(order["decision"]),
                execution_time, strategy_layer="BASELINE",
                rebuy_guard_checked=True, guard_analysis=analysis,
            )
            if action:
                action["pending_buy_fill"] = True
                action["post_sell_rebuy_guard"] = rebuy
                fills.append(action)
                self._pending_metrics["filled"] += 1
            else:
                events.append({
                    "event": "PENDING_BUY_CANCELLED", "symbol": symbol,
                    "reason": reason, "reserved_cash_released_usdt": amount,
                })
                self._pending_metrics["cancelled"] += 1
        return fills, events

    def _buy_notional(
        self,
        portfolio: ReplayPortfolio,
        symbol: str,
        raw_price: float,
        notional: float,
        decision: str,
        execution_time: datetime,
        *,
        strategy_layer: str,
        rebuy_guard_checked: bool = False,
        guard_analysis: dict | None = None,
    ) -> tuple[dict | None, str]:
        notional = min(
            max(0.0, float(notional)), max(0.0, self._available_cash(portfolio))
        )
        if notional < self.config.minimum_execution_notional_usdt:
            return None, "BUY_NOTIONAL_BELOW_MINIMUM"
        rebuy_details = {"active": False, "result": "ALLOW"}
        if strategy_layer != "NEWS_EVENT" and not rebuy_guard_checked:
            allowed, rebuy_details = self._evaluate_post_sell_rebuy_guard(
                symbol, raw_price
            )
            if not allowed:
                return None, "REBUY_NOT_CHEAPER_THAN_LAST_SELL"
        reentry = None
        if strategy_layer != "NEWS_EVENT" and guard_analysis is not None:
            reentry = guard_analysis.get("_loss_reentry_guard_proposal")
            if reentry is None:
                reentry = self.execution_guard.evaluate_reentry(symbol, guard_analysis)
            if not reentry.allowed:
                if not guard_analysis.get("_loss_reentry_guard_counted"):
                    self._guard_metrics["loss_reentry_blocked"] += 1
                    guard_analysis["_loss_reentry_guard_counted"] = True
                return None, reentry.reason
        price = raw_price * (1 + self.config.slippage_bps / 10_000)
        fee = notional * self.config.fee_rate
        quantity = (notional - fee) / price
        if quantity <= 0 or portfolio.cash + 1e-9 < notional:
            return None, "INSUFFICIENT_CASH"
        position = portfolio.get(symbol)
        was_empty = position.quantity <= 1e-12
        position.quantity += quantity
        position.cost_basis += notional
        portfolio.cash = max(0.0, portfolio.cash - notional)
        portfolio.fees_paid += fee
        portfolio.slippage_paid += quantity * (price - raw_price)
        portfolio.trades += 1
        if was_empty:
            self._position_opened_time[symbol] = execution_time
        self._last_buy_time[symbol] = execution_time
        if reentry is not None and reentry.reason == LOSS_REDUCE_THESIS_RECOVERED:
            self.execution_guard.record_buy_fill(symbol, reentry)
            self._guard_metrics["loss_reentry_recovered"] += 1
        return {
            "side": "BUY", "symbol": symbol, "decision": decision,
            "strategy_layer": strategy_layer, "quantity": quantity,
            "market_price": raw_price, "execution_price": price,
            "notional": notional, "fee": fee,
            "post_sell_rebuy_guard": rebuy_details,
            "loss_reduce_reentry_guard": (
                {"reason": reentry.reason, **reentry.details}
                if reentry is not None else {"active": False}
            ),
        }, "FILLED"

    def _buy(self, portfolio: ReplayPortfolio, analysis: dict, raw_price: float, marks: dict[str, float], age_cap: float, execution_time: datetime) -> tuple[dict | None, str]:
        symbol = str(analysis["symbol"])
        decision = str(analysis["decision"])
        position = portfolio.get(symbol)
        if position.quantity <= 0 and len(portfolio.open_positions()) >= self.config.max_open_positions:
            return None, "MAX_OPEN_POSITIONS"
        zone, notional, reason = self._buy_terms(
            portfolio, analysis, raw_price, marks, age_cap
        )
        if zone is None:
            return None, reason
        if not (float(zone["lower"]) <= raw_price <= float(zone["upper"])):
            pending = self._place_pending_buy(
                portfolio, analysis, raw_price, marks, age_cap, execution_time
            )
            return None, pending
        return self._buy_notional(
            portfolio, symbol, raw_price, notional, decision, execution_time,
            strategy_layer="BASELINE", guard_analysis=analysis,
        )

    def _sell_quantity(
        self, portfolio: ReplayPortfolio, symbol: str, raw_price: float,
        quantity: float, decision: str, execution_time: datetime, *,
        strategy_layer: str, require_positive_net: bool = False,
    ) -> tuple[dict | None, str]:
        p = portfolio.get(symbol)
        qty = min(max(0.0, float(quantity)), p.quantity)
        if qty <= 0:
            return None, "NO_POSITION"
        price = raw_price * (1 - self.config.slippage_bps / 10000)
        gross = qty * price
        is_partial = qty + 1e-12 < p.quantity
        if (
            is_partial
            and gross < self.config.minimum_execution_notional_usdt
        ):
            return None, "DUST_PARTIAL_REDUCTION_SKIPPED"
        fee = gross * self.config.fee_rate
        fraction = qty / p.quantity if p.quantity > 0 else 0.0
        basis = p.cost_basis * fraction
        proceeds = gross - fee
        if require_positive_net and proceeds <= basis + 1e-12:
            return None, "TAKE_PROFIT_NOT_POSITIVE_NET"
        p.quantity -= qty; p.cost_basis -= basis
        if p.quantity < 1e-12: p.quantity = 0.0; p.cost_basis = 0.0
        portfolio.cash += proceeds
        portfolio.fees_paid += fee
        portfolio.slippage_paid += qty * (raw_price - price)
        portfolio.realized_pnl += proceeds - basis
        portfolio.trades += 1
        self._last_sell_time[symbol] = execution_time
        if strategy_layer != "NEWS_EVENT":
            realized = proceeds - basis
            if p.quantity <= 1e-12:
                self._post_sell_rebuy_reference.pop(symbol, None)
            elif realized > 0 and qty > 0:
                self._post_sell_rebuy_reference[symbol] = {
                    "created_at": execution_time.isoformat(),
                    "last_sell_price": price,
                    "last_sell_quantity": qty,
                    "last_sell_fee_usdt": fee,
                    "last_sell_net_unit_proceeds": price - fee / qty,
                    "realized_pnl_usdt": realized,
                    "remaining_quantity_after_sell": p.quantity,
                }
            else:
                self._post_sell_rebuy_reference.pop(symbol, None)
        if p.quantity <= 0:
            self._position_opened_time.pop(symbol, None)
        return {"side":"SELL","symbol":symbol,"decision":decision,"strategy_layer":strategy_layer,"quantity":qty,"market_price":raw_price,"execution_price":price,"proceeds":proceeds,"fee":fee,"cost_basis_sold":basis,"realized_pnl":proceeds-basis}, "FILLED"

    def _sell(
        self, portfolio: ReplayPortfolio, analysis: dict, raw_price: float,
        execution_time: datetime,
    ) -> tuple[dict | None, str]:
        symbol = str(analysis["symbol"])
        decision = str(analysis["decision"])
        production_quantity = self._production_quantity(portfolio, symbol)
        if decision == "TAKE_PROFIT":
            target = ((analysis.get("take_profit_plan") or {}).get("targets") or [{}])[0]
            fraction = max(
                0.05,
                min(float(target.get("sell_percent_of_position", 25.0)) / 100.0, 1.0),
            )
        else:
            fraction = {"REDUCE": 0.25, "EXIT_ON_RISK": 1.0}[decision]
        action, reason = self._sell_quantity(
            portfolio, symbol, raw_price, production_quantity * fraction,
            decision, execution_time, strategy_layer="BASELINE",
            require_positive_net=decision == "TAKE_PROFIT",
        )
        if action and decision == "REDUCE":
            reduction = analysis.get("_deterioration_guard_proposal")
            if reduction is None:
                reduction = self.execution_guard.evaluate_reduce(symbol, analysis)
            self.execution_guard.record_reduce_fill(
                symbol, reduction,
                net_pnl_usdt=float(action.get("realized_pnl") or 0.0),
                executed_at=execution_time.isoformat(),
            )
            action["deterioration_guard"] = {
                "reason": reduction.reason, **reduction.details,
            }
            if reduction.reason == REDUCE_NEW_DETERIORATION_STAGE:
                self._guard_metrics["new_deterioration_stage_executed"] += 1
        if action and self._production_quantity(portfolio, symbol) <= 1e-12:
            self.execution_guard.reset(symbol, f"FULL_{decision}_CLOSE")
        return action, reason

    def _capital_recycling_action(
        self,
        portfolio: ReplayPortfolio,
        analysis: dict,
        raw_price: float,
        marks: dict[str, float],
        execution_time: datetime,
    ) -> tuple[dict | None, str]:
        if not self._recycling_enabled:
            return None, "DISABLED"
        symbol = str(analysis["symbol"])
        production_quantity = self._production_quantity(portfolio, symbol)
        if production_quantity <= 0 or str(analysis.get("decision")) in SELL_DECISIONS:
            return None, "NOT_APPLICABLE"
        state = self._recycling_state.setdefault(symbol, {
            "peak_price": raw_price, "harvest_stage": 0, "weakness_stage": 0,
            "harvest_reference_quantity": 0.0, "last_harvest_price": 0.0,
            "last_weakness_buy_price": 0.0,
        })
        state["peak_price"] = max(float(state.get("peak_price") or 0), raw_price)
        position = portfolio.get(symbol)
        production_basis = position.cost_basis * (
            production_quantity / position.quantity if position.quantity > 0 else 0.0
        )
        pnl_percent = (
            (production_quantity * raw_price / production_basis - 1) * 100
            if production_basis > 0 else 0.0
        )
        signal = self.capital_recycling_engine.assess(
            analysis=analysis, current_price=raw_price,
            position_pnl_percent=pnl_percent, state=state,
        )
        if signal.action == "HARVEST_PROFIT":
            reference = float(state.get("harvest_reference_quantity") or 0) or production_quantity
            action, reason = self._sell_quantity(
                portfolio, symbol, raw_price,
                min(production_quantity, reference * signal.sell_percent / 100),
                "HARVEST_PROFIT", execution_time,
                strategy_layer="CAPITAL_RECYCLING",
            )
            if action:
                proceeds = float(action.get("proceeds") or 0)
                total_share = max(1e-9, RECYCLE_REBUY_SHARE_PERCENT + RECYCLE_OPPORTUNITY_SHARE_PERCENT + RECYCLE_RETAINED_SHARE_PERCENT)
                rebuy = proceeds * RECYCLE_REBUY_SHARE_PERCENT / total_share
                opportunity = proceeds * RECYCLE_OPPORTUNITY_SHARE_PERCENT / total_share
                retained = proceeds - rebuy - opportunity
                action["proceeds_split"] = {
                    "rebuy_pool_usdt": rebuy,
                    "opportunity_pool_usdt": opportunity,
                    "retained_cash_usdt": retained,
                }
                state.update({
                    "harvest_stage": signal.stage,
                    "harvest_reference_quantity": reference,
                    "last_harvest_price": float(action["execution_price"]),
                })
                self._recycling_metrics["harvests"] += 1
                self._recycling_metrics["harvest_proceeds_usdt"] += proceeds
                self._recycling_metrics["harvest_realized_pnl_usdt"] += float(action.get("realized_pnl") or 0)
                self._recycling_metrics["rebuy_pool_usdt"] += rebuy
                self._recycling_metrics["opportunity_pool_usdt"] += opportunity
                self._recycling_metrics["retained_cash_usdt"] += retained
                rebuy_by_symbol = self._recycling_pools["rebuy_by_symbol"]
                rebuy_by_symbol[symbol] = float(rebuy_by_symbol.get(symbol, 0.0)) + rebuy
                self._recycling_pools["opportunity_usdt"] += opportunity
                self._recycling_pools["retained_usdt"] += retained
                if self._production_quantity(portfolio, symbol) <= 1e-12:
                    self.execution_guard.reset(
                        symbol, "FULL_CAPITAL_RECYCLING_CLOSE"
                    )
            return action, reason
        if signal.action == "ACCUMULATE_ON_WEAKNESS":
            self._recycling_metrics["weakness_signals"] += 1
            self._recycling_metrics["weakness_drawdown_total_percent"] += float(
                signal.drawdown_from_peak_percent or 0
            )
            if str(analysis.get("decision")) in BUY_DECISIONS:
                return None, "BASE_BUY_HAS_PRIORITY"
            total = portfolio.value(marks)
            desired = total * signal.buy_percent_of_portfolio / 100
            capacity = (analysis.get("risk") or {}).get("remaining_capacity_before_context_usdt")
            if capacity is not None:
                desired = min(desired, max(0.0, float(capacity)))
            reserve = total * signal.reserve_target_percent / 100
            spendable = max(0.0, portfolio.cash - reserve)
            amount = min(desired, spendable)
            if amount < 5:
                self._recycling_metrics["reserve_blocked_buys"] += 1
                return None, "DYNAMIC_CASH_RESERVE_BLOCKS_WEAKNESS_BUY"
            action, reason = self._buy_notional(
                portfolio, symbol, raw_price, amount,
                "ACCUMULATE_ON_WEAKNESS", execution_time,
                strategy_layer="CAPITAL_RECYCLING", guard_analysis=analysis,
            )
            if action:
                amount_used = float(action.get("notional") or 0)
                rebuy_by_symbol = self._recycling_pools["rebuy_by_symbol"]
                rebuy_available = max(0.0, float(rebuy_by_symbol.get(symbol, 0.0)))
                use_rebuy = min(amount_used, rebuy_available)
                remaining = amount_used - use_rebuy
                opportunity_available = max(
                    0.0, float(self._recycling_pools["opportunity_usdt"])
                )
                use_opportunity = min(remaining, opportunity_available)
                fresh_cash = max(0.0, remaining - use_opportunity)
                rebuy_by_symbol[symbol] = rebuy_available - use_rebuy
                self._recycling_pools["opportunity_usdt"] = (
                    opportunity_available - use_opportunity
                )
                action["pool_usage"] = {
                    "same_asset_rebuy_pool_used_usdt": use_rebuy,
                    "general_opportunity_pool_used_usdt": use_opportunity,
                    "portfolio_cash_used_usdt": fresh_cash,
                }
                action["recycling_signal"] = signal.to_dict()
                state.update({
                    "weakness_stage": signal.stage,
                    "last_weakness_buy_price": float(action["execution_price"]),
                    "harvest_stage": 0,
                    "harvest_reference_quantity": 0.0,
                })
                self._recycling_metrics["weakness_buys"] += 1
                self._recycling_metrics["weakness_added_usdt"] += amount_used
                self._recycling_metrics["reinvested_from_rebuy_pool_usdt"] += use_rebuy
                self._recycling_metrics["reinvested_from_opportunity_pool_usdt"] += use_opportunity
                self._recycling_metrics["portfolio_cash_used_usdt"] += fresh_cash
                if use_opportunity > 0:
                    self._recycling_metrics["opportunity_allocations"] += 1
            return action, reason
        return None, "NONE"

    def _open_event_trade(
        self,
        portfolio: ReplayPortfolio,
        analysis: dict,
        raw_price: float,
        marks: dict[str, float],
        execution_time: datetime,
        *,
        confirmed: bool = False,
    ) -> tuple[dict | None, str]:
        if not self._event_enabled:
            return None, "DISABLED"
        event = analysis.get("event_momentum") or {}
        symbol = str(analysis["symbol"])
        if not confirmed and (
            event.get("status") != "NEWS_EVENT_BUY_CANDIDATE"
            or not event.get("paper_execution_allowed")
        ):
            return None, "NOT_EVENT_CANDIDATE"
        if str(analysis.get("decision")) in SELL_DECISIONS | {"AVOID"}:
            return None, "EVENT_CONFLICTS_WITH_PRODUCTION_RISK"
        if str(analysis.get("decision")) in BUY_DECISIONS:
            return None, "EVENT_OVERLAPS_PRODUCTION_BUY"
        if any(item.get("symbol") == symbol and item.get("status") in {"OPEN", "PARTIAL"} for item in self._event_trades):
            return None, "EVENT_TRADE_ALREADY_OPEN"
        total = portfolio.value(marks)
        pool_cap = self.config.capital * EVENT_CAPITAL_POOL_PERCENT / 100
        pool_used = sum(
            float(item.get("remaining_quantity") or 0) * raw_price
            for item in self._event_trades if item.get("status") in {"OPEN", "PARTIAL"}
        )
        requested_percent = min(float(event.get("starter_percent") or 0), EVENT_MAX_SINGLE_TRADE_PERCENT)
        desired = self.config.capital * requested_percent / 100
        capacity = (analysis.get("risk") or {}).get("remaining_capacity_before_context_usdt")
        if capacity is not None:
            desired = min(desired, max(0.0, float(capacity)))
        hard_floor = total * HARD_CASH_RESERVE_PERCENT / 100
        amount = min(desired, max(0.0, pool_cap - pool_used), max(0.0, portfolio.cash - hard_floor))
        action, reason = self._buy_notional(
            portfolio, symbol, raw_price, amount, "NEWS_EVENT_BUY",
            execution_time, strategy_layer="NEWS_EVENT",
        )
        if action:
            action["news_event_ids"] = [
                str(item.get("content_hash") or item.get("url") or item.get("title") or "")
                for item in event.get("verified_news") or []
            ]
            action["event_type"] = event.get("event_type") or "VERIFIED_NEWS_EVENT"
            action["overbought_entry"] = bool(event.get("overbought_exception"))
            action["entry_scale"] = float(event.get("entry_scale") or 1.0)
            self._event_trades.append({
                "symbol": symbol, "status": "OPEN",
                "entry_time": execution_time, "entry_price": float(action["execution_price"]),
                "initial_quantity": float(action["quantity"]),
                "remaining_quantity": float(action["quantity"]),
                "entry_cost": float(action["notional"]),
                "plan": event.get("trade_plan") or {},
                "news": event.get("verified_news") or [],
                "realized_pnl_usdt": 0.0,
                "event_type": event.get("event_type") or "VERIFIED_NEWS_EVENT",
                "overbought_entry": bool(event.get("overbought_exception")),
                "tranche_count": 1,
            })
        return action, reason

    def _add_event_tranche(
        self,
        portfolio: ReplayPortfolio,
        analysis: dict,
        raw_price: float,
        marks: dict[str, float],
        execution_time: datetime,
    ) -> tuple[dict | None, str]:
        symbol = str(analysis["symbol"])
        trade = next(
            (item for item in self._event_trades if item.get("symbol") == symbol and item.get("status") in {"OPEN", "PARTIAL"}),
            None,
        )
        if trade is None:
            return None, "EVENT_TRADE_NOT_OPEN"
        if int(trade.get("tranche_count") or 1) > EVENT_MAX_ADDITIONAL_TRANCHES:
            return None, "EVENT_TRANCHE_LIMIT"
        event = analysis.get("event_momentum") or {}
        total = portfolio.value(marks)
        pool_cap = self.config.capital * EVENT_CAPITAL_POOL_PERCENT / 100
        pool_used = sum(
            float(item.get("remaining_quantity") or 0) * float(marks.get(item["symbol"], raw_price))
            for item in self._event_trades if item.get("status") in {"OPEN", "PARTIAL"}
        )
        desired = self.config.capital * min(
            float(event.get("starter_percent") or 0), EVENT_MAX_SINGLE_TRADE_PERCENT
        ) / 100
        hard_floor = total * HARD_CASH_RESERVE_PERCENT / 100
        amount = min(desired, max(0.0, pool_cap - pool_used), max(0.0, portfolio.cash - hard_floor))
        action, reason = self._buy_notional(
            portfolio, symbol, raw_price, amount, "NEWS_EVENT_ADD_TRANCHE",
            execution_time, strategy_layer="NEWS_EVENT",
        )
        if action:
            old_qty = float(trade["initial_quantity"])
            add_qty = float(action["quantity"])
            new_qty = old_qty + add_qty
            trade["entry_price"] = (
                float(trade["entry_price"]) * old_qty + float(action["execution_price"]) * add_qty
            ) / new_qty
            trade["initial_quantity"] = new_qty
            trade["remaining_quantity"] = float(trade["remaining_quantity"]) + add_qty
            trade["entry_cost"] = float(trade["entry_cost"]) + float(action["notional"])
            trade["tranche_count"] = int(trade.get("tranche_count") or 1) + 1
            action["event_type"] = event.get("event_type") or "MARKET_MOMENTUM_EVENT"
            action["overbought_entry"] = bool(event.get("overbought_exception"))
            action["entry_scale"] = float(event.get("entry_scale") or 1.0)
        return action, reason

    def _replay_event_watch(
        self,
        portfolio: ReplayPortfolio,
        analysis: dict,
        marks: dict[str, float],
        execution_time: datetime,
    ) -> tuple[list[dict], list[dict]]:
        """Run a bounded 1m watch with a strict per-candle cutoff."""
        event = analysis.get("event_momentum") or {}
        if event.get("status") not in {"EVENT_OVERBOUGHT_REVIEW", "EVENT_CONFIRMATION_REQUIRED"}:
            return [], []
        plan = event.get("trade_plan") or {}
        start_ms = int(execution_time.timestamp() * 1000)
        end_time = execution_time + timedelta(
            minutes=max(
                EVENT_WATCH_DURATION_MINUTES,
                int(self.event_watch_engine.config.max_duration_minutes),
            )
        )
        end_ms = int(end_time.timestamp() * 1000) - 1
        history_start = start_ms - 20 * 60_000
        candles = self.engine.market_data.get_historical_klines(
            analysis["symbol"], "1m", history_start, end_ms, page_size=1000
        )
        state = self.event_watch_engine.discover(
            symbol=analysis["symbol"], event_type=event.get("event_type") or "MARKET_MOMENTUM_EVENT",
            discovered_at_ms=start_ms,
            breakout_price=float(plan.get("breakout_price") or (event.get("metrics") or {}).get("prior_24h_high") or analysis.get("current_price") or 0),
            reference_price=float(plan.get("reference_price") or analysis.get("current_price") or 0),
            atr_price=float(plan.get("atr_price") or max(float(analysis.get("current_price") or 0) * 0.02, 1e-12)),
            overbought=bool(event.get("overbought_exception")),
            entry_scale=float(event.get("entry_scale") or 1.0),
        )
        state = type(state)(**{**state.to_dict(), "last_evaluated_close_ms": start_ms - 1})
        observations: list[dict] = []
        actions: list[dict] = []
        candidate_closes = sorted({
            int(row.get("close_time") or 0) for row in candles
            if start_ms <= int(row.get("close_time") or 0) <= end_ms
        })
        for close_ms in candidate_closes:
            outcome = self.event_watch_engine.evaluate(state, candles, as_of_ms=close_ms)
            state = outcome.state
            row = {
                "symbol": analysis["symbol"], "timestamp": datetime.fromtimestamp(close_ms / 1000, tz=timezone.utc).isoformat(),
                "event_type": state.event_type, "state": state.state,
                "action": outcome.action, "reason": outcome.reason,
                "confirmations": state.confirmations, **outcome.metrics,
                "entry_path": state.entry_path,
                "anchor_reset_count": state.anchor_reset_count,
                "base_confirmed_at_ms": state.base_confirmed_at_ms or None,
            }
            observations.append(row)
            if outcome.action in {"ENTER", "ADD_TRANCHE"}:
                price = float(outcome.metrics.get("price") or 0)
                marks[analysis["symbol"]] = price
                event_time = datetime.fromtimestamp(close_ms / 1000, tz=timezone.utc)
                if outcome.action == "ENTER":
                    action, reason = self._open_event_trade(
                        portfolio, analysis, price, marks, event_time, confirmed=True
                    )
                else:
                    action, reason = self._add_event_tranche(
                        portfolio, analysis, price, marks, event_time
                    )
                if action:
                    action.update({
                        "decision_time": execution_time.isoformat(),
                        "execution_time": event_time.isoformat(),
                        "reason": (
                            "Осторожная покупка после нескольких минутных подтверждений "
                            "событийного импульса."
                        ),
                        "watch_reason": outcome.reason,
                        "minute_confirmations": state.confirmations,
                        "entry_path": state.entry_path,
                        "original_breakout_price": state.original_breakout_price,
                        "dynamic_reference_price": state.breakout_price,
                        "anchor_reset_count": state.anchor_reset_count,
                        "base_low": state.base_low or None,
                        "base_high": state.base_high or None,
                        "base_quality": state.base_quality,
                    })
                    actions.append(action)
                else:
                    row["execution_rejection"] = reason
                    break
            elif outcome.action == "INVALIDATE":
                price = float(outcome.metrics.get("price") or 0)
                event_time = datetime.fromtimestamp(close_ms / 1000, tz=timezone.utc)
                for trade in self._event_trades:
                    if trade.get("symbol") != analysis["symbol"] or trade.get("status") not in {"OPEN", "PARTIAL"}:
                        continue
                    action, _ = self._sell_quantity(
                        portfolio, analysis["symbol"], price,
                        float(trade.get("remaining_quantity") or 0),
                        "EVENT_INVALIDATED", event_time, strategy_layer="NEWS_EVENT",
                    )
                    if action:
                        event_basis = float(trade.get("entry_cost") or 0)
                        action["event_exit"] = "EVENT_INVALIDATED"
                        action["realized_pnl"] = float(action["proceeds"]) - event_basis
                        action["decision_time"] = execution_time.isoformat()
                        action["execution_time"] = event_time.isoformat()
                        action["reason"] = "Событийный импульс отменён: пробой не удержан."
                        actions.append(action)
                        trade["remaining_quantity"] = 0.0
                        trade["status"] = "CLOSED"
                    break
            if state.state in {"CANCELLED", "EXPIRED", "CLOSED"}:
                break
        self._event_watch_rows.extend(observations)
        return actions, observations

    def _event_exit_actions(
        self,
        portfolio: ReplayPortfolio,
        prices: dict[str, float],
        execution_time: datetime,
    ) -> list[dict]:
        actions: list[dict] = []
        for trade in self._event_trades:
            if trade.get("status") not in {"OPEN", "PARTIAL"}:
                continue
            symbol = str(trade["symbol"])
            if symbol not in prices:
                continue
            price = float(prices[symbol])
            plan = trade.get("plan") or {}
            label = None
            quantity = 0.0
            stop = float(plan.get("stop_price") or 0)
            if stop > 0 and price <= stop:
                label = "EVENT_STOP"
                quantity = float(trade["remaining_quantity"])
            else:
                hit = set(trade.get("hit_targets") or [])
                for target in plan.get("targets") or []:
                    name = str(target.get("name") or "TP")
                    if name not in hit and price >= float(target.get("price") or 0) > 0:
                        label = name
                        quantity = min(
                            float(trade["remaining_quantity"]),
                            float(trade["initial_quantity"]) * float(target.get("sell_percent") or 0) / 100,
                        )
                        hit.add(name)
                        trade["hit_targets"] = sorted(hit)
                        break
                hours = (execution_time - trade["entry_time"]).total_seconds() / 3600
                if not label and hours >= float(plan.get("time_exit_hours") or 72):
                    label = "EVENT_TIME_EXIT"
                    quantity = float(trade["remaining_quantity"])
            if not label or quantity <= 0:
                continue
            action, _ = self._sell_quantity(
                portfolio, symbol, price, quantity, label, execution_time,
                strategy_layer="NEWS_EVENT",
            )
            if action:
                sold_fraction = quantity / max(float(trade["initial_quantity"]), 1e-12)
                event_basis = float(trade["entry_cost"]) * sold_fraction
                event_pnl = float(action["proceeds"]) - event_basis
                action["event_exit"] = label
                action["realized_pnl"] = event_pnl
                trade["realized_pnl_usdt"] += event_pnl
                trade["remaining_quantity"] = max(0.0, float(trade["remaining_quantity"]) - quantity)
                trade["status"] = "CLOSED" if trade["remaining_quantity"] <= 1e-12 else "PARTIAL"
                actions.append(action)
        return actions

    def _benchmark_open(self, symbol: str, when: datetime) -> float:
        # Use the same execution candle convention as the strategy, including
        # weekly Monday alignment.
        return self._execution_open(symbol, when)

    def _benchmarks(self, times: list[datetime]) -> dict:
        symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
        if not times:
            return {}
        first, last = times[0], times[-1]
        results: dict[str, dict] = {}
        prices: dict[str, tuple[float, float]] = {}
        for symbol in symbols:
            try:
                prices[symbol] = (self._benchmark_open(symbol, first), self._benchmark_open(symbol, last))
            except Exception as exc:
                results[symbol.replace("USDT", "") + "_BUY_HOLD"] = {"status":"UNAVAILABLE","reason":str(exc)}
        slip = self.config.slippage_bps / 10_000
        for symbol, pair in prices.items():
            start_px, end_px = pair
            buy_px = start_px * (1 + slip)
            fee = self.config.capital * self.config.fee_rate
            qty = (self.config.capital - fee) / buy_px
            final = qty * end_px
            results[symbol.replace("USDT", "") + "_BUY_HOLD"] = {
                "status":"AVAILABLE", "final_equity":round(final,8),
                "return_pct":round((final/self.config.capital-1)*100,6)
            }
        if len(prices) == 3:
            final = 0.0
            per = self.config.capital / 3
            for symbol in symbols:
                start_px, end_px = prices[symbol]
                fee = per * self.config.fee_rate
                qty = (per - fee) / (start_px * (1 + slip))
                final += qty * end_px
            results["BTC_ETH_SOL_EQUAL_WEIGHT"] = {"status":"AVAILABLE","final_equity":round(final,8),"return_pct":round((final/self.config.capital-1)*100,6)}

            # DCA: deploy equal slices of the original capital at each replay step,
            # equally across BTC/ETH/SOL, using the same fee/slippage assumptions.
            quantities = {s:0.0 for s in symbols}
            cash = self.config.capital
            step_budget = self.config.capital / len(times)
            for when in times:
                budget = min(step_budget, cash)
                if budget <= 0:
                    break
                per_asset = budget / 3
                for symbol in symbols:
                    try:
                        px = self._benchmark_open(symbol, when)
                    except Exception:
                        continue
                    fee = per_asset * self.config.fee_rate
                    quantities[symbol] += (per_asset - fee) / (px * (1 + slip))
                    cash -= per_asset
            final = cash + sum(quantities[s] * prices[s][1] for s in symbols)
            results["BTC_ETH_SOL_DCA"] = {"status":"AVAILABLE","final_equity":round(final,8),"return_pct":round((final/self.config.capital-1)*100,6)}
        return results

    @staticmethod
    def _drawdown_details(equity: list[dict]) -> dict:
        peak_value = 0.0
        peak_time = None
        worst = {"percent": 0.0, "usdt": 0.0, "peak_timestamp": None, "trough_timestamp": None}
        for row in equity:
            value = float(row.get("equity") or 0)
            if value >= peak_value:
                peak_value = value
                peak_time = row.get("timestamp")
            decline = peak_value - value
            percent = decline / peak_value * 100 if peak_value else 0.0
            if percent > worst["percent"]:
                worst = {
                    "percent": percent, "usdt": decline,
                    "peak_timestamp": peak_time,
                    "trough_timestamp": row.get("timestamp"),
                }
        if worst["peak_timestamp"] and worst["trough_timestamp"]:
            start = datetime.fromisoformat(str(worst["peak_timestamp"]).replace("Z", "+00:00"))
            end = datetime.fromisoformat(str(worst["trough_timestamp"]).replace("Z", "+00:00"))
            worst["duration_hours"] = round(max(0.0, (end-start).total_seconds()/3600), 2)
        else:
            worst["duration_hours"] = 0.0
        return worst

    def _asset_results(self, portfolio: ReplayPortfolio, marks: dict[str, float], trades: list[dict]) -> list[dict]:
        output = []
        symbols = sorted({str(row.get("symbol") or "") for row in trades} | set(portfolio.positions))
        max_values: dict[str, float] = {}
        for row in trades:
            total = float(row.get("portfolio_value_after") or 0)
            if total <= 0:
                continue
            symbol = str(row.get("symbol") or "")
            share = float(row.get("position_value_after") or 0) / total * 100
            max_values[symbol] = max(max_values.get(symbol, 0.0), share)
        for symbol in symbols:
            rows = [row for row in trades if row.get("symbol") == symbol]
            buys = [row for row in rows if row.get("side") == "BUY"]
            sells = [row for row in rows if row.get("side") == "SELL"]
            position = portfolio.get(symbol)
            mark_raw = marks.get(symbol)
            mark = float(mark_raw) if mark_raw is not None else None
            realized = sum(float(row.get("realized_pnl") or 0) for row in sells)
            unrealized = (
                position.quantity * mark - position.cost_basis
                if mark is not None else None
            )
            invested = sum(float(row.get("notional") or 0) for row in buys)
            sell_turnover = sum(
                float(row.get("proceeds") or 0) + float(row.get("fee") or 0)
                for row in sells
            )
            turnover = invested + sell_turnover
            fees = sum(float(row.get("fee") or 0) for row in rows)
            slippage = sum(
                abs(float(row.get("execution_price") or 0) - float(row.get("market_price") or 0))
                * float(row.get("quantity") or 0)
                for row in rows
            )
            bought_quantity = sum(float(row.get("quantity") or 0) for row in buys)
            average_purchase_price = (
                sum(
                    float(row.get("quantity") or 0)
                    * float(row.get("execution_price") or 0)
                    for row in buys
                ) / bought_quantity
                if bought_quantity > 0 else 0.0
            )
            event_result = sum(float(row.get("realized_pnl") or 0) for row in sells if row.get("strategy_layer") == "NEWS_EVENT")
            baseline_result = (
                realized - event_result + unrealized
                if unrealized is not None else None
            )
            total_pnl = realized + unrealized if unrealized is not None else None
            ending_market_value = position.quantity * mark if mark is not None else None
            output.append({
                "symbol": symbol,
                "invested_usdt_total": round(invested, 8),
                "buys": len(buys), "sells": len(sells),
                "average_purchase_price": round(average_purchase_price, 8),
                "remaining_average_entry": round(position.average_price, 8),
                # Backward-compatible field used by earlier report readers.
                "average_entry": round(position.average_price, 8),
                "remaining_quantity": round(position.quantity, 12),
                "end_mark_price": round(mark, 8) if mark is not None else None,
                "ending_mark_status": "AVAILABLE" if mark is not None else "UNAVAILABLE",
                "turnover_usdt": round(turnover, 8),
                "fees_usdt": round(fees, 8),
                "slippage_usdt": round(slippage, 8),
                "ending_market_value_usdt": round(ending_market_value, 8)
                if ending_market_value is not None else None,
                "realized_pnl_usdt": round(realized, 8),
                "unrealized_pnl_usdt": round(unrealized, 8)
                if unrealized is not None else None,
                "total_pnl_usdt": round(total_pnl, 8)
                if total_pnl is not None else None,
                "contribution_usdt": round(total_pnl, 8)
                if total_pnl is not None else None,
                "event_result_usdt": round(event_result, 8),
                "normal_strategy_result_usdt": round(baseline_result, 8)
                if baseline_result is not None else None,
                "max_portfolio_share_percent": max_values.get(symbol),
            })
        return output

    def _news_snapshot(self, store: PointInTimeStore | None) -> dict:
        events = [event for event in (store.events if store else []) if event.get("kind") == "news"]
        start = date.fromisoformat(self.config.start)
        end = date.fromisoformat(self.config.end)
        in_range = []
        covered_days = set()
        sources = set()
        manifest = []
        for event in events:
            observed = PointInTimeStore._dt(event["observed_at"])
            if not (start <= observed.date() <= end):
                continue
            in_range.append(event)
            covered_days.add(observed.date().isoformat())
            payload = event.get("payload") or {}
            items = payload.get("items") or [payload]
            for item in items:
                source = str(item.get("source") or payload.get("source") or "unknown")
                sources.add(source)
                title = str(item.get("title") or "")
                url = item.get("url")
                published = item.get("published_at")
                manifest.append({
                    "symbol": event.get("symbol"), "source": source,
                    "published_at": published, "observed_at": event.get("observed_at"),
                    "url": url,
                    "headline_hash": hashlib.sha256(title.encode("utf-8")).hexdigest(),
                })
        total_days = (end-start).days + 1
        return {
            "snapshot_id": _sha256_json(manifest),
            "period_days": total_days,
            "covered_days": len(covered_days),
            "coverage_percent": round(len(covered_days)/total_days*100, 6) if total_days else 0.0,
            "news_events": len(in_range),
            "articles": len(manifest),
            "sources": sorted(sources),
            "manifest": manifest,
            "sufficient": bool(manifest),
        }

    def _market_data_provenance(self) -> dict:
        """Fingerprint every candle dataset actually loaded by this replay."""
        memory = getattr(self._replay_cache, "_memory", {}) if self._replay_cache else {}
        manifest = []
        interval_counts: Counter = Counter()
        interval_candles: Counter = Counter()
        for key in sorted(memory):
            symbol, interval = key
            rows = memory[key]
            # Disk caches may contain a superset downloaded by an earlier,
            # longer replay.  Fingerprint only the deterministic requested
            # window so identical A/B/C inputs keep the same dataset hash.
            if self._replay_cache is not None:
                wanted_start, wanted_end = self._replay_cache._range_for(interval)
                rows = [
                    row for row in rows
                    if int(row.get("open_time", 0)) >= wanted_start
                    and int(row.get("close_time", 0)) <= wanted_end
                ]
            digest = hashlib.sha256()
            for row in rows:
                digest.update(_canonical_json(row).encode("utf-8"))
                digest.update(b"\n")
            first_open = int(rows[0].get("open_time", 0)) if rows else None
            last_close = int(rows[-1].get("close_time", 0)) if rows else None
            item = {
                "symbol": symbol,
                "interval": interval,
                "candles": len(rows),
                "first_open_ms": first_open,
                "last_close_ms": last_close,
                "sha256": digest.hexdigest(),
            }
            manifest.append(item)
            interval_counts[interval] += 1
            interval_candles[interval] += len(rows)
        return {
            "datasets": len(manifest),
            "candles": sum(item["candles"] for item in manifest),
            "datasets_by_interval": dict(sorted(interval_counts.items())),
            "candles_by_interval": dict(sorted(interval_candles.items())),
            "manifest_sha256": _sha256_json(manifest),
        }

    def _market_data_quality(self) -> dict:
        """Audit the exact requested replay period, including trailing gaps."""
        memory = getattr(self._replay_cache, "_memory", {}) if self._replay_cache else {}
        datasets: list[dict] = []
        period_start = datetime.combine(
            date.fromisoformat(self.config.start), time.min, tzinfo=timezone.utc
        )
        period_end = datetime.combine(
            date.fromisoformat(self.config.end), time.max, tzinfo=timezone.utc
        )
        period_start_ms = int(period_start.timestamp() * 1000)
        period_end_ms = int(period_end.timestamp() * 1000)
        for key in sorted(memory):
            symbol, interval = key
            rows = [
                row for row in memory[key]
                if int(row.get("open_time", 0)) >= period_start_ms
                and int(row.get("close_time", 0)) <= period_end_ms
            ]
            result = audit_candles(
                rows, interval, cutoff_ms=period_end_ms,
                minimum_count=1,
            )
            coverage = self._replay_cache.coverage(
                symbol, interval, start_ms=period_start_ms, end_ms=period_end_ms
            ) if self._replay_cache is not None else {
                "status": "UNAVAILABLE", "coverage_percent": 0.0,
                "gaps": 0, "trailing_stale": True,
            }
            status = (
                "READY"
                if result["status"] == "READY" and coverage["status"] == "AVAILABLE"
                else "WARNING"
            )
            datasets.append({
                "symbol": symbol, **result, "status": status,
                "requested_period_coverage": coverage,
            })
        totals = {
            "datasets": len(datasets),
            "ready": sum(row["status"] == "READY" for row in datasets),
            "warnings": sum(row["status"] != "READY" for row in datasets),
            "candles": sum(int(row["candles"]) for row in datasets),
            "duplicates": sum(int(row["duplicates"]) for row in datasets),
            "missing_candles": sum(int(row["missing_candles"]) for row in datasets),
            "incomplete_candles": sum(int(row["incomplete_candles"]) for row in datasets),
            "malformed_candles": sum(int(row["malformed_candles"]) for row in datasets),
            "invalid_ohlc": sum(int(row["invalid_ohlc"]) for row in datasets),
            "non_monotonic_datasets": sum(not row["timestamps_monotonic"] for row in datasets),
            "insufficient_history_datasets": sum(not row["sufficient_history"] for row in datasets),
        }
        totals["status"] = "READY" if not totals["warnings"] else "WARNING"
        coverage_states = [
            row["requested_period_coverage"]["status"] for row in datasets
        ]
        totals["coverage_status"] = (
            "UNAVAILABLE" if datasets and all(value == "UNAVAILABLE" for value in coverage_states)
            else "AVAILABLE" if datasets and all(value == "AVAILABLE" for value in coverage_states)
            else "PARTIAL"
        )
        totals["coverage_percent_min"] = min(
            (
                float(row["requested_period_coverage"]["coverage_percent"])
                for row in datasets
            ),
            default=0.0,
        )
        return {"summary": totals, "datasets": datasets}

    def _input_provenance(self, configured_store=None) -> dict:
        store = self.engine.point_in_time_store
        events = list(store.events) if store else []
        configured_store = configured_store if configured_store is not None else store
        configured_events = list(configured_store.events) if configured_store else []
        kinds = Counter(str(event.get("kind") or "UNKNOWN") for event in events)
        observed = sorted(str(event.get("observed_at")) for event in events)
        universe_symbols = list(
            self.fixed_symbols
            if self.config.universe_mode == "fixed"
            else self._daily_pool
        )
        stable_config = {
            key: value
            for key, value in asdict(self.config).items()
            if key not in _RUNTIME_ONLY_CONFIG_FIELDS
        }
        market_data = self._market_data_provenance()
        fingerprint_material = {
            "schema": FINGERPRINT_SCHEMA,
            "app_version": APP_VERSION,
            "config": stable_config,
            "universe_mode": self.config.universe_mode,
            "universe_symbols": universe_symbols,
            "point_in_time_events": events,
            "market_data_manifest_sha256": market_data["manifest_sha256"],
        }
        frozen_dataset_material = {
            "schema": "spot_frozen_historical_dataset_v1",
            "period": {"start": self.config.start, "end": self.config.end},
            "frequency": self.config.frequency,
            "universe_mode": self.config.universe_mode,
            "universe_symbols": universe_symbols,
            "configured_point_in_time_events": configured_events,
            "market_data_manifest_sha256": market_data["manifest_sha256"],
        }
        source_path = (
            getattr(configured_store, "source_path", None)
            if configured_store
            else None
        )
        return {
            "schema": FINGERPRINT_SCHEMA,
            "sha256": _sha256_json(fingerprint_material),
            "frozen_dataset_fingerprint": _sha256_json(frozen_dataset_material),
            "config_sha256": _sha256_json(stable_config),
            "universe": {
                "mode": self.config.universe_mode,
                "frozen": self.config.universe_mode == "fixed",
                "source": (
                    "fixed_symbols_argument"
                    if self.config.universe_mode == "fixed"
                    else "current_exchange_info_snapshot"
                ),
                "symbol_count": len(universe_symbols),
                "symbols_sha256": _sha256_json(universe_symbols),
                "symbols": universe_symbols
                if self.config.universe_mode == "fixed"
                else [],
            },
            "point_in_time": {
                "source": str(source_path) if source_path else "in_memory_store",
                "configured_event_count": len(configured_events),
                "configured_events_sha256": _sha256_json(configured_events),
                "applied_event_count": len(events),
                "events_by_kind": dict(sorted(kinds.items())),
                "first_observed_at": observed[0] if observed else None,
                "last_observed_at": observed[-1] if observed else None,
                "applied_events_sha256": _sha256_json(events),
            },
            "market_data": market_data,
        }

    @staticmethod
    def _analytical_output_hash(
        summary: dict,
        decisions: list,
        trades: list,
        universe: list,
        rejected: list,
        quality: list,
        errors: list,
        audit: list,
        equity: list,
    ) -> str:
        stable_summary = {
            key: value
            for key, value in summary.items()
            if key not in _VOLATILE_SUMMARY_FIELDS
        }
        return _sha256_json(
            {
                "schema": FINGERPRINT_SCHEMA,
                "summary": stable_summary,
                "decisions": decisions,
                "trades": trades,
                "universe": universe,
                "rejected": rejected,
                "quality": quality,
                "errors": errors,
                "audit": audit,
                "equity": equity,
            }
        )

    def run(self, output_root: str | Path = "output", run_id: str | None = None) -> tuple[dict, Path]:
        times = self._times()
        original_store = self.engine.point_in_time_store
        context_preflight = build_context_preflight(
            mode=self.config.mode,
            start=self.config.start,
            end=self.config.end,
            store=original_store,
            allow_fallback=self.config.allow_context_fallback,
        )
        require_context_preflight(context_preflight)
        run_id = run_id or datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        run_dir = Path(output_root) / f"replay_{self.config.start}_{self.config.end}_{self.config.frequency}_{self.config.mode}_{run_id}"
        run_dir.mkdir(parents=True, exist_ok=False)
        self.progress = self._progress_state(
            len(times), running=True, stage="PREPARING"
        )
        started = time_module.time()
        original_market_data = self.engine.market_data
        self._prepare_cache(times)
        if self.cancel_event.is_set():
            self.progress["stage"] = "STOPPED"
        portfolio = ReplayPortfolio.create(self.config.capital)
        decisions=[]; trades=[]; universe_log=[]; rejected=[]; quality=[]; errors=[]; audit=[]; equity=[]
        last_valid_marks: dict[str, float] = {}
        peak = self.config.capital; max_dd = 0.0; lookahead=0
        self.engine.point_in_time_store = self._filter_store(
            original_store, mode=context_preflight.effective_mode
        )
        try:
            for idx, execution_time in enumerate(times, 1):
                if not self._control_checkpoint(current=execution_time.isoformat()):
                    self.progress["stage"] = "STOPPED"
                    break
                cutoff = execution_time - timedelta(milliseconds=1); cutoff_ms=int(cutoff.timestamp()*1000)
                self.progress.update({"processed":idx-1,"current":execution_time.isoformat(),"stage":"UNIVERSE","symbol":""})
                symbols, universe_rows = self._universe(cutoff_ms)
                self.progress.update({
                    "symbols_done_current_cycle": 0,
                    "symbols_total_current_cycle": len(symbols),
                })
                self._refresh_progress()
                if not self._control_checkpoint(current=execution_time.isoformat()):
                    self.progress["stage"] = "STOPPED"
                    break
                for row in universe_rows:
                    universe_log.append({"timestamp":execution_time.isoformat(), **row, "selected": row["symbol"] in symbols})
                analyses=[]; marks={}; step_errors=[]
                # Mark every open position before sizing the next cycle. This is
                # the compounding anchor: risk limits and allocations use the
                # current historical portfolio value, never the original ENV
                # capital or a forward-filled future price.
                for open_position in portfolio.open_positions():
                    try:
                        marks[open_position.symbol] = self.engine.market_data.get_price_at(
                            open_position.symbol, cutoff_ms, interval="1h"
                        )
                    except Exception as exc:
                        step_errors.append({
                            "timestamp": execution_time.isoformat(),
                            "symbol": open_position.symbol,
                            "type": "OPEN_POSITION_MARK_UNAVAILABLE",
                            "error": str(exc),
                        })
                missing_open_marks = [
                    position.symbol for position in portfolio.open_positions()
                    if position.symbol not in marks
                ]
                if missing_open_marks:
                    errors.append({
                        "timestamp": execution_time.isoformat(),
                        "type": "INVALID_COVERAGE_OPEN_POSITION_UNPRICED",
                        "symbols": missing_open_marks,
                    })
                    quality.append({
                        "timestamp": execution_time.isoformat(),
                        "status": "INVALID_COVERAGE",
                        "unpriced_open_positions": "|".join(missing_open_marks),
                    })
                    self.progress["stage"] = "INVALID_COVERAGE"
                    break
                cycle_equity = portfolio.value(marks)
                if hasattr(self.engine, "risk_manager"):
                    self.engine.risk_manager.capital_usdt = max(0.0, cycle_equity)
                    self.engine.risk_manager.max_open_ideas = self.config.max_open_positions
                prior_peak = max(peak, cycle_equity)
                portfolio_dd = max(0.0, (1.0 - cycle_equity / prior_peak) * 100) if prior_peak else 0.0
                self.progress.update({"processed":idx-1,"current":execution_time.isoformat(),"stage":"ANALYZE","symbol":""})
                interrupted = False
                for symbol_index, symbol in enumerate(symbols, start=1):
                    if not self._control_checkpoint(current=execution_time.isoformat(), symbol=symbol):
                        interrupted = True
                        break
                    self.progress["stage"] = "ANALYZE"
                    age, age_status, age_cap = self._age_info(symbol, cutoff_ms)
                    try:
                        mark=self.engine.market_data.get_price_at(symbol, cutoff_ms, interval="1h")
                        marks[symbol]=mark
                        result=self.engine.analyze(
                            symbol,
                            position=portfolio.get(symbol).state(mark),
                            portfolio_positions=self._position_states(portfolio, marks),
                            portfolio_drawdown_percent=portfolio_dd,
                            as_of_ms=cutoff_ms,
                        ).to_dict()
                        self._assert_safe(result, cutoff)
                        result["_age_status"]=age_status; result["_age_cap"]=age_cap; analyses.append(result)
                        trace = build_decision_trace(
                            result,
                            position_exists=portfolio.get(symbol).quantity > 0,
                            policy=getattr(getattr(self.engine, "decision_engine", None), "policy", None),
                        )
                        reason_codes = [trace["primary_reason"], *trace["secondary_reasons"]]
                        decisions.append({"timestamp":execution_time.isoformat(),"symbol":symbol,"decision":result.get("decision"),"score":result.get("score"),"mode":self.config.mode,"frequency":self.config.frequency,"age_days":age,"age_status":age_status,"primary_reason":trace["primary_reason"],"secondary_reason_codes":"|".join(trace["secondary_reasons"]),"reason_codes":"|".join(reason_codes), **self._context_fields(result)})
                    except LookAheadError as exc:
                        lookahead+=1; item={"timestamp":execution_time.isoformat(),"symbol":symbol,"type":"LOOKAHEAD_BLOCKED","error":str(exc)}; errors.append(item); step_errors.append(item)
                        if self.config.strict_cutoff: raise
                    except Exception as exc:
                        item={"timestamp":execution_time.isoformat(),"symbol":symbol,"type":"UNAVAILABLE","error":f"{type(exc).__name__}: {exc}"}; errors.append(item); step_errors.append(item)
                    finally:
                        self.progress["symbols_done_current_cycle"] = symbol_index
                        self._refresh_progress()
                if interrupted or self.cancel_event.is_set():
                    self.progress["stage"] = "STOPPED"
                    break
                if not self._control_checkpoint(current=execution_time.isoformat()):
                    self.progress["stage"] = "STOPPED"
                    break
                self.progress.update({"stage":"EXECUTE","symbol":""})
                sells=[a for a in analyses if a.get("decision") in SELL_DECISIONS and self._production_quantity(portfolio, a["symbol"])>0]
                eligible_buys=sorted([a for a in analyses if a.get("decision") in BUY_DECISIONS and a.get("_age_status") not in {"WATCH_ONLY"}], key=lambda a:float(a.get("score") or 0), reverse=True)
                buys=eligible_buys[:self.config.candidate_limit]
                for a in analyses:
                    if a.get("decision") in BUY_DECISIONS and a.get("_age_status") == "WATCH_ONLY":
                        rejected.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":a.get("decision"),"reason":"WATCH_ONLY_AGE"})
                for a in eligible_buys[self.config.candidate_limit:]:
                    rejected.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":a.get("decision"),"reason":"CANDIDATE_LIMIT"})
                actions=[]
                pending_fills, pending_events = self._process_pending_buys(
                    portfolio, analyses, marks, execution_time
                )
                for event in pending_events:
                    audit.append({"timestamp": execution_time.isoformat(), **event})
                for action in pending_fills:
                    action.update({
                        "decision_time": cutoff.isoformat(),
                        "execution_time": execution_time.isoformat(),
                        "portfolio_value_after": portfolio.value(marks),
                        "position_value_after": (
                            portfolio.get(action["symbol"]).quantity
                            * float(action["execution_price"])
                        ),
                        "remaining_quantity": portfolio.get(action["symbol"]).quantity,
                        "reason": "Отложенная зона покупки повторно подтверждена.",
                    })
                    actions.append(action)
                    trades.append(action)
                # Existing event positions are a separate sleeve. Their exits
                # run before new entries, matching the live risk-first order.
                event_prices = {}
                for event_trade in self._event_trades:
                    if event_trade.get("status") not in {"OPEN", "PARTIAL"}:
                        continue
                    symbol = str(event_trade["symbol"])
                    try:
                        event_prices[symbol] = self._execution_open(symbol, execution_time)
                        marks[symbol] = event_prices[symbol]
                    except Exception as exc:
                        errors.append({"timestamp":execution_time.isoformat(),"symbol":symbol,"type":"EVENT_EXIT_PRICE_UNAVAILABLE","error":str(exc)})
                for event_action in self._event_exit_actions(portfolio, event_prices, execution_time):
                    event_action.update({
                        "decision_time":cutoff.isoformat(),"execution_time":execution_time.isoformat(),
                        "portfolio_value_after":portfolio.value(marks),
                        "position_value_after":portfolio.get(event_action["symbol"]).quantity * float(event_action["execution_price"]),
                        "remaining_quantity":portfolio.get(event_action["symbol"]).quantity,
                    })
                    actions.append(event_action); trades.append(event_action)
                owned_overlay = [
                    a for a in analyses
                    if self._production_quantity(portfolio, a["symbol"]) > 0
                    and a not in sells and a not in buys
                ]
                for a in sells+buys+owned_overlay:
                    if not self._control_checkpoint(current=execution_time.isoformat(), symbol=a.get("symbol", "")):
                        interrupted = True
                        break
                    self.progress["stage"] = "EXECUTE"
                    if len(actions)>=self.config.max_trades_per_step:
                        rejected.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":a.get("decision"),"reason":"STEP_TRADE_LIMIT"})
                        continue
                    allowed, reject_reason = self._execution_guard(portfolio, a, execution_time)
                    if not allowed:
                        rejected.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":a.get("decision"),"reason":reject_reason})
                        audit.append({"timestamp":execution_time.isoformat(),"event":"EXECUTION_REJECTED","symbol":a["symbol"],"decision":a.get("decision"),"reason":reject_reason})
                        continue
                    try:
                        px=self._execution_open(a["symbol"], execution_time); marks[a["symbol"]]=px
                        before_value = portfolio.value(marks)
                        recycling_action, recycling_reason = self._capital_recycling_action(
                            portfolio, a, px, marks, execution_time
                        )
                        if recycling_action is not None:
                            action, status_reason = recycling_action, recycling_reason
                        elif a["decision"] in SELL_DECISIONS:
                            action, status_reason = self._sell(
                                portfolio, a, px, execution_time
                            )
                        elif a["decision"] in BUY_DECISIONS:
                            action, status_reason = self._buy(portfolio,a,px,marks,float(a.get("_age_cap") or 0),execution_time)
                        else:
                            action, status_reason = None, "NO_TRADE"
                        if action:
                            action.update({
                                "decision_time":cutoff.isoformat(),
                                "execution_time":execution_time.isoformat(),
                                "portfolio_value_before":before_value,
                                "portfolio_value_after":portfolio.value(marks),
                                "position_value_after":portfolio.get(a["symbol"]).quantity * px,
                                "remaining_quantity":portfolio.get(a["symbol"]).quantity,
                                "reason": "; ".join(a.get("reasons") or [str(a.get("decision"))]),
                            }); actions.append(action); trades.append(action)
                        elif status_reason in {"PENDING_BUY_PLACED", "PENDING_BUY_EXISTS"}:
                            audit.append({
                                "timestamp":execution_time.isoformat(),
                                "event":status_reason,
                                "symbol":a["symbol"],
                                "decision":a.get("decision"),
                                "reserved_cash_usdt":self._reserved_cash(),
                            })
                        elif status_reason != "NO_TRADE":
                            rejected.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":a.get("decision"),"reason":status_reason})
                            audit.append({"timestamp":execution_time.isoformat(),"event":"EXECUTION_REJECTED","symbol":a["symbol"],"decision":a.get("decision"),"reason":status_reason})
                    except Exception as exc:
                        item={"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":a.get("decision"),"reason":"EXECUTION_UNAVAILABLE","detail":str(exc)}
                        rejected.append(item)
                        errors.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"type":"EXECUTION_UNAVAILABLE","error":str(exc)})
                # Event entries are independent. Legacy direct candidates remain
                # reproducible; v6.1 candidates must pass the bounded 1m watch.
                if self._event_enabled and len(actions) < self.config.max_trades_per_step:
                    event_candidates = [
                        row for row in analyses
                        if (row.get("event_momentum") or {}).get("status") == "NEWS_EVENT_BUY_CANDIDATE"
                        and (row.get("event_momentum") or {}).get("paper_execution_allowed")
                    ]
                    for a in sorted(event_candidates, key=lambda row: float((row.get("event_momentum") or {}).get("score") or 0), reverse=True):
                        if len(actions) >= self.config.max_trades_per_step:
                            break
                        try:
                            px = self._execution_open(a["symbol"], execution_time)
                            marks[a["symbol"]] = px
                            before_value = portfolio.value(marks)
                            action, reason = self._open_event_trade(portfolio, a, px, marks, execution_time)
                            if action:
                                action.update({
                                    "decision_time": cutoff.isoformat(),
                                    "execution_time": execution_time.isoformat(),
                                    "portfolio_value_before": before_value,
                                    "portfolio_value_after": portfolio.value(marks),
                                    "position_value_after": portfolio.get(a["symbol"]).quantity * px,
                                    "remaining_quantity": portfolio.get(a["symbol"]).quantity,
                                    "reason": "Покупка после подтверждённого новостного импульса.",
                                })
                                actions.append(action); trades.append(action)
                            elif reason not in {"NOT_EVENT_CANDIDATE", "DISABLED"}:
                                rejected.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"decision":"NEWS_EVENT_BUY","reason":reason})
                        except Exception as exc:
                            errors.append({"timestamp":execution_time.isoformat(),"symbol":a["symbol"],"type":"EVENT_EXECUTION_UNAVAILABLE","error":str(exc)})
                    watch_candidates = [
                        row for row in analyses
                        if (row.get("event_momentum") or {}).get("status")
                        in {"EVENT_OVERBOUGHT_REVIEW", "EVENT_CONFIRMATION_REQUIRED"}
                    ]
                    for a in sorted(
                        watch_candidates,
                        key=lambda row: float((row.get("event_momentum") or {}).get("score") or 0),
                        reverse=True,
                    ):
                        if len(actions) >= self.config.max_trades_per_step:
                            break
                        try:
                            watch_actions, watch_rows = self._replay_event_watch(
                                portfolio, a, marks, execution_time
                            )
                            for action in watch_actions:
                                action["portfolio_value_after"] = portfolio.value(marks)
                                action["position_value_after"] = (
                                    portfolio.get(a["symbol"]).quantity
                                    * float(marks.get(a["symbol"], action.get("execution_price") or 0))
                                )
                                action["remaining_quantity"] = portfolio.get(a["symbol"]).quantity
                                actions.append(action)
                                trades.append(action)
                            if not watch_actions and watch_rows:
                                final_watch = watch_rows[-1]
                                if final_watch.get("reason") not in {"EVENT_CONFIRMATION_PENDING"}:
                                    rejected.append({
                                        "timestamp": execution_time.isoformat(),
                                        "symbol": a["symbol"],
                                        "decision": "EVENT_WATCH",
                                        "reason": final_watch.get("reason"),
                                    })
                        except Exception as exc:
                            errors.append({
                                "timestamp": execution_time.isoformat(), "symbol": a["symbol"],
                                "type": "EVENT_WATCH_UNAVAILABLE", "error": str(exc),
                            })
                if interrupted or self.cancel_event.is_set():
                    self.progress["stage"] = "STOPPED"
                    break
                value=portfolio.value(marks); peak=max(peak,value); dd=(value/peak-1)*100 if peak else 0; max_dd=min(max_dd,dd)
                last_valid_marks = dict(marks)
                invested = portfolio.invested_value(marks)
                unrealized = portfolio.unrealized_pnl(marks)
                policies = [self._reserve_policy(a) for a in analyses]
                reserve_percent = max((p.target_percent for p in policies), default=self.config.min_cash_reserve_percent)
                minimum_reserve = value * reserve_percent / 100
                reserved_cash = self._reserved_cash()
                equity.append({
                    "timestamp":execution_time.isoformat(),"equity":value,
                    "cash":portfolio.cash,"reserved_cash":reserved_cash,
                    "free_cash":max(0.0, portfolio.cash-reserved_cash),
                    "invested":invested,
                    "realized_pnl":portfolio.realized_pnl,
                    "unrealized_pnl":unrealized,
                    "minimum_reserve":minimum_reserve,
                    "available_to_invest":max(
                        0.0, portfolio.cash-reserved_cash-minimum_reserve
                    ),
                    "reserve_percent":reserve_percent,
                    "drawdown_percent":dd,"open_positions":len(portfolio.open_positions())
                })
                quality.append({"timestamp":execution_time.isoformat(),"universe":len(symbols),"analyzed":len(analyses),"errors":len(step_errors),"future_records_blocked":lookahead,"status":"OK" if not step_errors else "PARTIAL"})
                audit.append({"timestamp":execution_time.isoformat(),"event":"STEP_COMPLETE","cutoff":cutoff.isoformat(),"actions":len(actions),"equity":value})
                self.progress.update({
                    "cycles_done": idx,
                    "symbols_done_current_cycle": len(symbols),
                    "symbols_total_current_cycle": len(symbols),
                    "operations": len(trades),
                    "portfolio_value": round(value, 8),
                })
                self._refresh_progress()
                if self.config.performance_mode == "eco": time_module.sleep(0.05)
            final=equity[-1]["equity"] if equity else portfolio.initial_capital
            status=(
                self.progress.get("stage")
                if self.progress.get("stage") in {"STOPPED", "INVALID_COVERAGE"}
                else "COMPLETE"
            )
            cache_stats = dict(self._replay_cache.stats) if self._replay_cache else {}
            decision_counts = Counter(str(row.get("decision") or "UNKNOWN") for row in decisions)
            execution_rejection_counts = Counter(str(row.get("reason") or "UNKNOWN") for row in rejected)
            trade_decision_counts = Counter(str(row.get("decision") or "UNKNOWN") for row in trades)
            macro_events_used = {str(row.get("macro_observed_at")) for row in decisions if row.get("macro_status") == "AVAILABLE" and row.get("macro_observed_at")}
            news_events_used = {str(row.get("news_observed_at")) for row in decisions if row.get("news_status") == "AVAILABLE" and row.get("news_observed_at")}
            macro_context_changes = sum(1 for row in decisions if row.get("macro_status") == "AVAILABLE" and (float(row.get("macro_multiplier") or 1.0) != 1.0 or str(row.get("macro_regime") or "NEUTRAL") != "NEUTRAL"))
            news_context_changes = sum(1 for row in decisions if row.get("news_status") == "AVAILABLE" and (float(row.get("news_multiplier") or 1.0) != 1.0 or str(row.get("news_impact") or "NEUTRAL") not in {"NEUTRAL","NO_CHANGE","NO_CHANGE_WITH_INCOMPLETE_DATA"}))
            context_coverage = _context_coverage(decisions, self.config.mode)
            event_momentum_rows = self._event_momentum_outcomes(decisions)
            event_momentum_summary = self._event_momentum_summary(event_momentum_rows)
            event_state_counts = Counter(str(row.get("event_state") or "NO_EVENT") for row in decisions)
            watch_state_counts = Counter(str(row.get("state") or "UNKNOWN") for row in self._event_watch_rows)
            watch_reason_counts = Counter(str(row.get("reason") or "UNKNOWN") for row in self._event_watch_rows)
            execution_metrics = _execution_observability(
                trades, equity, portfolio.initial_capital
            )
            reason_counts = Counter()
            for row in decisions:
                for reason in str(row.get("reason_codes") or "").split("|"):
                    reason = reason.strip()
                    if reason:
                        reason_counts[reason] += 1
            benchmarks = self._benchmarks(times) if times and status == "COMPLETE" else {}
            final_marks = last_valid_marks
            final_invested = portfolio.invested_value(final_marks)
            final_cost_basis = sum(
                position.cost_basis for position in portfolio.open_positions()
            )
            open_position_rows = []
            estimated_closing_fee = 0.0
            estimated_closing_slippage = 0.0
            estimated_closing_proceeds = 0.0
            for position in portfolio.open_positions():
                last_price = final_marks.get(position.symbol)
                market_value = (
                    position.quantity * float(last_price)
                    if last_price is not None else None
                )
                unrealized_position = (
                    market_value - position.cost_basis
                    if market_value is not None else None
                )
                open_position_rows.append({
                    "symbol": position.symbol,
                    "quantity": round(position.quantity, 12),
                    "average_price": round(position.average_price, 12),
                    "last_price": round(float(last_price), 12)
                    if last_price is not None else None,
                    "cost_basis_usdt": round(position.cost_basis, 8),
                    "market_value_usdt": round(market_value, 8)
                    if market_value is not None else None,
                    "unrealized_pnl_usdt": round(unrealized_position, 8)
                    if unrealized_position is not None else None,
                    "mark_status": "AVAILABLE" if last_price is not None else "UNAVAILABLE",
                })
                if last_price is not None:
                    raw_value = position.quantity * float(last_price)
                    slipped_value = raw_value * (
                        1 - self.config.slippage_bps / 10_000
                    )
                    closing_fee = slipped_value * self.config.fee_rate
                    estimated_closing_slippage += raw_value - slipped_value
                    estimated_closing_fee += closing_fee
                    estimated_closing_proceeds += slipped_value - closing_fee
            close_all_available = all(
                row["mark_status"] == "AVAILABLE" for row in open_position_rows
            )
            estimated_final_usdt = (
                portfolio.cash + estimated_closing_proceeds
                if close_all_available else None
            )
            accounting_realized = portfolio.cash + final_cost_basis - portfolio.initial_capital
            accounting_unrealized = final_invested - final_cost_basis
            drawdown_details = self._drawdown_details(equity)
            news_snapshot = self._news_snapshot(original_store)
            asset_results = self._asset_results(portfolio, final_marks, trades)
            event_realized = sum(
                float(row.get("realized_pnl") or 0)
                for row in trades
                if row.get("strategy_layer") == "NEWS_EVENT" and row.get("side") == "SELL"
            )
            event_unrealized = 0.0
            for item in self._event_trades:
                if item.get("status") not in {"OPEN", "PARTIAL"}:
                    continue
                remaining = float(item.get("remaining_quantity") or 0)
                initial = max(float(item.get("initial_quantity") or 0), 1e-12)
                remaining_basis = float(item.get("entry_cost") or 0) * remaining / initial
                event_unrealized += remaining * float(final_marks.get(item["symbol"], item.get("entry_price") or 0)) - remaining_basis
            market_data_quality = self._market_data_quality()
            coverage_status = str(
                market_data_quality["summary"].get("coverage_status") or "UNAVAILABLE"
            )
            replay_validity = (
                "INVALID_COVERAGE"
                if status == "INVALID_COVERAGE" or coverage_status == "UNAVAILABLE"
                else "PARTIAL_DATA" if coverage_status == "PARTIAL"
                else "VALID"
            )
            context_preflight_payload = context_preflight.as_dict()
            context_preflight_payload["market"]["status"] = coverage_status
            context_preflight_payload["market"]["coverage_percent"] = (
                market_data_quality["summary"].get("coverage_percent_min")
            )
            recycling_summary = {
                key: round(value, 8) if isinstance(value, float) else value
                for key, value in self._recycling_metrics.items()
            }
            weakness_signals = int(recycling_summary.get("weakness_signals") or 0)
            recycling_summary["average_weakness_drawdown_percent"] = round(
                float(recycling_summary.get("weakness_drawdown_total_percent") or 0)
                / weakness_signals,
                8,
            ) if weakness_signals else None
            recycling_summary["current_rebuy_pool_usdt"] = round(
                sum(float(value) for value in self._recycling_pools["rebuy_by_symbol"].values()),
                8,
            )
            recycling_summary["current_opportunity_pool_usdt"] = round(
                float(self._recycling_pools["opportunity_usdt"]), 8
            )
            recycling_summary["current_retained_cash_usdt"] = round(
                float(self._recycling_pools["retained_usdt"]), 8
            )
            summary={
                "version":APP_VERSION,
                "status":status,
                "start":self.config.start,
                "end":self.config.end,
                "frequency":self.config.frequency,
                "mode":self.config.mode,
                "effective_context_mode":context_preflight.effective_mode,
                "context_validity":context_preflight.validity_label,
                "context_preflight":context_preflight_payload,
                "replay_validity":replay_validity,
                "strategy_mode":self.config.strategy_mode,
                "universe_mode":self.config.universe_mode,
                "fixed_symbols":self.fixed_symbols if self.config.universe_mode == "fixed" else [],
                "universe_size":self.config.universe_size,
                "candidate_limit":self.config.candidate_limit,
                "max_open_positions":self.config.max_open_positions,
                "initial_capital":portfolio.initial_capital,
                "final_equity":round(final,8),
                "ending_mtm_equity_usdt":round(final,8),
                "return_pct":round((final/portfolio.initial_capital-1)*100,6),
                "max_drawdown_pct":round(max_dd,6),
                "max_drawdown": {key: round(value, 8) if isinstance(value, float) else value for key, value in drawdown_details.items()},
                "maximum_equity_usdt": round(max((float(row.get("equity") or 0) for row in equity), default=portfolio.initial_capital), 8),
                "final_cash_usdt": round(portfolio.cash, 8),
                "reserved_cash_usdt": round(self._reserved_cash(), 8),
                "free_cash_usdt": round(self._available_cash(portfolio), 8),
                "final_invested_usdt": round(final_invested, 8),
                "cost_basis_open_positions_usdt": round(final_cost_basis, 8),
                "market_value_open_positions_usdt": round(final_invested, 8),
                "open_positions": open_position_rows,
                "hypothetical_close_all": {
                    "status": "AVAILABLE" if close_all_available else "UNAVAILABLE_MISSING_MARKS",
                    "estimated_closing_fee_usdt": round(estimated_closing_fee, 8)
                    if close_all_available else None,
                    "estimated_closing_slippage_usdt": round(
                        estimated_closing_slippage, 8
                    ) if close_all_available else None,
                    "estimated_final_usdt": round(estimated_final_usdt, 8)
                    if estimated_final_usdt is not None else None,
                    "liquidated_return_percent": round(
                        (estimated_final_usdt / portfolio.initial_capital - 1) * 100,
                        6,
                    ) if estimated_final_usdt is not None else None,
                    "note": "SEPARATE_FROM_MARK_TO_MARKET_ENDING_EQUITY",
                },
                "realized_pnl_usdt": round(accounting_realized, 8),
                "unrealized_pnl_usdt": round(accounting_unrealized, 8),
                "net_result_usdt": round(final-portfolio.initial_capital, 8),
                "gross_result_before_costs_usdt": round(final-portfolio.initial_capital+portfolio.fees_paid+portfolio.slippage_paid, 8),
                "trades":portfolio.trades,
                **execution_metrics,
                "win_rate_percent":execution_metrics["closed_cycle_metrics"]["win_rate_percent"],
                "profit_factor":execution_metrics["closed_cycle_metrics"]["profit_factor"],
                "profit_factor_status":execution_metrics["closed_cycle_metrics"]["profit_factor_status"],
                "expectancy_usdt":execution_metrics["closed_cycle_metrics"]["expectancy_usdt"],
                "cycles_completed":len(equity),
                "decisions_total":len(decisions),
                "decision_counts":dict(sorted(decision_counts.items())),
                "top_rejection_reasons":[{"reason":reason,"count":count} for reason,count in reason_counts.most_common(10)],
                "execution_counts":dict(sorted(trade_decision_counts.items())),
                "execution_rejections":sum(execution_rejection_counts.values()),
                "execution_rejection_reasons":[{"reason":reason,"count":count} for reason,count in execution_rejection_counts.most_common(10)],
                "macro_events_used":len(macro_events_used),
                "news_events_used":len(news_events_used),
                "macro_context_changes":macro_context_changes,
                "news_context_changes":news_context_changes,
                "macro_context_coverage":context_coverage["macro"],
                "news_context_coverage":context_coverage["news"],
                "context_warnings":context_coverage["warnings"],
                "context_warning": ("|".join(context_coverage["warnings"]) if context_coverage["warnings"] else "OK"),
                "event_momentum_research": {**event_momentum_summary, "research_only": not self._event_enabled},
                "event_momentum_state_counts": dict(sorted(event_state_counts.items())),
                "event_momentum_outcome_hash": _sha256_json(event_momentum_rows),
                "event_momentum_production_weight": sum(row.get("strategy_layer") == "NEWS_EVENT" for row in trades),
                "event_watch": {
                    "observations": len(self._event_watch_rows),
                    "state_counts": dict(sorted(watch_state_counts.items())),
                    "reason_counts": dict(sorted(watch_reason_counts.items())),
                    "confirmed_entries": sum(row.get("action") == "ENTER" for row in self._event_watch_rows),
                    "additional_tranches": sum(row.get("action") == "ADD_TRANCHE" for row in self._event_watch_rows),
                    "invalidations": sum(row.get("action") == "INVALIDATE" for row in self._event_watch_rows),
                    "late_events": sum(
                        "EVENT_TOO_EXTENDED" in str(row.get("event_blockers") or "")
                        for row in decisions
                    ),
                    "overbought_buys": sum(
                        row.get("strategy_layer") == "NEWS_EVENT"
                        and row.get("side") == "BUY"
                        and bool(row.get("overbought_entry"))
                        for row in trades
                    ),
                    "lookahead_guard": "CLOSED_1M_AT_OR_BEFORE_EACH_OBSERVATION",
                },
                "event_result": {
                    "realized_pnl_usdt": round(event_realized, 8),
                    "unrealized_pnl_usdt": round(event_unrealized, 8),
                    "total_pnl_usdt": round(event_realized + event_unrealized, 8),
                    "buys": sum(row.get("strategy_layer") == "NEWS_EVENT" and row.get("side") == "BUY" for row in trades),
                    "sells": sum(row.get("strategy_layer") == "NEWS_EVENT" and row.get("side") == "SELL" for row in trades),
                },
                "capital_recycling": recycling_summary,
                "deterioration_reentry_guard": {
                    **self._guard_metrics,
                    "production_parity": True,
                    "rule_source": "investment.deterioration_guard.DeteriorationGuard",
                    "telemetry_events": len(self._execution_guard_store.events),
                },
                "pending_buys": {
                    **self._pending_metrics,
                    "open_at_end": len(self._pending_buys),
                    "reserved_at_end_usdt": round(self._reserved_cash(), 8),
                    "ttl_hours": self.config.pending_buy_ttl_hours,
                    "orders": [
                        {
                            **{key: value for key, value in order.items() if key != "created_at"},
                            "created_at": order["created_at"].isoformat(),
                        }
                        for order in self._pending_buys.values()
                    ],
                },
                "asset_results": asset_results,
                "ohlcv_data_quality": market_data_quality["summary"],
                "news_snapshot": {key:value for key,value in news_snapshot.items() if key != "manifest"},
                "churn_guard": {"enabled":self.config.churn_guard_enabled,"buy_cooldown_hours":self.config.buy_cooldown_hours,"reduce_min_hold_hours":self.config.reduce_min_hold_hours,"reentry_cooldown_hours":self.config.reentry_cooldown_hours},
                "benchmarks":benchmarks,
                "fees_usdt":round(portfolio.fees_paid,8),
                "slippage_usdt":round(portfolio.slippage_paid,8),
                "fee_rate":self.config.fee_rate,
                "slippage_bps":self.config.slippage_bps,
                "lookahead_blocked":lookahead,
                "errors":len(errors),
                "duration_seconds":round(time_module.time()-started,2),
                "cache":cache_stats,
            }
            input_provenance = self._input_provenance(original_store)
            summary["fingerprint_schema"] = FINGERPRINT_SCHEMA
            summary["input_fingerprint"] = input_provenance["sha256"]
            summary["frozen_dataset_fingerprint"] = input_provenance[
                "frozen_dataset_fingerprint"
            ]
            summary["input_provenance"] = input_provenance
            summary["analytical_output_hash"] = self._analytical_output_hash(
                summary,
                decisions,
                trades,
                universe_log,
                rejected,
                quality,
                errors,
                audit,
                equity,
            )
            self._write_outputs(run_dir, summary, decisions, trades, universe_log, rejected, quality, errors, audit, equity)
            self._write_csv(run_dir / "event_momentum.csv", event_momentum_rows)
            self._write_csv(run_dir / "event_watch_timeline.csv", self._event_watch_rows)
            return summary, run_dir
        finally:
            self.engine.point_in_time_store = original_store
            self._restore_market_data(original_market_data)
            self.progress["running"] = False
            if self.progress.get("stage") not in {"STOPPED", "INVALID_COVERAGE"}:
                self.progress["stage"] = "COMPLETE"
            self._refresh_progress()

    def _write_csv(self, path: Path, rows: list[dict]) -> None:
        if not rows: path.write_text("",encoding="utf-8"); return
        fields=[]
        for row in rows:
            for key in row:
                if key not in fields: fields.append(key)
        with path.open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

    def _write_outputs(self, d:Path, summary:dict, decisions:list, trades:list, universe:list, rejected:list, quality:list, errors:list, audit:list, equity:list)->None:
        from testing.historical_artifacts import (
            build_candlestick_chart, build_equity_chart, build_markdown,
            write_isolated_journal,
        )
        config=asdict(self.config); config["fixed_symbols"]=self.fixed_symbols if self.config.universe_mode == "fixed" else []; config["config_hash"]=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()
        config["fingerprint_schema"] = summary.get("fingerprint_schema")
        config["input_fingerprint"] = summary.get("input_fingerprint")
        config["frozen_dataset_fingerprint"] = summary.get("frozen_dataset_fingerprint")
        config["analytical_output_hash"] = summary.get("analytical_output_hash")
        (d/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
        (d/"config.json").write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding="utf-8")
        (d/"fingerprints.json").write_text(json.dumps({
            "schema": summary.get("fingerprint_schema"),
            "input_fingerprint": summary.get("input_fingerprint"),
            "frozen_dataset_fingerprint": summary.get("frozen_dataset_fingerprint"),
            "analytical_output_hash": summary.get("analytical_output_hash"),
            "input_provenance": summary.get("input_provenance"),
        },ensure_ascii=False,indent=2),encoding="utf-8")
        self._write_csv(d/"decisions.csv",decisions); self._write_csv(d/"trades.csv",trades); self._write_csv(d/"universe.csv",universe); self._write_csv(d/"rejected_assets.csv",rejected); self._write_csv(d/"data_quality.csv",quality); self._write_csv(d/"daily_equity.csv",equity)
        for name,rows in (("errors.jsonl",errors),("audit.jsonl",audit)):
            (d/name).write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in rows),encoding="utf-8")
        (d/"source_events.jsonl").write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in (self.engine.point_in_time_store.events if self.engine.point_in_time_store else [])),encoding="utf-8")
        news_snapshot = self._news_snapshot(self.engine.point_in_time_store)
        (d/"news_snapshot_manifest.json").write_text(
            json.dumps(news_snapshot,ensure_ascii=False,indent=2),encoding="utf-8"
        )
        (d/"market_data_quality.json").write_text(
            json.dumps(self._market_data_quality(),ensure_ascii=False,indent=2),
            encoding="utf-8",
        )
        (d/"result.json").write_text(json.dumps({
            "summary":summary,"trades":trades,"equity_curve":equity,
            "event_trades":self._event_trades,"news_snapshot":news_snapshot,
            "event_watch_timeline":self._event_watch_rows,
        },ensure_ascii=False,indent=2,default=str),encoding="utf-8")
        self._write_csv(d/"event_trades.csv", [
            {**item,"entry_time":str(item.get("entry_time")),"plan":json.dumps(item.get("plan") or {},ensure_ascii=False),"news":json.dumps(item.get("news") or [],ensure_ascii=False)}
            for item in self._event_trades
        ])
        limitations = []
        if not news_snapshot.get("sufficient"):
            limitations.append("Покрытие исторических новостей недостаточно: новостные события не выдумывались и сегодняшние статьи не использовались.")
        if self.config.universe_mode == "dynamic":
            limitations.append("Каталог пар получен из текущего Binance exchangeInfo; это не исторический рейтинг капитализации и он не включает уже делистированные пары — возможен survivorship bias.")
        limitations.append(
            "Ожидающие покупки резервируют USDT, повторно проверяются на каждом цикле, "
            "имеют production TTL и освобождают резерв при отмене. Историческая глубина "
            "стакана недоступна, поэтому точное влияние глубины рынка отмечено как недоступное для воспроизведения."
        )
        if not any((row.get("macro_context_coverage") or {}).get("covered_evaluations") for row in [summary]):
            limitations.append("Архив исторических макро-публикаций отсутствует или не покрыл решения; отсутствующий optional context применён нейтрально.")
        build_equity_chart(d/"equity_curve.png",equity)
        interval = self._interval()
        chart_symbols = {
            str(row.get("symbol")) for row in trades if row.get("symbol")
        }
        if self.config.universe_mode == "fixed":
            chart_symbols.update(self.fixed_symbols)
        for symbol in sorted(chart_symbols)[:20]:
            try:
                candles = self._replay_cache.ensure(symbol, interval) if self._replay_cache else []
                start_ms = int(datetime.combine(date.fromisoformat(self.config.start),time.min,tzinfo=timezone.utc).timestamp()*1000)
                end_ms = int(datetime.combine(date.fromisoformat(self.config.end),time.max,tzinfo=timezone.utc).timestamp()*1000)
                visible = [row for row in candles if start_ms <= int(row.get("open_time") or 0) <= end_ms]
                build_candlestick_chart(d/f"{symbol}_candles.png",symbol,visible,trades)
            except Exception as exc:
                errors.append({"type":"CHART_UNAVAILABLE","symbol":symbol,"error":str(exc)})
        (d/"report_ru.md").write_text(build_markdown(summary,trades,limitations),encoding="utf-8")
        write_isolated_journal(
            d/"historical_replay.sqlite3",summary=summary,trades=trades,
            equity=equity,news_manifest=news_snapshot["manifest"],
        )
        (d/"diagnostics.txt").write_text(f"Bot version: {APP_VERSION}\nPython: {sys.version}\nPlatform: {platform.platform()}\nStatus: {summary['status']}\nDuration: {summary['duration_seconds']} sec\nErrors: {summary['errors']}\nLookahead blocked: {summary['lookahead_blocked']}\nInput fingerprint: {summary.get('input_fingerprint')}\nAnalytical output hash: {summary.get('analytical_output_hash')}\n",encoding="utf-8")
        rows="".join(f"<tr><th>{html.escape(str(k))}</th><td>{html.escape(str(v))}</td></tr>" for k,v in summary.items())
        (d/"report.html").write_text(f"<!doctype html><meta charset='utf-8'><title>Replay report</title><h1>Spot Investment AI v{APP_VERSION}</h1><table border='1' cellpadding='6'>{rows}</table><p>See CSV/JSONL files for the full audit.</p>",encoding="utf-8")


def compare_runs(engine_factory, base_config: HistoricalReplayConfig, symbols: Iterable[str] | None, output_root: str|Path="output") -> tuple[dict,Path]:
    stamp=datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    root=Path(output_root)/f"comparison_{base_config.start}_{base_config.end}_{stamp}"; root.mkdir(parents=True,exist_ok=False)
    rows=[]; manifests=[]
    for frequency in ("4h","1d","1w"):
        for mode in ("market_only","macro_only","verified_news"):
            cfg=HistoricalReplayConfig(**{**asdict(base_config),"frequency":frequency,"mode":mode})
            runner=HistoricalReplayRunner(engine_factory(),cfg,symbols)
            summary,run_dir=runner.run(root)
            rows.append(summary); manifests.append({"frequency":frequency,"mode":mode,"path":str(run_dir)})
    runner._write_csv(root/"comparison.csv",rows)
    (root/"runs_manifest.json").write_text(json.dumps(manifests,ensure_ascii=False,indent=2),encoding="utf-8")
    best=max(rows,key=lambda x:x["return_pct"]) if rows else {}
    result={"version":APP_VERSION,"runs":len(rows),"best":best,"path":str(root)}
    (root/"comparison_report.html").write_text("<!doctype html><meta charset='utf-8'><h1>Replay comparison</h1><pre>"+html.escape(json.dumps(result,ensure_ascii=False,indent=2))+"</pre>",encoding="utf-8")
    return result,root


def compare_strategy_runs(engine_factory, base_config: HistoricalReplayConfig, symbols: Iterable[str] | None, output_root: str|Path="output") -> tuple[dict,Path]:
    """Compare the four v6 Spot layers on one frozen period and universe."""
    stamp=datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    root=Path(output_root)/f"strategy_comparison_{base_config.start}_{base_config.end}_{stamp}"
    root.mkdir(parents=True,exist_ok=False)
    definitions = (
        ("baseline", "market_only", "Базовая стратегия"),
        ("baseline_recycling", "market_only", "Базовая + оборот капитала"),
        ("baseline_news_event", "verified_news", "Базовая + новости/события"),
        ("full", "verified_news", "Полная текущая стратегия"),
    )
    rows=[]; manifests=[]
    for strategy_mode, context_mode, label in definitions:
        cfg=HistoricalReplayConfig(**{
            **asdict(base_config),"strategy_mode":strategy_mode,"mode":context_mode,
        })
        runner=HistoricalReplayRunner(engine_factory(),cfg,symbols)
        summary,run_dir=runner.run(root)
        row={**summary,"comparison_label":label}
        rows.append(row)
        manifests.append({"strategy_mode":strategy_mode,"mode":context_mode,"label":label,"path":str(run_dir),"output_hash":summary.get("analytical_output_hash")})
    by_mode={row["strategy_mode"]:row for row in rows}
    baseline=by_mode["baseline"]
    recycling=by_mode["baseline_recycling"]
    news=by_mode["baseline_news_event"]
    full=by_mode["full"]
    result={
        "version":APP_VERSION,"start":base_config.start,"end":base_config.end,
        "initial_capital":base_config.capital,"frequency":base_config.frequency,
        "universe_mode":base_config.universe_mode,"runs":len(rows),
        "results":rows,
        "baseline_final_equity":baseline["final_equity"],
        "capital_recycling_final_equity":recycling["final_equity"],
        "news_event_final_equity":news["final_equity"],
        "full_final_equity":full["final_equity"],
        "capital_recycling_contribution_usdt":round(recycling["final_equity"]-baseline["final_equity"],8),
        "news_event_contribution_usdt":round(news["final_equity"]-baseline["final_equity"],8),
        "full_vs_baseline_usdt":round(full["final_equity"]-baseline["final_equity"],8),
        "frozen_dataset_hashes":sorted({str(row.get("frozen_dataset_fingerprint")) for row in rows}),
        "same_frozen_dataset":len({str(row.get("frozen_dataset_fingerprint")) for row in rows})==1,
        "path":str(root),
    }
    HistoricalReplayRunner._write_csv(runner,root/"strategy_comparison.csv",rows)
    (root/"runs_manifest.json").write_text(json.dumps(manifests,ensure_ascii=False,indent=2),encoding="utf-8")
    (root/"comparison.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    lines=[
        "# СРАВНЕНИЕ СТРАТЕГИЙ — Spot Investment AI", "",
        f"Период: **{base_config.start} — {base_config.end}**  ",
        f"Старт: **{base_config.capital:.2f} USDT**", "",
        "| Режим | Итог, USDT | Доходность | MaxDD | Покупок | Продаж |", "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(f"| {row['comparison_label']} | {row['final_equity']:.2f} | {row['return_pct']:+.2f}% | {abs(row['max_drawdown_pct']):.2f}% | {row.get('buys',0)} | {row.get('sell_actions',0)} |")
    lines.extend([
        "", f"Вклад оборота капитала относительно baseline: **{result['capital_recycling_contribution_usdt']:+.2f} USDT**.",
        f"Вклад News/Event относительно baseline: **{result['news_event_contribution_usdt']:+.2f} USDT**.",
        f"Полная стратегия относительно baseline: **{result['full_vs_baseline_usdt']:+.2f} USDT**.",
        "", f"Одинаковый frozen dataset для всех режимов: **{'да' if result['same_frozen_dataset'] else 'нет'}**.",
    ])
    (root/"comparison_ru.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return result,root


def move_run_to_trash(path: str|Path, output_root: str|Path="output") -> Path:
    source=Path(path).resolve(); root=Path(output_root).resolve()
    if root not in source.parents or not source.is_dir(): raise ValueError("run path must be an output subdirectory")
    trash=root/"trash"; trash.mkdir(parents=True,exist_ok=True)
    target=trash/source.name
    if target.exists(): target=trash/f"{source.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.move(str(source),str(target)); return target
