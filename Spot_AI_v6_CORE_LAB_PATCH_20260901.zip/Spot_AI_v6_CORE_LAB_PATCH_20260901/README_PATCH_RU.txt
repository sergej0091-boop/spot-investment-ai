Spot Investment AI v6.0.0 — CORE LAB patch, 2026-09-01

Назначение:
- добавить переключаемый профиль CORE_LAB (BTC+ETH) внутри того же Spot AI;
- FULL остаётся доступен и возвращает прежний полный paper-режим;
- CORE_LAB замораживает optional context для решений, Capital Recycling и новые News/Event входы;
- safety/deterioration/re-entry guards остаются включены;
- существующие позиции продолжают управляться;
- исправить изоляцию News/Event sleeve от production position quantity/cost basis/risk;
- decision trace использует policy thresholds, чтобы A/B-диагностика не врала;
- добавить локальный BTC/ETH audit script для 90d 1D/4H A/B.

ВАЖНО:
- пакет НЕ содержит .env, production SQLite, caches, logs или Telegram session;
- не менять thresholds/allocation/universe одновременно с этим патчем;
- после установки явно включить CORE_LAB в Telegram Settings (или config key strategy_profile=CORE_LAB);
- FULL остаётся аварийно/операционно доступен одной кнопкой в настройках.

Основной локальный аудит:
python scripts/core_lab_btc_eth_audit.py --start 2026-06-03 --end 2026-08-31 --symbols BTCUSDT ETHUSDT --frequencies 1d 4h --capital 1000

Он выполняет:
1) baseline production policy vs LONG_HORIZON_EXIT;
2) baseline -> +Capital Recycling -> +News/Event -> Full.

Тяжёлые historical datasets должны оставаться на локальном компьютере пользователя.
