from __future__ import annotations

import json
import sqlite3
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

from config.settings import AUTO_ENABLED_BY_DEFAULT, DEFAULT_CAPITAL_USDT, PORTFOLIO_DB_PATH
from investment.models import PositionState


class PortfolioJournal:
    def __init__(self, path: str | Path = PORTFOLIO_DB_PATH):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._migrate()

    def _connect(self):
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _migrate(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS transactions(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
                    quantity REAL NOT NULL CHECK(quantity>0),
                    price REAL NOT NULL CHECK(price>0),
                    fee_usdt REAL NOT NULL DEFAULT 0,
                    reason TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS theses(
                    symbol TEXT PRIMARY KEY,
                    why_bought TEXT NOT NULL,
                    expected_outcome TEXT NOT NULL,
                    invalidation TEXT NOT NULL,
                    acceptable_risks TEXT,
                    review_at TEXT,
                    updated_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'ACTIVE',
                    invalidation_rules_json TEXT NOT NULL DEFAULT '{}',
                    breach_reason TEXT,
                    breached_at TEXT
                );
                CREATE TABLE IF NOT EXISTS analyses(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    score REAL NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS review_events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    trigger_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    reason TEXT,
                    analysis_id INTEGER,
                    status TEXT NOT NULL DEFAULT 'OPEN',
                    due_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    closed_at TEXT
                );
                CREATE TABLE IF NOT EXISTS portfolio_snapshots(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    total_cost_usdt REAL NOT NULL,
                    total_value_usdt REAL NOT NULL,
                    realized_pnl_usdt REAL NOT NULL,
                    unrealized_pnl_usdt REAL NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS bot_config(
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS paper_orders(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
                    status TEXT NOT NULL,
                    order_kind TEXT NOT NULL,
                    amount_usdt REAL NOT NULL DEFAULT 0,
                    quantity REAL NOT NULL DEFAULT 0,
                    lower_price REAL,
                    upper_price REAL,
                    requested_price REAL,
                    fill_price REAL,
                    fee_usdt REAL NOT NULL DEFAULT 0,
                    slippage_bps REAL NOT NULL DEFAULT 0,
                    reason TEXT,
                    analysis_id INTEGER,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    filled_at TEXT,
                    cancelled_at TEXT
                );
                CREATE TABLE IF NOT EXISTS automation_runs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    status TEXT NOT NULL,
                    summary_json TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    finished_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS notifications(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'PENDING',
                    created_at TEXT NOT NULL,
                    sent_at TEXT
                );
                CREATE TABLE IF NOT EXISTS source_snapshots(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_type TEXT NOT NULL,
                    source_name TEXT NOT NULL,
                    symbol TEXT,
                    payload_json TEXT NOT NULL,
                    observed_at TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS whale_observations(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    label TEXT NOT NULL,
                    chain TEXT NOT NULL,
                    address TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    balance REAL NOT NULL,
                    observed_at TEXT NOT NULL,
                    metadata_json TEXT NOT NULL DEFAULT '{}'
                );
                CREATE TABLE IF NOT EXISTS decision_cycles(
                    cycle_id TEXT PRIMARY KEY,
                    mode TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'RUNNING',
                    config_json TEXT NOT NULL DEFAULT '{}',
                    available_assets INTEGER NOT NULL DEFAULT 0,
                    asset_filter_eligible_assets INTEGER NOT NULL DEFAULT 0,
                    liquidity_eligible_assets INTEGER NOT NULL DEFAULT 0,
                    universe_assets INTEGER NOT NULL DEFAULT 0,
                    history_eligible_assets INTEGER NOT NULL DEFAULT 0,
                    analyzed_assets INTEGER NOT NULL DEFAULT 0,
                    candidate_pool_assets INTEGER NOT NULL DEFAULT 0,
                    final_candidate_assets INTEGER NOT NULL DEFAULT 0,
                    purchases INTEGER NOT NULL DEFAULT 0,
                    exits INTEGER NOT NULL DEFAULT 0,
                    errors INTEGER NOT NULL DEFAULT 0,
                    summary_json TEXT NOT NULL DEFAULT '{}',
                    started_at TEXT NOT NULL,
                    finished_at TEXT
                );
                CREATE TABLE IF NOT EXISTS decision_evaluations(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cycle_id TEXT NOT NULL,
                    analysis_id INTEGER,
                    symbol TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    universe_membership INTEGER NOT NULL DEFAULT 1,
                    data_completeness REAL,
                    eligibility TEXT NOT NULL DEFAULT 'PENDING',
                    evaluation_status TEXT NOT NULL DEFAULT 'PENDING',
                    candidate_score REAL,
                    base_score REAL,
                    final_score REAL,
                    base_decision TEXT,
                    final_decision TEXT,
                    primary_reason TEXT,
                    secondary_reasons_json TEXT NOT NULL DEFAULT '[]',
                    context_snapshot_ref TEXT,
                    purchase_possible INTEGER,
                    candidate_rank INTEGER,
                    candidate_selected INTEGER NOT NULL DEFAULT 0,
                    execution_action TEXT,
                    execution_status TEXT,
                    execution_blocker TEXT,
                    score_components_json TEXT NOT NULL DEFAULT '{}',
                    gate_results_json TEXT NOT NULL DEFAULT '{}',
                    data_quality_json TEXT NOT NULL DEFAULT '{}',
                    payload_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(cycle_id, symbol)
                );
                CREATE INDEX IF NOT EXISTS idx_decision_evaluations_created
                    ON decision_evaluations(created_at);
                CREATE INDEX IF NOT EXISTS idx_decision_evaluations_decision
                    ON decision_evaluations(final_decision);
                CREATE TABLE IF NOT EXISTS provider_health_events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    provider TEXT NOT NULL,
                    status TEXT NOT NULL,
                    fallback TEXT,
                    detail_json TEXT NOT NULL DEFAULT '{}',
                    observed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_provider_health_provider_time
                    ON provider_health_events(provider, observed_at);
                CREATE TABLE IF NOT EXISTS capital_recycling_state(
                    symbol TEXT PRIMARY KEY,
                    peak_price REAL NOT NULL DEFAULT 0,
                    peak_at TEXT,
                    harvest_stage INTEGER NOT NULL DEFAULT 0,
                    weakness_stage INTEGER NOT NULL DEFAULT 0,
                    harvest_reference_quantity REAL NOT NULL DEFAULT 0,
                    last_harvest_price REAL,
                    last_weakness_buy_price REAL,
                    rebuy_pool_usdt REAL NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS capital_recycling_events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    stage INTEGER NOT NULL DEFAULT 0,
                    price REAL NOT NULL DEFAULT 0,
                    quantity REAL NOT NULL DEFAULT 0,
                    amount_usdt REAL NOT NULL DEFAULT 0,
                    pnl_percent REAL,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_capital_recycling_symbol_time
                    ON capital_recycling_events(symbol, created_at);
                """
            )
        self._ensure_thesis_columns()
        if self.get_config("initial_capital_usdt") is None:
            self.set_config("initial_capital_usdt", DEFAULT_CAPITAL_USDT)
        if self.get_config("automation_enabled") is None:
            self.set_config("automation_enabled", AUTO_ENABLED_BY_DEFAULT)
        if self.get_config("purchases_paused") is None:
            self.set_config("purchases_paused", False)
        if self.get_config("daily_report_enabled") is None:
            self.set_config("daily_report_enabled", False)
        if self.get_config("last_daily_report_at") is None:
            self.set_config("last_daily_report_at", None)
        if self.get_config("last_cycle_summary_at") is None:
            self.set_config("last_cycle_summary_at", None)

    def _ensure_thesis_columns(self) -> None:
        with self._connect() as connection:
            columns = {
                item["name"] for item in connection.execute("PRAGMA table_info(theses)").fetchall()
            }
            additions = [
                ("status", "TEXT NOT NULL DEFAULT 'ACTIVE'"),
                ("invalidation_rules_json", "TEXT NOT NULL DEFAULT '{}'"),
                ("breach_reason", "TEXT"),
                ("breached_at", "TEXT"),
            ]
            for name, ddl in additions:
                if name not in columns:
                    connection.execute(f"ALTER TABLE theses ADD COLUMN {name} {ddl}")

    def set_config(self, key: str, value) -> None:
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO bot_config(key,value_json,updated_at) VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=excluded.updated_at""",
                (key, json.dumps(value, ensure_ascii=False), self._now()),
            )

    def get_config(self, key: str, default=None):
        with self._connect() as connection:
            row = connection.execute("SELECT value_json FROM bot_config WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value_json"])
        except json.JSONDecodeError:
            return default

    def all_config(self) -> dict:
        with self._connect() as connection:
            rows = connection.execute("SELECT key,value_json FROM bot_config ORDER BY key").fetchall()
        result = {}
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value_json"])
            except json.JSONDecodeError:
                result[row["key"]] = row["value_json"]
        return result

    def begin_decision_cycle(
        self, cycle_id: str, mode: str, config: dict, started_at: str | None = None
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO decision_cycles(cycle_id,mode,status,config_json,started_at)
                VALUES(?,?,'RUNNING',?,?)""",
                (
                    str(cycle_id),
                    str(mode),
                    json.dumps(config, ensure_ascii=False),
                    started_at or self._now(),
                ),
            )

    def reconcile_running_decision_cycles(self, reason: str = "PROCESS_RESTART") -> int:
        """Close cycle rows left RUNNING by a dead previous process.

        This is safe to call only after the process single-instance lock is held.
        Historical completed rows are never touched.
        """
        now = self._now()
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT cycle_id,summary_json,errors FROM decision_cycles WHERE status='RUNNING'"
            ).fetchall()
            for row in rows:
                try:
                    summary = json.loads(row["summary_json"] or "{}")
                except json.JSONDecodeError:
                    summary = {}
                summary.update({
                    "recovered_on_startup": True,
                    "recovery_reason": reason,
                    "recovered_at": now,
                })
                connection.execute(
                    """UPDATE decision_cycles
                       SET status='INTERRUPTED_ON_RESTART', finished_at=?, errors=?, summary_json=?
                       WHERE cycle_id=? AND status='RUNNING'""",
                    (now, int(row["errors"] or 0) + 1, json.dumps(summary, ensure_ascii=False), row["cycle_id"]),
                )
        return len(rows)

    def latest_decision_cycle(self, *, completed_only: bool = False) -> dict | None:
        where = "WHERE status NOT IN ('RUNNING')" if completed_only else ""
        with self._connect() as connection:
            row = connection.execute(
                f"SELECT * FROM decision_cycles {where} ORDER BY started_at DESC LIMIT 1"
            ).fetchone()
        if not row:
            return None
        item = dict(row)
        try:
            item["config"] = json.loads(item.pop("config_json") or "{}")
        except json.JSONDecodeError:
            item["config"] = {}
        try:
            item["summary"] = json.loads(item.pop("summary_json") or "{}")
        except json.JSONDecodeError:
            item["summary"] = {}
        return item

    def decision_cycle_evaluations(self, cycle_id: str) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM decision_evaluations WHERE cycle_id=? ORDER BY final_score DESC,id",
                (str(cycle_id),),
            ).fetchall()
        output = []
        for row in rows:
            item = dict(row)
            for field, default in (("secondary_reasons_json", []), ("score_components_json", {}),
                                   ("gate_results_json", {}), ("data_quality_json", {}),
                                   ("payload_json", {})):
                try:
                    item[field.removesuffix("_json")] = json.loads(item.pop(field) or json.dumps(default))
                except json.JSONDecodeError:
                    item[field.removesuffix("_json")] = default
            output.append(item)
        return output

    def update_decision_cycle(self, cycle_id: str, **changes) -> None:
        allowed = {
            "status", "available_assets", "asset_filter_eligible_assets",
            "liquidity_eligible_assets", "universe_assets", "history_eligible_assets",
            "analyzed_assets", "candidate_pool_assets", "final_candidate_assets",
            "purchases", "exits", "errors", "finished_at", "summary_json",
        }
        values = []
        assignments = []
        for key, value in changes.items():
            if key not in allowed:
                raise ValueError(f"unsupported decision cycle field: {key}")
            if key == "summary_json" and not isinstance(value, str):
                value = json.dumps(value or {}, ensure_ascii=False)
            assignments.append(f"{key}=?")
            values.append(value)
        if not assignments:
            return
        values.append(str(cycle_id))
        with self._connect() as connection:
            connection.execute(
                f"UPDATE decision_cycles SET {','.join(assignments)} WHERE cycle_id=?",
                values,
            )

    def upsert_decision_evaluation(self, cycle_id: str, symbol: str, mode: str, **changes) -> None:
        json_fields = {
            "secondary_reasons_json", "score_components_json", "gate_results_json",
            "data_quality_json", "payload_json",
        }
        allowed = {
            "analysis_id", "universe_membership", "data_completeness", "eligibility",
            "evaluation_status", "candidate_score", "base_score", "final_score",
            "base_decision", "final_decision", "primary_reason",
            "secondary_reasons_json", "context_snapshot_ref", "purchase_possible",
            "candidate_rank", "candidate_selected", "execution_action",
            "execution_status", "execution_blocker", "score_components_json",
            "gate_results_json", "data_quality_json", "payload_json",
        }
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                """INSERT OR IGNORE INTO decision_evaluations(
                    cycle_id,symbol,mode,created_at,updated_at
                ) VALUES(?,?,?,?,?)""",
                (str(cycle_id), symbol.upper(), str(mode), now, now),
            )
            assignments = []
            values = []
            for key, value in changes.items():
                if key not in allowed:
                    raise ValueError(f"unsupported decision evaluation field: {key}")
                if key in json_fields and not isinstance(value, str):
                    value = json.dumps(value if value is not None else {}, ensure_ascii=False)
                if key in {"universe_membership", "candidate_selected"} and value is not None:
                    value = int(bool(value))
                if key == "purchase_possible" and value is not None:
                    value = int(bool(value))
                assignments.append(f"{key}=?")
                values.append(value)
            assignments.append("updated_at=?")
            values.append(now)
            values.extend([str(cycle_id), symbol.upper()])
            connection.execute(
                f"UPDATE decision_evaluations SET {','.join(assignments)} "
                "WHERE cycle_id=? AND symbol=?",
                values,
            )

    def record_provider_health(
        self, provider: str, status: str, detail: dict | None = None,
        fallback: str | None = None, observed_at: str | None = None,
    ) -> int:
        with self._connect() as connection:
            return int(connection.execute(
                """INSERT INTO provider_health_events(
                    provider,status,fallback,detail_json,observed_at
                ) VALUES(?,?,?,?,?)""",
                (
                    str(provider), str(status), fallback,
                    json.dumps(detail or {}, ensure_ascii=False),
                    observed_at or self._now(),
                ),
            ).lastrowid)

    def latest_provider_health(self) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                """SELECT p.* FROM provider_health_events p
                JOIN (
                    SELECT provider,MAX(id) AS max_id
                    FROM provider_health_events GROUP BY provider
                ) latest ON latest.max_id=p.id
                ORDER BY p.provider"""
            ).fetchall()
        output = []
        for row in rows:
            item = dict(row)
            item["detail"] = json.loads(item.pop("detail_json") or "{}")
            output.append(item)
        return output

    def provider_health_summary(self) -> list[dict]:
        """Latest observation plus last READY timestamp for every provider."""
        with self._connect() as connection:
            rows = connection.execute(
                """SELECT p.*,
                          (SELECT MAX(ok.observed_at)
                           FROM provider_health_events ok
                           WHERE ok.provider=p.provider AND ok.status='READY') AS last_success
                   FROM provider_health_events p
                   JOIN (SELECT provider,MAX(id) AS max_id
                         FROM provider_health_events GROUP BY provider) latest
                     ON latest.max_id=p.id
                   ORDER BY p.provider"""
            ).fetchall()
        output = []
        for row in rows:
            item = dict(row)
            try:
                item["detail"] = json.loads(item.pop("detail_json") or "{}")
            except json.JSONDecodeError:
                item["detail"] = {}
            output.append(item)
        return output

    def decision_diagnostics(self, hours: int = 24, detail_limit: int = 50) -> dict:
        hours = max(1, int(hours))
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        with self._connect() as connection:
            cycle_rows = connection.execute(
                "SELECT * FROM decision_cycles WHERE started_at>=? ORDER BY started_at",
                (cutoff,),
            ).fetchall()
            rows = connection.execute(
                """SELECT * FROM decision_evaluations
                WHERE created_at>=? ORDER BY created_at DESC,id DESC""",
                (cutoff,),
            ).fetchall()
        evaluations = []
        for row in rows:
            item = dict(row)
            for field, default in (
                ("secondary_reasons_json", []), ("score_components_json", {}),
                ("gate_results_json", {}), ("data_quality_json", {}),
                ("payload_json", {}),
            ):
                try:
                    item[field.removesuffix("_json")] = json.loads(item.pop(field) or json.dumps(default))
                except json.JSONDecodeError:
                    item[field.removesuffix("_json")] = default
            evaluations.append(item)

        decisions = Counter(
            str(item["final_decision"])
            for item in evaluations if item.get("final_decision")
        )
        no_buy = Counter()
        for item in evaluations:
            if item.get("execution_action") == "BUY" and item.get("execution_status") == "FILLED":
                continue
            reason = item.get("execution_blocker") or item.get("primary_reason")
            if reason:
                no_buy[str(reason)] += 1
        gate_totals: dict[str, list[int]] = {}
        for item in evaluations:
            for gate, result in (item.get("gate_results") or {}).items():
                if not isinstance(result, dict) or not result.get("evaluated"):
                    continue
                bucket = gate_totals.setdefault(str(gate), [0, 0])
                bucket[0] += 1
                bucket[1] += int(bool(result.get("pass")))
        gate_rates = {
            gate: {
                "evaluated": values[0],
                "pass": values[1],
                "fail": values[0] - values[1],
                "fail_rate_percent": round((values[0] - values[1]) / values[0] * 100, 2),
            }
            for gate, values in sorted(gate_totals.items())
        }
        return {
            "hours": hours,
            "cycles": len(cycle_rows),
            "unique_assets": len({item["symbol"] for item in evaluations}),
            "universe_rows": len(evaluations),
            "evaluations": sum(
                item.get("evaluation_status") in {"EVALUATED", "ERROR"}
                for item in evaluations
            ),
            "candidate_pool": sum(int(row["candidate_pool_assets"] or 0) for row in cycle_rows),
            "candidates": sum(int(row["final_candidate_assets"] or 0) for row in cycle_rows),
            "purchases": sum(int(row["purchases"] or 0) for row in cycle_rows),
            "exits": sum(int(row["exits"] or 0) for row in cycle_rows),
            "errors": sum(int(row["errors"] or 0) for row in cycle_rows),
            "decision_counts": dict(sorted(decisions.items())),
            "top_no_buy_reasons": [
                {"reason": reason, "count": count}
                for reason, count in no_buy.most_common(10)
            ],
            "quality_gate_pass_rates": gate_rates,
            "cycles_detail": [dict(row) for row in cycle_rows],
            "evaluations_detail": evaluations[: max(1, int(detail_limit))],
        }

    def set_initial_capital(self, amount_usdt: float, reset: bool = False) -> None:
        amount = float(amount_usdt)
        if amount <= 0:
            raise ValueError("capital must be positive")
        if reset:
            with self._connect() as connection:
                connection.execute("DELETE FROM transactions")
                connection.execute("DELETE FROM paper_orders")
                connection.execute("DELETE FROM portfolio_snapshots")
        elif self.transactions_count() > 0:
            raise ValueError("capital cannot be changed after trades without reset")
        self.set_config("initial_capital_usdt", round(amount, 8))

    def initial_capital(self) -> float:
        return float(self.get_config("initial_capital_usdt", DEFAULT_CAPITAL_USDT))

    def add_transaction(
        self, symbol, side, quantity, price, fee_usdt=0.0, reason="", created_at: str | None = None
    ):
        side = side.upper()
        if side not in {"BUY", "SELL"}:
            raise ValueError("side must be BUY or SELL")
        if quantity <= 0 or price <= 0 or fee_usdt < 0:
            raise ValueError("invalid transaction values")
        with self._connect() as connection:
            return int(
                connection.execute(
                    "INSERT INTO transactions(symbol,side,quantity,price,fee_usdt,reason,created_at) VALUES(?,?,?,?,?,?,?)",
                    (
                        symbol.upper(), side, float(quantity), float(price), float(fee_usdt),
                        reason, created_at or self._now(),
                    ),
                ).lastrowid
            )

    def transactions_count(self) -> int:
        with self._connect() as connection:
            return int(connection.execute("SELECT COUNT(*) AS n FROM transactions").fetchone()["n"])

    def recent_transactions(self, limit: int = 20, symbol: str | None = None) -> list[dict]:
        query = "SELECT * FROM transactions"
        params: list = []
        if symbol:
            query += " WHERE symbol=?"
            params.append(symbol.upper())
        query += " ORDER BY id DESC LIMIT ?"
        params.append(max(1, int(limit)))
        with self._connect() as connection:
            return [dict(row) for row in connection.execute(query, params).fetchall()]

    def recent_transactions_with_realized_pnl(self, limit: int = 20) -> list[dict]:
        """Return recent journal entries with read-only, moving-average sale results.

        The journal schema is deliberately unchanged.  Sale cost and profit are
        derived from the same chronological cost basis used by ``realized_pnl``.
        """
        with self._connect() as connection:
            rows = [dict(row) for row in connection.execute(
                "SELECT * FROM transactions ORDER BY id"
            ).fetchall()]
        state: dict[str, tuple[float, float]] = {}
        enriched: list[dict] = []
        for row in rows:
            item = dict(row)
            symbol = str(item["symbol"])
            quantity, cost = state.get(symbol, (0.0, 0.0))
            qty = float(item["quantity"])
            price = float(item["price"])
            fee = float(item["fee_usdt"])
            if item["side"] == "BUY":
                item["spent_usdt"] = round(qty * price + fee, 8)
                quantity += qty
                cost += qty * price + fee
            else:
                sold = min(qty, quantity)
                average = cost / quantity if quantity else 0.0
                cost_basis = average * sold
                received = qty * price - fee
                item["received_usdt"] = round(received, 8)
                item["sold_quantity_with_cost"] = round(sold, 8)
                if sold > 0:
                    pnl = sold * price - fee - cost_basis
                    item["cost_basis_usdt"] = round(cost_basis, 8)
                    item["realized_pnl_usdt"] = round(pnl, 8)
                    item["realized_pnl_percent"] = round(pnl / cost_basis * 100, 8) if cost_basis else None
                quantity -= sold
                cost -= cost_basis
            if quantity < 1e-12:
                quantity, cost = 0.0, 0.0
            state[symbol] = (quantity, cost)
            enriched.append(item)
        return list(reversed(enriched[-max(1, int(limit)):]))

    def post_sell_rebuy_reference(self, symbol: str) -> dict | None:
        """Return the last profitable partial production SELL in the open cycle.

        The value is derived read-only from the existing execution journal.  A
        full production close clears the reference, so an old SELL can never
        leak into a later independent investment cycle.  NEWS/EVENT sleeve
        executions are excluded from the production-position replay.
        """
        symbol = str(symbol).upper()
        with self._connect() as connection:
            transactions = [dict(row) for row in connection.execute(
                "SELECT * FROM transactions WHERE symbol=? ORDER BY id", (symbol,)
            ).fetchall()]
            orders = [dict(row) for row in connection.execute(
                """SELECT symbol,side,quantity,fill_price,metadata_json
                   FROM paper_orders
                   WHERE symbol=? AND status='FILLED'
                   ORDER BY id""",
                (symbol,),
            ).fetchall()]

        order_metadata: dict[tuple[str, float, float], list[dict]] = {}
        for order in orders:
            try:
                metadata = json.loads(order.get("metadata_json") or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                metadata = {}
            key = (
                str(order.get("side") or "").upper(),
                round(float(order.get("quantity") or 0), 12),
                round(float(order.get("fill_price") or 0), 12),
            )
            order_metadata.setdefault(key, []).append(metadata)

        quantity = 0.0
        cost = 0.0
        reference: dict | None = None
        for row in transactions:
            side = str(row.get("side") or "").upper()
            qty = float(row.get("quantity") or 0)
            price = float(row.get("price") or 0)
            fee = float(row.get("fee_usdt") or 0)
            key = (side, round(qty, 12), round(price, 12))
            metadata_rows = order_metadata.get(key) or []
            metadata = metadata_rows.pop(0) if metadata_rows else {}
            trade_type = str(metadata.get("trade_type") or "").upper()
            sleeve = str(metadata.get("strategy_sleeve") or "").upper()
            is_event = trade_type == "NEWS_EVENT" or "EVENT" in sleeve
            if is_event:
                continue

            if side == "BUY":
                quantity += qty
                cost += qty * price + fee
                continue
            if side != "SELL":
                continue

            sold = min(qty, quantity)
            average = cost / quantity if quantity else 0.0
            basis = average * sold
            realized_pnl = sold * price - fee - basis
            quantity -= sold
            cost -= basis
            if quantity < 1e-12:
                quantity, cost, reference = 0.0, 0.0, None
                continue

            # Only the latest eligible production SELL controls the guard.  A
            # non-profitable partial reduction does not manufacture a rebuy
            # threshold from proceeds that were not profitably harvested.
            if realized_pnl > 0 and sold > 0:
                reference = {
                    "symbol": symbol,
                    "transaction_id": int(row["id"]),
                    "created_at": row.get("created_at"),
                    "last_sell_price": price,
                    "last_sell_quantity": sold,
                    "last_sell_fee_usdt": fee,
                    "last_sell_net_unit_proceeds": price - fee / sold,
                    "realized_pnl_usdt": realized_pnl,
                    "remaining_quantity_after_sell": quantity,
                }
            else:
                reference = None
        return reference if quantity > 0 else None

    def position(self, symbol, current_price=0.0):
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT side,quantity,price,fee_usdt FROM transactions WHERE symbol=? ORDER BY id",
                (symbol.upper(),),
            ).fetchall()
        quantity = 0.0
        cost = 0.0
        for row in rows:
            qty = float(row["quantity"])
            price = float(row["price"])
            fee = float(row["fee_usdt"])
            if row["side"] == "BUY":
                quantity += qty
                cost += qty * price + fee
            else:
                sold = min(qty, quantity)
                average = cost / quantity if quantity else 0.0
                quantity -= sold
                cost -= average * sold
        if quantity < 1e-12:
            quantity = 0.0
            cost = 0.0
        average = cost / quantity if quantity else 0.0
        return PositionState(
            symbol=symbol.upper(), quantity=quantity, average_price=average,
            invested_usdt=cost, current_value_usdt=quantity * float(current_price),
        )

    def paper_order_position(
        self, symbol: str, current_price: float = 0.0, *,
        excluded_trade_types: set[str] | frozenset[str] | tuple[str, ...] = (),
    ) -> tuple[PositionState, int]:
        """Rebuild a logical sleeve position from filled paper orders.

        Paper orders retain metadata (unlike the legacy transaction table), so
        NEWS_EVENT fills can be excluded without changing the aggregate cash
        ledger.  The returned count lets callers detect old/migrated journals
        where paper-order coverage is incomplete and fall back safely.
        """
        excluded = {str(item).upper() for item in excluded_trade_types}
        with self._connect() as connection:
            rows = connection.execute(
                """SELECT side,quantity,fill_price,fee_usdt,metadata_json
                   FROM paper_orders
                   WHERE symbol=? AND status='FILLED'
                   ORDER BY id""",
                (symbol.upper(),),
            ).fetchall()
        quantity = 0.0
        cost = 0.0
        included = 0
        for row in rows:
            try:
                metadata = json.loads(row["metadata_json"] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                metadata = {}
            trade_type = str(metadata.get("trade_type") or "").upper()
            if trade_type in excluded:
                continue
            qty = float(row["quantity"] or 0)
            price = float(row["fill_price"] or 0)
            fee = float(row["fee_usdt"] or 0)
            if qty <= 0 or price <= 0:
                continue
            included += 1
            if str(row["side"]).upper() == "BUY":
                quantity += qty
                cost += qty * price + fee
                continue
            sold = min(qty, quantity)
            average = cost / quantity if quantity else 0.0
            quantity -= sold
            cost -= average * sold
        if quantity < 1e-12:
            quantity = 0.0
            cost = 0.0
        average = cost / quantity if quantity else 0.0
        return (
            PositionState(
                symbol=symbol.upper(), quantity=quantity, average_price=average,
                invested_usdt=cost, current_value_usdt=quantity * float(current_price),
            ),
            included,
        )

    def positions(self, prices: dict[str, float] | None = None):
        with self._connect() as connection:
            symbols = [
                item["symbol"]
                for item in connection.execute("SELECT DISTINCT symbol FROM transactions ORDER BY symbol")
            ]
        output = []
        prices = prices or {}
        for symbol in symbols:
            stored = self.position(symbol, float(prices.get(symbol, 0)))
            if stored.exists:
                current_value = stored.current_value_usdt or stored.invested_usdt
                output.append(
                    PositionState(
                        symbol=stored.symbol, quantity=stored.quantity,
                        average_price=stored.average_price, invested_usdt=stored.invested_usdt,
                        current_value_usdt=current_value,
                    )
                )
        return output

    def cash_balance(self) -> float:
        cash = self.initial_capital()
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT side,quantity,price,fee_usdt FROM transactions ORDER BY id"
            ).fetchall()
        for row in rows:
            gross = float(row["quantity"]) * float(row["price"])
            fee = float(row["fee_usdt"])
            cash += gross - fee if row["side"] == "SELL" else -(gross + fee)
        return round(cash, 8)

    def reserved_cash(self) -> float:
        with self._connect() as connection:
            value = connection.execute(
                "SELECT COALESCE(SUM(amount_usdt),0) AS total FROM paper_orders WHERE side='BUY' AND status='PENDING'"
            ).fetchone()["total"]
        return round(float(value or 0), 8)

    def available_cash(self) -> float:
        return round(max(0.0, self.cash_balance() - self.reserved_cash()), 8)

    def realized_pnl(self, symbol=None):
        query = "SELECT symbol,side,quantity,price,fee_usdt FROM transactions"
        params = ()
        if symbol:
            query += " WHERE symbol=?"
            params = (symbol.upper(),)
        query += " ORDER BY symbol,id"
        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        state = {}
        realized = 0.0
        for row in rows:
            current_symbol = row["symbol"]
            quantity, cost = state.get(current_symbol, (0.0, 0.0))
            qty = float(row["quantity"])
            price = float(row["price"])
            fee = float(row["fee_usdt"])
            if row["side"] == "BUY":
                quantity += qty
                cost += qty * price + fee
            else:
                sold = min(qty, quantity)
                average = cost / quantity if quantity else 0.0
                realized += sold * (price - average) - fee
                quantity -= sold
                cost -= average * sold
            state[current_symbol] = (quantity, cost)
        return round(realized, 8)

    def create_paper_order(
        self, symbol: str, side: str, order_kind: str, amount_usdt: float = 0,
        quantity: float = 0, lower_price: float | None = None,
        upper_price: float | None = None, requested_price: float | None = None,
        reason: str = "", analysis_id: int | None = None, metadata: dict | None = None,
    ) -> int:
        side = side.upper()
        if side not in {"BUY", "SELL"}:
            raise ValueError("paper order side must be BUY or SELL")
        if amount_usdt < 0 or quantity < 0:
            raise ValueError("paper order values cannot be negative")
        with self._connect() as connection:
            return int(
                connection.execute(
                    """INSERT INTO paper_orders(symbol,side,status,order_kind,amount_usdt,quantity,
                    lower_price,upper_price,requested_price,reason,analysis_id,metadata_json,created_at)
                    VALUES(?,?,'PENDING',?,?,?,?,?,?,?,?,?,?)""",
                    (
                        symbol.upper(), side, order_kind, float(amount_usdt), float(quantity),
                        lower_price, upper_price, requested_price, reason, analysis_id,
                        json.dumps(metadata or {}, ensure_ascii=False), self._now(),
                    ),
                ).lastrowid
            )

    def pending_orders(self, symbol: str | None = None) -> list[dict]:
        query = "SELECT * FROM paper_orders WHERE status='PENDING'"
        params: list = []
        if symbol:
            query += " AND symbol=?"
            params.append(symbol.upper())
        query += " ORDER BY id"
        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        output = []
        for row in rows:
            item = dict(row)
            item["metadata"] = json.loads(item.pop("metadata_json") or "{}")
            output.append(item)
        return output

    def has_pending_buy(self, symbol: str) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT 1 FROM paper_orders WHERE symbol=? AND side='BUY' AND status='PENDING' LIMIT 1",
                (symbol.upper(),),
            ).fetchone()
        return bool(row)

    def fill_paper_order(
        self, order_id: int, fill_price: float, quantity: float,
        fee_usdt: float, slippage_bps: float,
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """UPDATE paper_orders SET status='FILLED',fill_price=?,quantity=?,fee_usdt=?,
                slippage_bps=?,filled_at=? WHERE id=? AND status='PENDING'""",
                (float(fill_price), float(quantity), float(fee_usdt), float(slippage_bps), self._now(), int(order_id)),
            )

    def cancel_order(self, order_id: int, reason: str = "") -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE paper_orders SET status='CANCELLED',reason=COALESCE(reason,'')||?,cancelled_at=? WHERE id=? AND status='PENDING'",
                ((" | " + reason) if reason else "", self._now(), int(order_id)),
            )

    def recent_orders(self, limit: int = 20) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM paper_orders ORDER BY id DESC LIMIT ?", (max(1, int(limit)),)
            ).fetchall()
        return [dict(row) for row in rows]

    def save_automation_run(self, status: str, summary: dict, started_at: str, finished_at: str) -> int:
        with self._connect() as connection:
            return int(
                connection.execute(
                    "INSERT INTO automation_runs(status,summary_json,started_at,finished_at) VALUES(?,?,?,?)",
                    (status, json.dumps(summary, ensure_ascii=False), started_at, finished_at),
                ).lastrowid
            )

    def latest_automation_run(self) -> dict | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM automation_runs ORDER BY id DESC LIMIT 1").fetchone()
        if not row:
            return None
        item = dict(row)
        item["summary"] = json.loads(item.pop("summary_json"))
        return item

    def queue_notification(self, event_type: str, payload: dict) -> int:
        with self._connect() as connection:
            return int(
                connection.execute(
                    "INSERT INTO notifications(event_type,payload_json,created_at) VALUES(?,?,?)",
                    (event_type, json.dumps(payload, ensure_ascii=False), self._now()),
                ).lastrowid
            )

    def pending_notifications(self, limit: int = 50) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM notifications WHERE status='PENDING' ORDER BY id LIMIT ?",
                (max(1, int(limit)),),
            ).fetchall()
        output = []
        for row in rows:
            item = dict(row)
            item["payload"] = json.loads(item.pop("payload_json"))
            output.append(item)
        return output

    def mark_notification_sent(self, notification_id: int) -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE notifications SET status='SENT',sent_at=? WHERE id=?",
                (self._now(), int(notification_id)),
            )

    def save_source_snapshot(self, source_type: str, source_name: str, payload: dict,
                             symbol: str | None = None, observed_at: str | None = None) -> int:
        with self._connect() as connection:
            return int(connection.execute(
                "INSERT INTO source_snapshots(source_type,source_name,symbol,payload_json,observed_at,created_at) VALUES(?,?,?,?,?,?)",
                (source_type, source_name, symbol.upper() if symbol else None,
                 json.dumps(payload, ensure_ascii=False), observed_at or self._now(), self._now()),
            ).lastrowid)

    def add_whale_observation(self, label: str, chain: str, address: str, symbol: str,
                              balance: float, metadata: dict | None = None,
                              observed_at: str | None = None) -> int:
        with self._connect() as connection:
            return int(connection.execute(
                "INSERT INTO whale_observations(label,chain,address,symbol,balance,observed_at,metadata_json) VALUES(?,?,?,?,?,?,?)",
                (label, chain, address, symbol.upper(), float(balance), observed_at or self._now(),
                 json.dumps(metadata or {}, ensure_ascii=False)),
            ).lastrowid)

    def last_whale_observation(self, chain: str, address: str, symbol: str) -> dict | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM whale_observations WHERE chain=? AND address=? AND symbol=? ORDER BY id DESC LIMIT 1",
                (chain, address, symbol.upper()),
            ).fetchone()
        return dict(row) if row else None

    def save_thesis(self, symbol, why_bought, expected_outcome, invalidation,
                    acceptable_risks="", review_at="", invalidation_rules=None):
        now = self._now()
        rules = json.dumps(invalidation_rules or {}, ensure_ascii=False)
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO theses(symbol,why_bought,expected_outcome,invalidation,acceptable_risks,
                review_at,updated_at,status,invalidation_rules_json)
                VALUES(?,?,?,?,?,?,?,'ACTIVE',?)
                ON CONFLICT(symbol) DO UPDATE SET why_bought=excluded.why_bought,
                expected_outcome=excluded.expected_outcome,invalidation=excluded.invalidation,
                acceptable_risks=excluded.acceptable_risks,review_at=excluded.review_at,
                updated_at=excluded.updated_at,status='ACTIVE',
                invalidation_rules_json=excluded.invalidation_rules_json,breach_reason=NULL,breached_at=NULL""",
                (
                    symbol.upper(), why_bought, expected_outcome, invalidation,
                    acceptable_risks, review_at, now, rules,
                ),
            )

    def thesis(self, symbol):
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM theses WHERE symbol=?", (symbol.upper(),)).fetchone()
        if not row:
            return None
        item = dict(row)
        item["invalidation_rules"] = json.loads(item.pop("invalidation_rules_json") or "{}")
        return item

    def invalidate_thesis(self, symbol, reason):
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                "UPDATE theses SET status='INVALIDATED',breach_reason=?,breached_at=?,updated_at=? WHERE symbol=?",
                (reason, now, now, symbol.upper()),
            )

    def save_analysis(self, analysis):
        with self._connect() as connection:
            return int(
                connection.execute(
                    "INSERT INTO analyses(symbol,decision,score,payload_json,created_at) VALUES(?,?,?,?,?)",
                    (
                        analysis["symbol"], analysis["decision"], float(analysis["score"]),
                        json.dumps(analysis, ensure_ascii=False), self._now(),
                    ),
                ).lastrowid
            )

    def latest_analysis(self, symbol, before_id=None):
        query = "SELECT id,payload_json FROM analyses WHERE symbol=?"
        params = [symbol.upper()]
        if before_id is not None:
            query += " AND id<?"
            params.append(before_id)
        query += " ORDER BY id DESC LIMIT 1"
        with self._connect() as connection:
            row = connection.execute(query, params).fetchone()
        if not row:
            return None
        item = json.loads(row["payload_json"])
        item["_analysis_id"] = row["id"]
        return item

    def add_review_events(self, symbol, events, analysis_id=None):
        ids = []
        now = self._now()
        with self._connect() as connection:
            for event in events:
                ids.append(
                    int(
                        connection.execute(
                            "INSERT INTO review_events(symbol,trigger_type,severity,reason,analysis_id,due_at,created_at) VALUES(?,?,?,?,?,?,?)",
                            (
                                symbol.upper(), event["type"], event["severity"],
                                event.get("reason"), analysis_id, event.get("due_at") or now, now,
                            ),
                        ).lastrowid
                    )
                )
        return ids

    def due_reviews(self):
        now = self._now()
        with self._connect() as connection:
            return [
                dict(item)
                for item in connection.execute(
                    "SELECT * FROM review_events WHERE status='OPEN' AND due_at<=? ORDER BY severity DESC,due_at",
                    (now,),
                ).fetchall()
            ]

    def close_review(self, event_id):
        with self._connect() as connection:
            connection.execute(
                "UPDATE review_events SET status='CLOSED',closed_at=? WHERE id=?",
                (self._now(), event_id),
            )

    # --- Spot AI v6.0 Capital Recycling state ---------------------------------

    def recycling_state(self, symbol: str) -> dict:
        symbol = symbol.upper()
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM capital_recycling_state WHERE symbol=?", (symbol,)
            ).fetchone()
        if row:
            return dict(row)
        return {
            "symbol": symbol,
            "peak_price": 0.0,
            "peak_at": None,
            "harvest_stage": 0,
            "weakness_stage": 0,
            "harvest_reference_quantity": 0.0,
            "last_harvest_price": None,
            "last_weakness_buy_price": None,
            "rebuy_pool_usdt": 0.0,
            "updated_at": self._now(),
        }

    def update_recycling_state(self, symbol: str, **changes) -> dict:
        current = self.recycling_state(symbol)
        allowed = {
            "peak_price", "peak_at", "harvest_stage", "weakness_stage",
            "harvest_reference_quantity", "last_harvest_price",
            "last_weakness_buy_price", "rebuy_pool_usdt",
        }
        for key, value in changes.items():
            if key in allowed:
                current[key] = value
        current["updated_at"] = self._now()
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO capital_recycling_state(
                    symbol,peak_price,peak_at,harvest_stage,weakness_stage,
                    harvest_reference_quantity,last_harvest_price,last_weakness_buy_price,
                    rebuy_pool_usdt,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET
                    peak_price=excluded.peak_price,peak_at=excluded.peak_at,
                    harvest_stage=excluded.harvest_stage,weakness_stage=excluded.weakness_stage,
                    harvest_reference_quantity=excluded.harvest_reference_quantity,
                    last_harvest_price=excluded.last_harvest_price,
                    last_weakness_buy_price=excluded.last_weakness_buy_price,
                    rebuy_pool_usdt=excluded.rebuy_pool_usdt,updated_at=excluded.updated_at""",
                (
                    symbol.upper(), float(current.get("peak_price") or 0),
                    current.get("peak_at"), int(current.get("harvest_stage") or 0),
                    int(current.get("weakness_stage") or 0),
                    float(current.get("harvest_reference_quantity") or 0),
                    current.get("last_harvest_price"),
                    current.get("last_weakness_buy_price"),
                    float(current.get("rebuy_pool_usdt") or 0),
                    current["updated_at"],
                ),
            )
        return self.recycling_state(symbol)

    def observe_recycling_price(self, symbol: str, price: float) -> dict:
        state = self.recycling_state(symbol)
        price = float(price)
        old_peak = float(state.get("peak_price") or 0)
        if price > old_peak:
            # A new high starts a fresh pullback ladder.  Harvest stages are kept
            # until a new accumulation cycle occurs so the 20% strategic core is
            # not repeatedly harvested on every marginal high.
            state = self.update_recycling_state(
                symbol, peak_price=price, peak_at=self._now(), weakness_stage=0
            )
        elif old_peak <= 0:
            state = self.update_recycling_state(
                symbol, peak_price=price, peak_at=self._now()
            )
        return state

    def add_recycling_event(
        self, symbol: str, event_type: str, *, stage: int = 0, price: float = 0,
        quantity: float = 0, amount_usdt: float = 0, pnl_percent: float | None = None,
        metadata: dict | None = None, created_at: str | None = None,
    ) -> int:
        with self._connect() as connection:
            return int(connection.execute(
                """INSERT INTO capital_recycling_events(
                    symbol,event_type,stage,price,quantity,amount_usdt,pnl_percent,metadata_json,created_at
                ) VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    symbol.upper(), str(event_type), int(stage), float(price),
                    float(quantity), float(amount_usdt),
                    None if pnl_percent is None else float(pnl_percent),
                    json.dumps(metadata or {}, ensure_ascii=False),
                    created_at or self._now(),
                ),
            ).lastrowid)

    def recycling_events(self, limit: int = 100, symbol: str | None = None) -> list[dict]:
        query = "SELECT * FROM capital_recycling_events"
        params: list = []
        if symbol:
            query += " WHERE symbol=?"
            params.append(symbol.upper())
        query += " ORDER BY id DESC LIMIT ?"
        params.append(max(1, int(limit)))
        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        output = []
        for row in rows:
            item = dict(row)
            item["metadata"] = json.loads(item.pop("metadata_json") or "{}")
            output.append(item)
        return output

    def add_recycling_proceeds(self, symbol: str, net_proceeds_usdt: float, *,
                               rebuy_share_percent: float, opportunity_share_percent: float,
                               retained_share_percent: float) -> dict:
        total_share = max(1e-9, float(rebuy_share_percent) + float(opportunity_share_percent) + float(retained_share_percent))
        proceeds = max(0.0, float(net_proceeds_usdt))
        rebuy = proceeds * float(rebuy_share_percent) / total_share
        opportunity = proceeds * float(opportunity_share_percent) / total_share
        retained = max(0.0, proceeds - rebuy - opportunity)
        state = self.recycling_state(symbol)
        self.update_recycling_state(
            symbol, rebuy_pool_usdt=float(state.get("rebuy_pool_usdt") or 0) + rebuy
        )
        self.set_config(
            "recycling_opportunity_pool_usdt",
            float(self.get_config("recycling_opportunity_pool_usdt", 0.0)) + opportunity,
        )
        self.set_config(
            "recycling_retained_proceeds_usdt",
            float(self.get_config("recycling_retained_proceeds_usdt", 0.0)) + retained,
        )
        return {
            "rebuy_pool_usdt": round(rebuy, 8),
            "opportunity_pool_usdt": round(opportunity, 8),
            "retained_cash_usdt": round(retained, 8),
        }

    def consume_recycling_pools(self, symbol: str, amount_usdt: float) -> dict:
        amount = max(0.0, float(amount_usdt))
        state = self.recycling_state(symbol)
        rebuy_available = max(0.0, float(state.get("rebuy_pool_usdt") or 0))
        use_rebuy = min(amount, rebuy_available)
        remaining = amount - use_rebuy
        opportunity_available = max(0.0, float(self.get_config("recycling_opportunity_pool_usdt", 0.0)))
        use_opportunity = min(remaining, opportunity_available)
        fresh = max(0.0, remaining - use_opportunity)
        self.update_recycling_state(symbol, rebuy_pool_usdt=rebuy_available - use_rebuy)
        self.set_config(
            "recycling_opportunity_pool_usdt", opportunity_available - use_opportunity
        )
        return {
            "same_asset_rebuy_pool_used_usdt": round(use_rebuy, 8),
            "general_opportunity_pool_used_usdt": round(use_opportunity, 8),
            "portfolio_cash_used_usdt": round(fresh, 8),
        }

    def recycling_summary(self) -> dict:
        with self._connect() as connection:
            state_rows = connection.execute(
                "SELECT * FROM capital_recycling_state ORDER BY symbol"
            ).fetchall()
            event_rows = connection.execute(
                "SELECT event_type,COUNT(*) AS n,COALESCE(SUM(amount_usdt),0) AS amount FROM capital_recycling_events GROUP BY event_type"
            ).fetchall()
        return {
            "states": [dict(row) for row in state_rows],
            "events": {row["event_type"]: {"count": int(row["n"]), "amount_usdt": round(float(row["amount"] or 0), 8)} for row in event_rows},
            "opportunity_pool_usdt": round(float(self.get_config("recycling_opportunity_pool_usdt", 0.0)), 8),
            "retained_proceeds_usdt": round(float(self.get_config("recycling_retained_proceeds_usdt", 0.0)), 8),
            "rebuy_pool_usdt": round(sum(float(row["rebuy_pool_usdt"] or 0) for row in state_rows), 8),
        }

    def portfolio_snapshot(self, prices: dict[str, float]):
        positions = []
        total_cost = 0.0
        total_value = 0.0
        for position in self.positions(prices):
            price = float(prices.get(position.symbol, position.average_price))
            value = position.quantity * price
            total_cost += position.invested_usdt
            total_value += value
            positions.append(
                {
                    "symbol": position.symbol,
                    "quantity": position.quantity,
                    "average_price": position.average_price,
                    "price": price,
                    "cost_usdt": position.invested_usdt,
                    "value_usdt": value,
                    "unrealized_pnl_usdt": value - position.invested_usdt,
                    "pnl_percent": position.pnl_percent,
                }
            )
        realized = self.realized_pnl()
        cash = self.cash_balance()
        equity = cash + total_value
        initial = self.initial_capital()
        payload = {"positions": positions, "cash_usdt": cash, "equity_usdt": equity}
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO portfolio_snapshots(total_cost_usdt,total_value_usdt,realized_pnl_usdt,unrealized_pnl_usdt,payload_json,created_at) VALUES(?,?,?,?,?,?)",
                (
                    total_cost, total_value, realized, total_value - total_cost,
                    json.dumps(payload, ensure_ascii=False), now,
                ),
            )
        return {
            "initial_capital_usdt": round(initial, 2),
            "cash_usdt": round(cash, 2),
            "reserved_cash_usdt": round(self.reserved_cash(), 2),
            "available_cash_usdt": round(self.available_cash(), 2),
            "total_cost_usdt": round(total_cost, 2),
            "total_value_usdt": round(total_value, 2),
            "equity_usdt": round(equity, 2),
            "total_return_usdt": round(equity - initial, 2),
            "total_return_percent": round((equity / initial - 1) * 100, 4) if initial else 0,
            "realized_pnl_usdt": round(realized, 2),
            "unrealized_pnl_usdt": round(total_value - total_cost, 2),
            **payload,
            "created_at": now,
        }
