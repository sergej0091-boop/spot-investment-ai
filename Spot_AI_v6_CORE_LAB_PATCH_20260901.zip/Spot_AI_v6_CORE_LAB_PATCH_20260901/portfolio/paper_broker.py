from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Callable

from config.settings import (
    AUTO_BUY_COOLDOWN_HOURS,
    AUTO_MAX_TRADES_PER_DAY,
    MIN_CASH_RESERVE_PERCENT,
    PAPER_FEE_RATE,
    PAPER_MIN_EXECUTION_NOTIONAL_USDT,
    PAPER_SLIPPAGE_BPS,
    PENDING_BUY_TTL_HOURS,
)
from automation.models import PaperAction
from portfolio.journal import PortfolioJournal


logger = logging.getLogger(__name__)
PendingBuyValidator = Callable[[dict, float], tuple[bool, str]]
REBUY_NOT_CHEAPER_THAN_LAST_SELL = "REBUY_NOT_CHEAPER_THAN_LAST_SELL"


class PaperBroker:
    """Deterministic, no-order paper broker using observed Binance prices."""

    def __init__(self, journal: PortfolioJournal | None = None,
                 fee_rate: float = PAPER_FEE_RATE,
                 slippage_bps: float = PAPER_SLIPPAGE_BPS,
                 min_cash_reserve_percent: float = MIN_CASH_RESERVE_PERCENT,
                 pending_buy_ttl_hours: float = PENDING_BUY_TTL_HOURS):
        self.journal = journal or PortfolioJournal()
        self.fee_rate = max(0.0, float(fee_rate))
        self.slippage_bps = max(0.0, float(slippage_bps))
        self.min_cash_reserve_percent = max(0.0, float(min_cash_reserve_percent))
        self.pending_buy_ttl_hours = max(1.0, float(pending_buy_ttl_hours))

    def _fill_price(self, side: str, market_price: float) -> float:
        multiplier = 1 + self.slippage_bps / 10_000 if side == "BUY" else 1 - self.slippage_bps / 10_000
        return float(market_price) * multiplier

    def evaluate_post_sell_rebuy_guard(
        self, symbol: str, market_price: float,
    ) -> tuple[bool, dict]:
        """Compare an expected BUY all-in unit cost with the last SELL net unit."""
        reference = self.journal.post_sell_rebuy_reference(symbol)
        if not reference:
            return True, {"active": False, "result": "ALLOW"}
        expected_fill = self._fill_price("BUY", market_price)
        fee_denominator = 1.0 - self.fee_rate
        expected_all_in = (
            expected_fill / fee_denominator if fee_denominator > 0 else float("inf")
        )
        sell_net = float(reference["last_sell_net_unit_proceeds"])
        allowed = expected_all_in < sell_net
        net_discount = (
            (sell_net - expected_all_in) / sell_net * 100.0 if sell_net > 0 else -float("inf")
        )
        details = {
            "active": True,
            "symbol": str(symbol).upper(),
            "last_sell_transaction_id": reference["transaction_id"],
            "last_sell_at": reference["created_at"],
            "last_sell_price": round(float(reference["last_sell_price"]), 12),
            "last_sell_net_unit_proceeds": round(sell_net, 12),
            "proposed_buy_price": round(float(market_price), 12),
            "expected_buy_fill_price": round(expected_fill, 12),
            "expected_buy_all_in_unit_cost": round(expected_all_in, 12),
            "net_discount_pct": round(net_discount, 8),
            "result": "ALLOW" if allowed else "BLOCK",
        }
        logger.info(
            "post_sell_rebuy_guard symbol=%s last_sell_price=%.12g "
            "last_sell_net_unit_proceeds=%.12g proposed_buy_price=%.12g "
            "expected_buy_all_in_unit_cost=%.12g net_discount_pct=%.8f result=%s",
            details["symbol"], details["last_sell_price"],
            details["last_sell_net_unit_proceeds"], details["proposed_buy_price"],
            details["expected_buy_all_in_unit_cost"], details["net_discount_pct"],
            details["result"],
        )
        return allowed, details

    def _trades_today(self) -> int:
        today = datetime.now(timezone.utc).date().isoformat()
        return sum(item["created_at"].startswith(today) for item in self.journal.recent_transactions(500))

    def _recent_buy(self, symbol: str) -> bool:
        if AUTO_BUY_COOLDOWN_HOURS <= 0:
            return False
        cutoff = datetime.now(timezone.utc) - timedelta(hours=AUTO_BUY_COOLDOWN_HOURS)
        for item in self.journal.recent_transactions(100, symbol):
            if item["side"] != "BUY":
                continue
            try:
                if datetime.fromisoformat(item["created_at"]) >= cutoff:
                    return True
            except ValueError:
                continue
        return False

    def can_buy(
        self, symbol: str, amount_usdt: float, *,
        reserve_floor_percent: float | None = None,
        reserve_base_usdt: float | None = None,
        bypass_cooldown: bool = False,
    ) -> tuple[bool, str]:
        amount = float(amount_usdt)
        if amount <= 0:
            return False, "buy_amount_not_positive"
        if bool(self.journal.get_config("purchases_paused", False)):
            return False, "purchases_paused"
        if self._trades_today() >= AUTO_MAX_TRADES_PER_DAY:
            return False, "daily_trade_limit_reached"
        if not bypass_cooldown and self._recent_buy(symbol):
            return False, "buy_cooldown_active"
        initial = self.journal.initial_capital()
        reserve_base = max(0.0, float(reserve_base_usdt)) if reserve_base_usdt is not None else initial
        reserve_percent = (
            self.min_cash_reserve_percent
            if reserve_floor_percent is None
            else max(0.0, float(reserve_floor_percent))
        )
        minimum_cash = reserve_base * reserve_percent / 100
        if self.journal.available_cash() - amount < minimum_cash:
            return False, "minimum_cash_reserve_would_be_breached"
        return True, "ok"

    def buy(self, symbol: str, amount_usdt: float, market_price: float,
            reason: str, analysis_id: int | None = None,
            metadata: dict | None = None, *,
            reserve_floor_percent: float | None = None,
            reserve_base_usdt: float | None = None,
            bypass_cooldown: bool = False,
            enforce_post_sell_rebuy_guard: bool = False) -> PaperAction:
        metadata = dict(metadata or {})
        if enforce_post_sell_rebuy_guard:
            rebuy_allowed, rebuy_details = self.evaluate_post_sell_rebuy_guard(
                symbol, market_price
            )
            if rebuy_details.get("active"):
                metadata["post_sell_rebuy_guard"] = rebuy_details
            if not rebuy_allowed:
                return PaperAction(
                    "BUY", symbol.upper(), "SKIPPED",
                    amount_usdt=float(amount_usdt),
                    reason=REBUY_NOT_CHEAPER_THAN_LAST_SELL,
                    details=rebuy_details,
                )
        allowed, why = self.can_buy(
            symbol, amount_usdt, reserve_floor_percent=reserve_floor_percent,
            reserve_base_usdt=reserve_base_usdt, bypass_cooldown=bypass_cooldown,
        )
        if not allowed:
            return PaperAction("BUY", symbol, "SKIPPED", amount_usdt=float(amount_usdt), reason=why)
        fill_price = self._fill_price("BUY", market_price)
        fee = float(amount_usdt) * self.fee_rate
        spendable = float(amount_usdt) - fee
        quantity = spendable / fill_price
        if quantity <= 0:
            return PaperAction("BUY", symbol, "SKIPPED", reason="quantity_not_positive")
        order_id = self.journal.create_paper_order(
            symbol, "BUY", "MARKET", amount_usdt=float(amount_usdt),
            requested_price=float(market_price), reason=reason,
            analysis_id=analysis_id, metadata=metadata,
        )
        self.journal.add_transaction(symbol, "BUY", quantity, fill_price, fee, reason)
        self.journal.fill_paper_order(order_id, fill_price, quantity, fee, self.slippage_bps)
        action = PaperAction(
            "BUY", symbol.upper(), "FILLED", amount_usdt=float(amount_usdt),
            quantity=quantity, price=fill_price, fee_usdt=fee, reason=reason,
            details={"order_id": order_id, **metadata},
        )
        self.journal.queue_notification("PAPER_BUY", action.to_dict())
        return action

    def sell(self, symbol: str, quantity: float, market_price: float,
             reason: str, analysis_id: int | None = None,
             metadata: dict | None = None, *,
             require_positive_net: bool = False,
             cost_basis_price: float | None = None) -> PaperAction:
        metadata = dict(metadata or {})
        stored = self.journal.position(symbol, market_price)
        sell_quantity = min(float(quantity), stored.quantity)
        if sell_quantity <= 0:
            return PaperAction("SELL", symbol, "SKIPPED", reason="no_position")
        fill_price = self._fill_price("SELL", market_price)
        gross = sell_quantity * fill_price
        if (
            sell_quantity + 1e-12 < float(stored.quantity)
            and gross < PAPER_MIN_EXECUTION_NOTIONAL_USDT
        ):
            return PaperAction(
                "SELL", symbol.upper(), "SKIPPED", amount_usdt=max(0.0, gross),
                quantity=sell_quantity, price=fill_price,
                reason="partial_sell_below_minimum_execution_notional",
                details={
                    "minimum_execution_notional_usdt":
                        PAPER_MIN_EXECUTION_NOTIONAL_USDT,
                    "execution_guard": "DUST_PARTIAL_REDUCTION",
                },
            )
        fee = gross * self.fee_rate
        logical_average_cost = (
            float(cost_basis_price)
            if cost_basis_price is not None and float(cost_basis_price) > 0
            else float(stored.average_price or 0)
        )
        cost_basis = sell_quantity * logical_average_cost
        net_realized_pnl = gross - fee - cost_basis
        metadata.update({
            "average_cost_price": logical_average_cost,
            "cost_basis_source": "SLEEVE_OVERRIDE" if cost_basis_price is not None else "AGGREGATE_POSITION",
            "estimated_net_realized_pnl_usdt": round(net_realized_pnl, 12),
        })
        if require_positive_net and net_realized_pnl <= 0:
            return PaperAction(
                "SELL", symbol.upper(), "SKIPPED", amount_usdt=max(0.0, gross - fee),
                quantity=sell_quantity, price=fill_price, fee_usdt=fee,
                reason="profit_guard_net_not_positive",
                details={
                    "requested_reason": reason,
                    "average_cost_price": logical_average_cost,
                    "estimated_net_realized_pnl_usdt": round(net_realized_pnl, 8),
                    "guard": "ordinary_profit_taking_requires_positive_net_pnl",
                    **metadata,
                },
            )
        order_id = self.journal.create_paper_order(
            symbol, "SELL", "MARKET", quantity=sell_quantity,
            requested_price=float(market_price), reason=reason,
            analysis_id=analysis_id, metadata=metadata,
        )
        self.journal.add_transaction(symbol, "SELL", sell_quantity, fill_price, fee, reason)
        self.journal.fill_paper_order(order_id, fill_price, sell_quantity, fee, self.slippage_bps)
        action = PaperAction(
            "SELL", symbol.upper(), "FILLED", amount_usdt=gross - fee,
            quantity=sell_quantity, price=fill_price, fee_usdt=fee, reason=reason,
            details={"order_id": order_id, **metadata},
        )
        self.journal.queue_notification("PAPER_SELL", action.to_dict())
        return action

    def place_buy_zone(self, symbol: str, zone: dict, reason: str,
                       analysis_id: int | None = None, metadata: dict | None = None, *,
                       reserve_floor_percent: float | None = None,
                       reserve_base_usdt: float | None = None) -> PaperAction:
        amount = float(zone.get("amount_usdt", 0))
        if amount <= 0:
            return PaperAction("PLACE_BUY_ZONE", symbol, "SKIPPED", reason="zone_amount_zero")
        if self.journal.has_pending_buy(symbol):
            return PaperAction("PLACE_BUY_ZONE", symbol, "SKIPPED", reason="pending_buy_exists")
        allowed, why = self.can_buy(
            symbol, amount, reserve_floor_percent=reserve_floor_percent,
            reserve_base_usdt=reserve_base_usdt
        )
        if not allowed:
            return PaperAction("PLACE_BUY_ZONE", symbol, "SKIPPED", amount_usdt=amount, reason=why)
        order_id = self.journal.create_paper_order(
            symbol, "BUY", "ZONE", amount_usdt=amount,
            lower_price=float(zone["lower"]), upper_price=float(zone["upper"]),
            reason=reason, analysis_id=analysis_id,
            metadata={"zone": zone, **(metadata or {})},
        )
        return PaperAction(
            "PLACE_BUY_ZONE", symbol.upper(), "PENDING", amount_usdt=amount,
            reason=reason, details={"order_id": order_id, "zone": zone, **(metadata or {})},
        )

    @staticmethod
    def _as_utc(value: str) -> datetime | None:
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)

    def _pending_buy_expired(self, order: dict, now: datetime) -> bool:
        created_at = self._as_utc(order.get("created_at"))
        if created_at is None:
            # An order without a trustworthy age must never execute automatically.
            return True
        return now - created_at >= timedelta(hours=self.pending_buy_ttl_hours)

    def _cancel_pending_buy(
        self, order: dict, reason: str, details: dict | None = None,
    ) -> PaperAction:
        self.journal.cancel_order(int(order["id"]), reason)
        logger.info(
            "pending_buy_cancelled order_id=%s symbol=%s reason=%s reserved_released_usdt=%.8f",
            order["id"], order["symbol"], reason, float(order.get("amount_usdt") or 0),
        )
        return PaperAction(
            "CANCEL_BUY_ZONE", str(order["symbol"]).upper(), "CANCELLED",
            amount_usdt=float(order.get("amount_usdt") or 0), reason=reason,
            details={
                "order_id": int(order["id"]), "reserved_cash_released": True,
                **(details or {}),
            },
        )

    def expire_pending_buy_orders(self, now: datetime | None = None) -> list[PaperAction]:
        current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        actions: list[PaperAction] = []
        for order in self.journal.pending_orders():
            if order["side"] != "BUY" or order["order_kind"] != "ZONE":
                continue
            if self._pending_buy_expired(order, current):
                reason = (
                    f"pending_buy_ttl_expired:{self.pending_buy_ttl_hours:g}h"
                    if self._as_utc(order.get("created_at")) is not None
                    else "pending_buy_created_at_invalid"
                )
                actions.append(self._cancel_pending_buy(order, reason))
        return actions

    def process_pending(
        self, prices: dict[str, float], *,
        validator: PendingBuyValidator | None = None,
        now: datetime | None = None,
    ) -> list[PaperAction]:
        actions: list[PaperAction] = []
        current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        for order in self.journal.pending_orders():
            if order["side"] != "BUY" or order["order_kind"] != "ZONE":
                continue
            if self._pending_buy_expired(order, current):
                reason = (
                    f"pending_buy_ttl_expired:{self.pending_buy_ttl_hours:g}h"
                    if self._as_utc(order.get("created_at")) is not None
                    else "pending_buy_created_at_invalid"
                )
                actions.append(self._cancel_pending_buy(order, reason))
                continue
            symbol = order["symbol"]
            price = prices.get(symbol)
            if price is None:
                continue
            # A pending BUY is never executable without a fresh strategy/context check.
            if validator is None:
                continue
            valid, validation_reason = validator(order, float(price))
            if not valid:
                actions.append(self._cancel_pending_buy(
                    order, validation_reason or "pending_buy_revalidation_failed"
                ))
                continue
            lower = float(order["lower_price"])
            upper = float(order["upper_price"])
            if lower <= float(price) <= upper:
                rebuy_allowed, rebuy_details = self.evaluate_post_sell_rebuy_guard(
                    symbol, float(price)
                )
                if not rebuy_allowed:
                    actions.append(self._cancel_pending_buy(
                        order, REBUY_NOT_CHEAPER_THAN_LAST_SELL, rebuy_details
                    ))
                    continue
                # Release this order's reservation before the normal cash/reserve/cooldown checks.
                self.journal.cancel_order(order["id"], "replaced_by_revalidated_fill")
                metadata = dict(order.get("metadata") or {})
                if rebuy_details.get("active"):
                    metadata["post_sell_rebuy_guard"] = rebuy_details
                action = self.buy(
                    symbol, float(order["amount_usdt"]), float(price),
                    order.get("reason") or "Buy zone reached",
                    analysis_id=order.get("analysis_id"), metadata=metadata,
                    reserve_floor_percent=metadata.get("reserve_target_percent"),
                    reserve_base_usdt=metadata.get("reserve_base_usdt"),
                )
                actions.append(action)
        return actions
