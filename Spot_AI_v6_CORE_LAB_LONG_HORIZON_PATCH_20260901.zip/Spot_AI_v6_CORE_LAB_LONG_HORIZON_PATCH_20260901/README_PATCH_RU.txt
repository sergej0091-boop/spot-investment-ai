Spot Investment AI v6.0.0 — CORE LAB LONG_HORIZON_EXIT experiment
Дата: 2026-09-01

Предпосылка:
- первый CORE LAB patch уже должен быть установлен;
- этот patch НЕ меняет FULL и НЕ продвигает экспериментальную политику в live/autonomous production decisions.

Что меняется:
- только Telegram historical replay;
- когда профиль = CORE_LAB и режим теста = MARKET_ONLY, replay использует LONG_HORIZON_EXIT:
  reduce_on_bearish_regime = False
  structural_failure_action = REDUCE
- FULL replay остаётся BASELINE_V480;
- live/autonomous paper decisions остаются на PRODUCTION_POLICY.

Зачем:
проверить гипотезу, что обычный BEARISH regime сам по себе провоцирует вредный REDUCE после падения.

После установки в результатах исторического теста должны появиться строки:
Профиль: CORE_LAB
Политика решений: LONG_HORIZON_EXIT

Первый тест:
BTCUSDT, 90 дней, 1D, MARKET_ONLY.
Второй тест:
BTCUSDT, 90 дней, 4H, MARKET_ONLY.
